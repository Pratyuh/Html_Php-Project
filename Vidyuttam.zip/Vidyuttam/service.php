<!--==========================
      Services Section
    ============================-->
    <section id="services" class="section-bg">
      <div class="container">

        <header class="section-header">
          <h3>Events</h3>
          
          <center><a style="text-decoration: none; color: #ff6d1b; font-size: 20px; font-weight: 15px;" href="schedule.pdf" download="vidyuttam schedule" ><b>Download Event Schedule</b></a></center>

           


           <p style="color: #7F04FA; font-family: Arial, Helvetica, sans-serif;  font-size: 18px; text-align:justify;">Every Participants Should Bring Their <span style="color: red;">School/College Identity Card</span> With Them. All the participants will be awarded participation certificate after successful completion of the event. Before Registering Any Event, First Go Through The <span style="color: red;">Event Profile</span> Carefully...... <b>Participants are informed to be present 15mins prior to the starting of the event.</b></p> 

          <b style="  font-size: 19px; color: #E81A7B; text-align: justify;"> Note:- Online registration starts from 20th September and Offline Registration will be  from 24th to 26th Sept  and spot registration on 27th Sept only for outside students .. GCE KEONJHAR  Students have to register on or before 26th Sept .</b><br><br>
           
        </header>

        <!-- row 1 card 1 -->
        <div class="row">
  <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/group-quiz.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">Champion Quizzers <br>  <b style="color: #7F04FA;">(Group Quiz)</b></h5>
    
      <p class="card-text"> Hey,yes Hey! Do you think you have a strong general knowledge and intelligent.....</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal1">See Profile</a>
      <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
  <!--2D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/plastic.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">MOVING ON UP <br> <b style="color: #7F04FA;">(Stacking Paper Cup)</b> </h5>
      <p class="card-text">A game that asks player to be a little ambidextrous...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal2">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>

  </div>
    </div>
  </div>
   <!--3D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/paper.png" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title"><b style="color: #7F04FA;">Paper Presentation</b> <br>  </h5>
      <p class="card-text">Tune your compatibility and balance with and balance with  ...</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal3">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--4D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/code.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">BATTLE OF CODERS <br> <b style="color: #7F04FA;">(Coding)</b> </h5>
      <p class="card-text">The most awaited event for which coders prepare to fight on the battlefield...</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal4">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
</div>


        <!-- row 2  1D-->
        <div class="row">
    <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/movie.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">TRIVIA JUNKIES <br> <b style="color: #7F04FA;">(Movie Mania)</b> </h5>
      <p class="card-text">Unlock your Bollywood knowledge at the speed of thought as the quizmaster ..</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal5">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
 <!--2D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/treasure.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">BUSCAR TESORO <br> <b style="color: #7F04FA;">(Treasure Hunt)</b> </h5>
      <p class="card-text">Team uses their collective brainpower to solve clues which will..</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal6">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--3D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/pubg.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">PATT SE HEADSHOT <br> <b style="color: #7F04FA;">(PUBG)</b> </h5>
      <p class="card-text">If you’re a maniac obsessed with “Enemies ahead, I got some life, Winner Winner ..</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal7">See Profile</a>
      <a href="https://docs.google.com/forms/d/e/1FAIpQLSesH8-ih8kbWAhUeZk8x0z_8_htmEBlxcrjJZ5_Bk7WziCdsw/viewform?usp=sf_link" target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--4D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/mobile.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">KNIGHT- X-WING <br> <b style="color: #7F04FA;">(Mobile Legends)</b> </h5>
      <p class="card-text">Be the best out of the rest. Shatter your enemies on the battlefield..</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal8">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
</div>

<!-- row 3 1D -->
        <div class="row">
    <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/poem.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">KREATIONZ <br> <b style="color: #7F04FA;">(Poem Writing)</b> </h5>
      <p class="card-text">Odisha is known for its Arts and artistic people. Here is a..</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal9">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
 <!--2D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/debate.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">POLEMICZNY <br> <b style="color: #7F04FA;">(Parliamentary Debate)</b></h5>
      <p class="card-text">Political acumenship and courage might...</p>
       <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal10">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--3D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/debug.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">CIRCUIT SCRAMBLE <br> <b style="color: #7F04FA;">(Circuit Debugging)</b>  </h5>
      <p class="card-text">Who said only coders can debug? Doctors can debug patients and  ..</p>
     <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal11">See Profile</a>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--4D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/memori.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">MEMORONICS <br> <b style="color: #7F04FA;">(Memorise Tray Items)</b></h5>
      <p class="card-text">Confident enough on your memory and....</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal12">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
</div>

<!-- row 4 1D -->
        <div class="row">
    <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/selfie.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">SNAP- IT <br> <b style="color: #7F04FA;">(Selfie Shooter)</b> </h5>
      <p class="card-text">Stop walking dead as a zombie. Cheer up!! Find something that you...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal13">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
 <!--2D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/tiktok.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">VOGUE ZENITH <br> <b style="color: #7F04FA;">(Tik-Tok)</b> </h5>
      <p class="card-text">If you believe you are raw, real and stylish, then live in the...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal14">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--3D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/2min.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">THE HUNARBAAZ <br> <b style="color: #7F04FA;">(2 Min To Prove)</b> </h5>
      <p class="card-text">Do what makes your soul shine. Empower your creative talent within..</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal15">See Profile</a>
        <a href= "https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
   <!--4D-->
  <div class="column">
    <div class="card">
        <div class="card" >
    <img class="card-img-top" src="img/handicraft.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">RAZSTAVA <br> <b style="color: #7F04FA;">(Handicraft Exhibition)</b></h5>
      <p class="card-text truncate">Reveal your creative art, crafts or paintings...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal16">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
</div>

<!-- row 5 1D -->
        <div class="row">
    <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/robo.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">ROBO LABORATORIO <br> <b style="color: #7F04FA;">(Robotics Exhibition & Death Race)</b></h5>
      <p class="card-text">Robotics and automation have become the focal point for industries to ...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal17">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div> 
  <!-- row 5 2D -->
  <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/dance.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">STAND TOGETHER, STAND STRONG<br> <b style="color: #7F04FA;">(PAPER DANCE)</b></h5>
      <p class="card-text">Tune your compatibility and balance with your friend with beats of music on sheet of paper....</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal18">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
 <!-- row 5 3D -->
  <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/gd.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">Group Discussion <br> <b style="color: #7F04FA;">(Group Discussion)</b></h5>
      <p class="card-text">A discussion group is a group of individuals, typically who share a similar interestCommon methods of conversing ...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal19">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
<!-- row 5 4D -->
  <div class="column">
    <div class="card">
      <div class="card" >
    <img class="card-img-top" src="img/fas.jpg" alt="Card image" >
    <div class="card-body">
      <h5 class="card-title">V-MART FASHION GALA <br> <b style="color: #7F04FA;">(FASHION SHOW)</b></h5>
      <p class="card-text">Fashion is a popular aesthetic expression in a certain time and context, especially in clothing, ...</p>
      <a  class="btn btn-primary stretched-link modal-trigger" data-toggle="modal" data-target="#myModal20">See Profile</a>
          <a href="https://docs.google.com/forms/d/e/1FAIpQLSdMJYO_MKVvhdlb87lczjBjprzGU2DY67q52BXWCmsL4eLt7Q/viewform?usp=sf_link"  target="_blank" class="btn btn-primary stretched-link modal-trigger">Register</a>
    </div>
  </div>
    </div>
  </div>
</div>


      
      </div>
    </section><!-- #services -->


    <!-- popup Modal  -->

  <div class="modal fade" id="myModal1" role="dialog" tabindex="-1">
    <div class="modal-dialog"  role="document">

      <div class="modal-content">
        <h4 style="text-align: center; color:red;">CHAMPION QUIZZERS</h4>
       
        <div class="modal-body ">
           
       <b>  Description:-</b>
      <p>Hey,yes Hey! Do you think you have a strong general knowledge and intelligent enough to answer correctly? If yes, participate and become a champion. Shows us your intelligence and enthusiasm as this quiz will have a pool of question on different fields. </p> <br>

      <b>Rules and regulation:-</b>
      <p><b>GENERAL RULES(PRELIMS):</b><br>
1.Only team entries are eligible ;and A team shall consists of  2 persons.<br>
2.Prior to the start,all participants must write the cover sheets to qualify for finals.This Prelims section is a repository of 30 questions from a wide range of categories within 45 minutes. <br>
3.The participants shall not be allowed to  use mobile or other electronic instruments.<br>
4.The questions shall be in the form of multiple choice, Specific-answer question etc.<br>
5. Top 8 teams will qualify for the final round based on the highest scores obtained & If there is a tie, then team with maximum number of correct starred questions is considered.<br>
6.Audience  shall  not give any hints or clues to the competitors.<br>
7.Replacement of any participant  of a team is not allowed after REGISTRATIONS And Teams selected for the final rounds  will be allowed to give themselves an appropriate name related to the competition by which they may want to be known..<br>
 </p><br>

 <b>FINAL QUIZ(STAGE ROUNDS):</b><br>
Round 1 <br>
1. A question will be asked to a team and if they are unable to answer it will be passed to the next team.(rounds 24-32 questions)<br>
2. Each team would be asked 4 questions each. <br>
* +10/-5: Direct Questions<br>
*+5/0: Pass Questions<br>
3. If a team cannot answer the question, they can pass the question &  then the question would be forwarded to the next team.<br>
4. Answering time is only 30 seconds..<br><br><br>

ROUND 2(RAPID FIRE ROUND):<br>
1. Each team will be asked 10 questions one after another in one minutes time.<br>
* +10/-5: Direct Questions<br>
2. If a team cannot answer the question, they can say pass for the next question. The question will not  be forwarded to the next team&Audience can answer..<br><br><br>
ROUND 3(AUDIO-VISUAL ROUND):<br>
1.Teams  will be shown clips and will have to answer.(rounds 2:12questions)<br>
* +10/-5: Direct Questions<br>
2.Each Team would be asked 2 audio-visual questions. ( 1 slide in each round )<br>
3.Answering time is only 30 seconds And No passing to the next  team &Audience can answer.<br><br><br>
ROUND 4(IN CASE OF TIE): <br>
1.In case of a tie after the 3th round, the tied teams get into a buzzer/bell<br>
Round &Rules are similar to general round.<br>
2.If a team answer right they get 10 points. If they answer wrong they get
minus 10 points.<br><br><br>

<b>DISCLAIMER:-</b><br>
• In case of ambiguity, the decision of the judges would be considered final.<br>
• If any team found misleading the organizer or using unfair means to win, organizer
reserves the right to disqualify the team at any stage of the event.<br>
• Organisers hold the right to make changes in the event structure during the event<br><br>

ENTRY FEE –₹40/Group of 2 <br>
PRIZES :-    WINNER-₹1000<br>
                     1ST RUNNER UP- ₹500<br>
                     2ND RUNNER UP -₹300<br>




       <b>Co-ordinator Details:-</b><br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
       <p>SMRUTI RANJAN DAS <a href="tel: 7978636456"> 7978636456</a></p>
      <p> SHUBHANJALI  UPADHYAYA <a href="tel: 7008509833"> 7008509833</a></p>
      <p>YUVRAJ SAHU <a href="tel:8249143391">8249143391</a></p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">MOVING ON UP  </h4>
      <div class="modal-body">
      
        <b>  Description:-</b>
      <p>A game that asks player to be a little ambidextrous as they alternate hands to build a tall stack of cups. Played by a group of 2, as a race in teams.</p>
       <b>Criteria:-</b>
      <p>1.	This is a group event.<br>
2.	A group of 2 are allowed to participate.<br>
3.	Every group will be provided with a balloon and cups.<br>
 </p><br>

      <b>Rules and regulation:-</b>
      <p>1.	There will be plastic cups kept on the table. Participant 1 has to blow the balloon and expel the air out of it so that it blows the cups off the edge of table.<br>
2.	At that time, participant 2 has to pick up the cups and make a stack of the cups with a particular marked cup at the bottom of the stack.<br>
3.	Then he/she has to move one cup from bottom of stack and move it to the top using one hand and then should repeat the process with other hand. The hands are alternated to move all the cups until the marked cup is back in its place at the bottom of the stack.<br>
4.	The team that completes the task in shortest interval of time will be declared as winner.<br>
5.	Participants will only start the task once the timer is started.<br>
</p><br>
ENTRY FEE –₹30/group of 2<br><br>
         PRIZES :-    WINNER-₹1000<br>
                             RUNNER UP- ₹500<br><br>



       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SMARANIKA NAYAK  <a href="tel:+7683825091">7683825091</a></p>
      <p>GOURAV PING <a href="tel:+6370397917">6370397917</a></p> </p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal3" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">Paper Presentation</h4>
        <div class="modal-body">
            
      <b>  Description:-</b>
      <p>You can present your paper on any topic related to your research on the advancement in technologies or on any such topic which needs to be understood by the mankind for its benefits.<br><br>

 Bring your college I-Card & receipt on event day<br><br>

Please bring your PowerPoint presentation on a pen-drive.<br><br>

Please Mail your abstract, paper and ppt to <a href = "mailto: bidyuttam@gmail.com">bidyuttam@gmail.com</a>  <br><br>

The participants will get 10 minutes for presentation followed by question and answer session.<br><br>

The mail with submissions should contain:<br><br>
Title- theme of the paper.<br><br>
Name of the author .<br><br>
Phone no of the author<br><br>
E- mail ID .<br><br>

Paper must contain index, abstract, introduction, point wise description of subject and conclusion and references.<br><br>

Last day to submit soft copy of your report (via e-mail or at college) will be one day prior to the day of presentation.<br><br>

The decision of judges will be final and no arguments or appeal will be entertained.<br><br>
 </p><br>
     ENTRY FEE – Free<br>
     <p>PRIZES</p>
       -  winner- ₹500 <br>

       <b>Co-ordinator Details:-</b><br>
       
         <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SANJEEB DEHURY <a href="tel:6372484098">6372484098</a></p>
      <p>Pawan Gupta <a href="tel: 7905245916">7905245916</a> </p>

      
       <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal4" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">BATTLE OF CODERS </h4>
        <div class="modal-body">
            
      <b>  Description:-</b>
      <p>The most awaited event for which coders prepare to fight on the battlefield. Brush up your maths and algorithm skills for the coding contest that will have questions you can’t stop thinking of.</p>
 
      <b>Rules and regulation:-</b>
      <p><u>Round 1: Debugging (Elimination round)</u><br><br>
1.	It is a group event where only two students can participate in each group.<br>
2.	A set of 30 questions will be given, which includes blanks filling, MCQS, logical and syntactical errors.<br>
3.	Total point will be evaluated upon the correctness of the submitted answer.<br>
4.	Questions will be given in C++,C ,JAVA language .<br>
5.	Top FIVE groups will be selected for the next round i.e. Final round.<br>
</p>

<u>Round 2: Blind Coding (Final round)</u><br><br>
1.	This is an individual event.<br>
2.	The program statement of lower to medium complexity will be given.<br>
3.	Each participant has to write the code with MONITORS OFF.<br>
4.	Participants whose all the code gets executed will be awarded first prize.<br>
5.	The second and third prize will be given to the code with least number of errors .<br>
6.	In case of tie in the number of errors, then timing will be considered.<br><br>

ENTRY FEE-RS 50/- (group of two) <br><br>
PRIZES :-    WINNER-₹1000<br>
                     1ST RUNNER UP- ₹500<br>
                          2ND RUNNER UP -₹300<br>


       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SOURAV KUMAR NAYAK <a href="tel:7377673921">7008624044</a></p>
      <p>A. NAG LOKESH <a href="tel: 8328872025">8328872025</a> </p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal5" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">TRIVIA JUNKIES </h4>
        <div class="modal-body">
           
      <b>  Description:-</b>
      <p>Unlock your Bollywood knowledge at the speed of thought as the quizmaster asks you brainstorming questions related to the Bollywood industry.</p>
      <b>Criteria:-</b>
      <p  style="color: red;">All students are eligible for TRIVIA JUNKIES except 4th year Electrical students. </p>

      <b>Rules and regulation:-</b>
      <p>1.	Only team entries are eligible.<br>
2.	A team shall consist of  two persons.<br>
3.	The competition shall be consisting of 4 Rounds<br>
4.	The decision of the quiz-master will be final and will not be subjected to any change.<br>
5.	The participants shall not be allowed to use mobile or other electronic instruments.<br>
6.	The questions shall be in the form of multiple choice, True / False statement, Specific-answer question etc. for round-1.<br>
7.	Audience shall not give any hints or clues to the competitors.<br>
8.	Replacement of any participant of a team is not allowed after registration.<br>
 </p><br><br>

   <b><u>Elimination Round</u></b><br>
   1.	Each team would be given a set of question paper containing 20 multiple choice objective type questions. <br>
2.	1 mark for each correct answer and ¼ negative marks for wrong answer.<br>
3.	Time limit for each round-15 minutes.<br>
4.	Only 4 Teams would be selected for final rounds.<br>
5.	In case of tie between 2 or more teams, further 5 questions would be asked for final selection.<br><br>

ENTRY FEE –₹30/Group of 2<br>
         PRIZES :-    WINNER-₹500 + 2 Movie Ticket<br>
                    1ST RUNNER UP- ₹200 + 2 Movie ticket<br>
                     2ND RUNNER UP - 2 Movie Tickets<br><br>

    <b style="color:FC502B"> War Movie Ticket 1st Day 1St Show </b> <br><br>

       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SANTIPRAKASH NAYAK <a href="tel:7377673921">7377673921</a></p>
      <p>SMRUTI RANJAN SAMAL    <a href="tel:8917246796">8917246796</a> </p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal6" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;">BUSCAR TESORO  </h4>
        <div class="modal-body">
          
     <b>  Description:-</b>
      <p>Team uses their collective brainpower to solve clues which will lead you to the treasure. Come and join us to make much better stories as there is treasure at the end.</p>
      <b>Criteria:-</b>
      <p>1. The participants should be a student of GCE KJR or any institutions.<br>
  2. Proper identification is required for the participants belonging to their institutions. Hence    
    Participants must have their I’d Card for the entry to the event.  <br>    

3. Both online and offline registrations are available.  <br>    
 </p><br>

      <b>Rules and regulation:-</b>
      <p>1.	The theme of the game will be disclosed later on the spot.<br>
2.	There will be a written qualifying round which consists of riddles on given theme.<br>
3.	Not more than 5 players will be allowed in a group.<br>
4.	There will be multiple clues on several stages which will lead the team to the Treasure Box. The “TOP TEAMS (will be declared on spot) WHICH WILL COLLECT THE TREASURE BOX AFTER SUCCESSFUL SOLVING OF CLUES” will be promoted to stage 2 and remaining others will get eliminated. <br>
5.	Hence, on every stage participants need to collect and solve the clues in right time so that they can reach to treasure Box earlier and they can avoid elimination.<br>
6.	Every TREASURE BOX contains CLUES which will lead to TREASURE BOX for next stage and the procedure follows for given stages.<br>
7.	The team which approaches judges must have all the proper clues and Treasure box otherwise their team will be disqualified.<br>

<b>*Time duration for each round will be notified on spot.</b>
</p><br>

<b>NOTES: TOP TEAMS- Number of teams eligible for qualifying stages<br>
               For Ex: If there are 5 teams having same clues and there is only 2 Treasure Box <br>
Provided then the top 2 teams will be eligible for stage 2 and rest 3 teams will be eliminated.</b><br><br>

Entry fee- Rs.75/group of 5 <br>                   
Prize: 1st – Rs.700<br>    
2nd – 500<br>
The prize money may vary according to no of participants (Terms & Condition Applied)<br><br>



      <b>Co-ordinator Details:-</b>
      <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SAURABH KUMAR <a href="tel:7008336050">7008336050</a> </p>
      CHIRANJEEBI MANSINGH  <a href="tel:7381190311">7381190311</a> <br><br>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal7" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;">PATT SE HEADSHOT  </h4>
        <div class="modal-body">
            
      <b>  Description:-</b>
      <p>If you’re a maniac obsessed with “Enemies ahead, I got some life, Winner Winner Chicken Dinner” then its time for you to showcase your extra ordinary skills and strategic planning to beat your opponents and be the last person standing to be christened as the winner.</p>
      
   <b>Rules and regulation:-</b> 
      <p>So before going anywhere please go through the rules carefully:<br>
The GAME will be basically in 3 modes:<br>
1.	SQUAD<br>
2.	DUO<br>
3.	TDM (TEAM DEATHMATCH)<br>
 SQUAD:<br>
•	Each squad will be basically of 4 players.<br>
•	Winner will be decided not only by position i.e. not only by CHICKEN DINNER.<br>
•	**Moreover rules are:<br>
1.	The squad who will be in position 1 will get 100 points.<br>
2.	The squad who will finish 2nd will get 98 points.<br>
3.	The squad who will be in 3rd position will get 96 points.<br>
4.	Likewise , the 25th  positioned squad will have 52 points.<br>
5.	For each kill each squad will be awarded 5 points.<br>
For Example, If a squad finishes in position 1 with 8 kills then the overall points for that squad will be:<br>
100(for position) + 5*8(for total kills) = 100+40 = 140.<br>
Similarly, it goes on for all other squads.<br>
	If total number of squads will be more than 25 then top 10 squads from each room will be selected.<br>
	Then a final room will be created to find the winner on the basis of above mentioned rules.**<br>

DUO:<br>
•	Each squad will be basically of 2 players.<br>
•	As Like the squad, Winner will be decided not only by position i.e. not only by CHICKEN DINNER.<br>
•	**Moreover rules are:<br>
	The squad who will be in position 1 will get 100 points.<br>
	The squad who will finish 2nd will get 98 points.<br>
	The squad who will be in 3rd position will get 96 points.<br>
	Likewise , the 25th  positioned squad will have 52 points.<br><br>
	For each kill each squad will be awarded 5 points.<br>
For Example, If a squad finishes in position 1 with 8 kills then the overall points for that squad will be:<br>
100(for position) + 5*8(for total kills) = 100+40 = 140.<br>
Similarly, it goes on for all other squads.<br>
	If total number of squads will be more than 25 then top 10 squads from each room will be selected.<br>
	Then a final room will be created to find the winner on the basis of above mentioned rules.**<br>
TDM (TEAM DEATHMATCH):<br>
•	Each squad will have four players.<br>
•	First 16 registered squads will be allowed to play the game.<br><br>
•	Rules for TDM are:<br>
1.	As in each match two squads will play against each other<br>
2.	The team which will win gets qualified for next round.<br>
3.	The matches will be like a KNOCKOUT match.<br>
Note: For Each TDM match, each team must bring/have a room card of their own.  
 </p><br>

 


       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>DIBYA RANJAN NAYAK <a href="tel:7735588183">7735588183</a> </p>
      <p>PRASANJEET PRADHAN <a href="tel:9776999491">9776999491</a></p>
       <p>ABHISHEK PATRA <a href="tel:7504836535">7504836535</a></p>
        

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal8" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">KNIGHT- X-WING  </h4>
        <div class="modal-body">
            
             <b>  Description:-</b>
      <p>Be the best out of the rest. Shatter your enemies on the battlefield with the touch of your finger and claim the crown of strongest challenger.</p>
       <b>Criteria:-</b>
      <p>First 16 teams registered will be able to participate.<br>
Each team will have max 5 players.<br>
 </p><br>

      <b>Rules and regulation:-</b>
      <p>No map hack<br>
- No mod apk<br>
- Bring your own teammates<br>
- Two squads will play against each other<br>
- Winner will be qualified for the next match and the losing team will be out of league.<br>
</p><br>

      <b>Co-ordinator Details:-</b>
      <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>MAHESH RANJAN RATH <a href="tel:7008939037">7008939037</a></p>
      <p>RAJU HANSDAH <a href="tel: 9439797685"> 9439797685</a></p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal9" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;">KREATIONZ </h4>
        <div class="modal-body">
          
            <b>  Description:-</b>
      <p>Odisha is known for its Arts and artistic people. Here is a chance to show your creativity among thousands of students using literary words and create magical spell with your poems.</p>
      <b>Criteria:-</b>
      <p>1. Participant need to choose one of the three languages i.e (Odia, English, Hindi).<br>
2. Duration of the event is 60 mins . And the topic will declared before 15 mins on the spot.<br>
3. There will be 2 choices in every language.<br>
4. Participant should come with a pen . Paper will be provided by the event organizers.<br>
 </p><br>

      <b>Rules and regulation:-</b>
      <p>1 .Mobile is strictly prohibited during the event.<br>
2. NO GROUP/TEAM is ALLOWED .<br>
3. A poem in its entirety must be an original work by the person entering the event .<br>
 </p><br>

 ENTRY FEE –₹20/person<br><br>
PRIZES :-    WINNER-₹700<br>
                     1ST RUNNER UP- ₹400<br>
                    2ND RUNNER UP -₹300<br><br>


       <b>Co-Ordinator details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SUBHASHREE SWAIN  <a href="tel:8596842011">8596842011</a></p>
      <p>SMARANIKA NAYAK   <a href="tel: 7683825091"> 7683825091</a></p>   </p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal10" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <h4 style="color: red; text-align: center;">POLEMICZNY</h4>
        <div class="modal-body">
           <b>  Description:-</b>
      <p>Political acumenship and courage might be crucial for a parliamentarian but ideological fierce oratory is the trademark. So, are you a good orator? Then come, articulate and receive commendations. Introducing Polemiczny, prove yourself as an enchanting speaker.</p>
     <b>Criteria:-</b>
      <p>Indivisual Participation and indivisual marking . Teams will be chosen at the spot.<br> HERE THERE WILL BE TWO PARTIES, ONE IS RULING AND OTHER IS OPPOSITION PARTY. LEGISLATIVE PROPOSALS ARE BROUGHT BEFORE THE HOUSE OF PARLIAMENT IN THE FORM OF A BILL , AND THOSE BILLS ARE GETTING PASSED FROM THE HOUSES TO FORM THE RULE. IN POLEMICZNY , WE WILL SIMULATE THE SAME PROCESS THAT IS BILL WILL BE PRESENT BY THE RULLING PARTY, DISCUSSION OVER IT AND FINALLY VOTING FOR THAT BILL.
 </p><br>

      <b>Rules and regulation:-</b>
      <p>1.  MUST PRESENT AT THE VENUE BEFORE 15MINS SO THAT THE EVENT WILL START WITHOUT ANY DELAY.<br>
2.  LATE COMERS WILL NOT BE ALLOWED TO ENTER THE EVENT .<br>
3.  DECORUM OF PARLIAMENT MUST BE MAINTAINED . ANY VIOLATION OF DECORUM INSIDE THE PARLIAMENT WILL LEAD TO THE TERMINATION OF THAT CANDIDATE FROM THE EVENT . <br>
4.  CANDIDATES CAN USE HINDI , ENGLISH AND ODIYA IN THE PARLIAMENT DURING THE DISCUSSION. <br>
5.  NO ONE SHOULD ARGUE WITH MADAM SPEAKER OR ANY OF THE COORDINATORS DURING THE SESSION.<br>
6.  TOPIC WILL BE SELECTED ON THE SPOT .<br>
7.  LEADERS OF THE RULING AND OPPOSITION PARTY WILL BE SELECTED ON THE SPOT BY THE COORDINATORS. (INTERESTED CANDIDATES SHOULD COME FORWARD AND APPROACH TO THE EVENT COORDINATORS BEFORE THE COMMENCEMENT OF THE EVENT)<br>
8.  A DEMO WILL PRESENTED BEFORE THE COMMENCEMENT OF THE SESSIONS.<br>
9. FURTHER RULES WILL BE NOTIFIED DURING THE EVENT BY THE RESPECTIVE COORDINATORS.<br></p><br>
   POLEMICZNY
ENTRY FEE –₹20/person<br>
PRIZES :-    WINNER-₹1000<br>
                      RUNNER UP- ₹600<br><br>

       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>TAPASWANEE SAHOO <a href="tel:7978671151"> 7978671151</a></p>
      <p>SHUBHRANSHU KUMAR SETHI <a href="tel:8588946276"> 8588946276</a> </p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re -directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box.  </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal11" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <h4 style="color: red; text-align: center;">CIRCUIT SCRAMBLE</h4>
        <div class="modal-body">
           
             <b>  Description:-</b>
      <p>Who said only coders can debug? Doctors can debug patients and mechanicals can debug engines. So, its turn of electricals to debug and prove themselves. Presenting Circuit Scramble, where electricals prove their debugging power.</p>
       <b>Criteria:-</b>
      <p>1)	Maximum 2 members allowed in a team.<br>
2)	The number of rounds will be decided based on the number of participants.<br>
3)	Multiple choice question.<br>
 </p><br>

 


      <b>Rules and regulation:-</b>
      <p>1)	Usage of mobile phone and any other electronic gadget will be not allowed in the compotation.<br>
2)	Preliminary round will be a MCQ round in which team will get a single question paper of 30 questions to be solved in 30 minutes.<br>
</p><br><br>
Entry fee: - Free<br>
Prize: -<br>
               1st –  600<br>
               2nd – 400<br>
               3rd – 300<br>

       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>BIRANCHI NARAYAN SAHOO <a href="tel:7978222370"> 7978222370</a> </p>
      <p>SHIVASHANKAR BADAPANDA <a href="tel:8763573593">8763573593</a></p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal12" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
             <h4 style="color: red; text-align: center;">MEMORONICS</h4>
            
       <b>Criteria:-</b><br>
      <p>1. Its a solo event.<br>
2. Only registered participants will be allowed to take part.<br>
3. As its based on your response timing,therefore participants are informed to be present 15mins prior to the starting of the event.<br>
4. Anyone can participate of any class,any stream but must carry a valid Identity Card of School/College.<br>

      <b>Rules and regulation:-</b>
      <p>There will be two rounds.<br>

First round:-<br>
We will show you few slides of some daily life used materials.You have to memorise them and them write all the names down on a paper. <br>

Top 10 participants will be qualified for the next round.<br>

Round Two:-<br>
We will show you 20slides with some information written on each slide.You have to memorise the data mentioned and them answer the questions given to you .<br>

The top 3participants who gets the maximum correct within shortest span of time become the winners.<br>

+1 - For each correct answer<br>
-1 - For wrong answer.<br><br>

ENTRY FEE –₹20/Person<br>
PRIZES :-    WINNER-₹800<br>
                     1ST RUNNER UP- ₹500<br>
                     2ND RUNNER UP -₹300<br><br>


      <b>Co-ordinator Details:-</b>
      <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SOURAV KUMAR DAS  <a href="tel: 7978775770">  7978775770</a></p>
      <p>BIRANCHI NARAYAN SAHOO  <a href="tel: 7978222370"> 7978222370</a> </p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal13" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
           <h4>SNAP- IT </h4>
            <b>  Description:-</b>
      <p>Stop walking dead as a zombie. Cheer up!! Find something that you are excited about in your life. Put the perfect expressions on your face and let the people say Best Selfie Ever.</p>
      <b>Criteria:-</b>
      <p>1. Its a solo event.<br>
2. Only registered participants will be allowed to take part.<br>
3. Participants are informed to be present 15mins prior to the starting of the event.
4. Anyone can participate of any class,any stream but must carry a valid Identity Card of School/College. </p><br>

      <b>Rules and regulation:-</b>
      <p>1.selfie should be taken by your own phone camera<br>
2.No app or filter will be used.<br>
3.There will be 3 rounds and points should be added<br>
   To each tasks in the respective round.<br>
4.Time duration for this event will be given in the spot.<br>
</p><br>

ENTRY FEE –₹20/person<br>
PRIZES :-    WINNER-₹800<br>
                     1ST RUNNER UP- ₹500<br>
                     2ND RUNNER UP -₹300<br><br>


       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>ARUNDHATI MALLICK <a href="tel:+7008941142">7008941142</a> </p>
      <p>PRIYANKA PATRA <a href="tel:+8637225449">8637225449</a>  </p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal14" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">VOGUE ZENITH </h4>
        <div class="modal-body">
             <b>  Description:-</b>
      <p>If you believe you are raw, real and stylish, then live in the moment and go beyond to explore. Make every second count and show the world what you got by promoting yourself from a bedroom singer to a famous tiktoker.</p>
       <b>Criteria:-</b>
      <p>1. Contestants should be a student of GCE or any invited college and school.<br>
2. No outsiders are allowed without a valid Identity Card of Their college.<br>
2. Only resistered students will be allowed to participate.<br>
</p><br>

      <b>Rules and regulation:-</b>
      <p>1. Video should be shooted in TikTok app.<br>
2.. The same contestants will remain in the same video.<br>
3. For a single round only one video will be taken.<br>
4. The video should be shooted in a safe place.<br>
5. There will be 3 rounds-<br>
     &nbsp &nbsp &nbsp &nbsp &nbsp - First round is any dialogue or comedy of Bollywood.<br>
     &nbsp &nbsp &nbsp &nbsp &nbsp  - Second round is Transition with promo.<br>
      &nbsp &nbsp &nbsp &nbsp &nbsp - Last round is Innovative.<br>
* Time duration for these videos will be given on the spot.
</p><br>

   ENTRY FEE –₹30/person<br> 
     PRIZES :- WINNER- GIFT<br>
            1ST RUNNER UP- GIFT<br>
                     2ND RUNNER UP -GIFT<br>


       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>PRAJNA PARAMITA PRADHAN <a href="tel:+7978286055">7978286055</a> </p>
      <p>SWARAJ BIBHUPRASAD ACHARYA <a href="tel:+7751839360">7751839360</a>  </p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal15" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <h4 style="color: red; text-align: center;">THE HUNARBAAZ </h4>
        <div class="modal-body">
           
            <b>  Description:-</b>
      <p>Do what makes your soul shine. Empower your creative talent within 2minutes to build a credible identity as an artist. Get discovered and earn star status in a new way.</p>
      <b>Procedure:-</b><br>
      <p>There will be 2 rounds in this competition.<br>
1st Round - <br>
Participants can perform anything(as per the rules n regulations) of their interest in the time limit of 2 mins.<br>
There will be selection of participants from the 1st round.<br>
2nd Round - <br>
Selected students of 1st round will be given a topic according 2 their respected activities performed in 1st round by the judges n will be judged accordingly.</p><br>

      <b>Rules and regulation:-</b>
      <p>1. The activities should be strictly indoor within a specified room.<br>
2.No vulgar content to be entertained <br>
3.Not 2 create embarassing situation<br>
4. No offending languages or contents will be entertained.<br>
5.Proper decorum should be maintained in the room n participants should behave properly with d coordinators .<br>
6.Participants must bring their own instruments or accessories.<br>
Any participating violating the rules n regulation will be disqualified. </p><br><br>

ENTRY FEE –₹20/person<br>
          –₹30/group of 2 <br><br>
PRIZES :- WINNER-₹1000<br>
         RUNNER UP- ₹500<br><br>


       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>A. NAG LOKESH <a href="tel:8328872025 ">8328872025 </a>    </p>
      <p> SAMEEKSHYA AICH </p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal16" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;">RAZSTAVA</h4>
        <div class="modal-body">
     The Space for interaction and exploration , a tasting menu  for creative art,craft and paintings. An invitation to dream bigger and showcase your unique creativity.Participants can display their art,crafts and paintings. The best one most liked by visitors will recieve exciting prizes and felicitations.<br><br>

       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>Rudra Prasad das <a href="tel:9090539869 ">9090539869 </a>  </p>
      <p>Ajit kumar patra <a href="tel: 9938685576 "> 9938685576 </a></p>

      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re -directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal17" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;" >ROBO LABORATORIO</h4>
        <div class="modal-body">
            <b>  Description:-</b>
      <p>Robotics and automation have become the focal point for industries to shake the workplace of tomorrow. The curiosity and inquisitiveness has increased. For this very reason come to Vidyuttam where our students exhibit their robotics skills creativity and innovation from their out-of-the-box thinking.</p>
     

      <a href="raw death race.pdf" download="T&C Of Robo">Download Rules And Regulation PDF</a><br><br>

  ENTRY FEE – with Personal Bots ₹500/ Group Of 4 <br>
          –with Our Bots (Hiring) ₹600/ Group Of 4 (*T&C) <br>
          –  <b>Arena Will be reveled on 24th sept 2019.</b><br><br>
<b>PRIZES</b> :- <br>WINNER-₹5000<br>
         RUNNER UP- ₹2000<br><br>
     

       <b>Co-ordinator Details:-</b>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      <p>SOURAV KUMAR NAYAK <a href="tel:7008624044 ">7008624044 </a> </p>
      <p>KUMAR GOURAV <a href="tel:8917239911 ">8917239911 </a> </p>

      <b>How to Register:-</b>
     <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  <div class="modal fade" id="myModal18" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;" >PAPER DANCE</h4>
        <div class="modal-body">
            <b>  Description:-</b>
      <p>Tune your compatibility and balance with your friend with beats of music on sheet of paper. The team which can endure the difficult and diminishing sheet till the end wins the game.</p>
      <b>Criteria:-</b><br>
       -It is a group event .<br>
       -Two adults can participate.<br>
 </p><br>

      <b>Rules and regulation:-</b><br>
             - There will be Scattered sheets of newspapers on the floor and participants have to step  on them in pairs.<br>
       -With the music on dance for a minute or two on the paper.<br>
       -The team will be out of the game if any person steps on the floor.<br>
- After a minute, the music will stop and then fold the paper into half.<br>
<br>

       ENTRY FEE –₹40/group of two<br>
  PRIZES :-    WINNER-₹1000<br>
                      RUNNER UP- ₹750<br><br>



       <b>Co-ordinator Details:-</b><br>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      Smruti ranjan das  <a href="tel:7978636456 ">7978636456</a>    <br>  
      SAMBIT KUMAR BEHERA   <a href="tel: 9776530316 "> 9776530316</a> <br><br>


      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

    <div class="modal fade" id="myModal19" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;" >Group Discussion</h4>
        <div class="modal-body">
            <b>  Description:-</b>
      <p>A discussion group is a group of individuals, typically who share a similar interest, who gather either formally or informally to discuss ideas, solve problems, or make comments.</p>
      <b>Criteria:-</b><br>
       1. Its a solo event.<br>
2. Only registered participants will be allowed to take part.<br>
3. Participants are informed to be present 15mins prior to the starting of the event.<br>
4. Anyone can participate of any class,any stream but must carry a valid Identity Card of School/College.<br>
 </p><br>

       ENTRY FEE –₹20/ Person<br>
  PRIZES :-    WINNER-₹800<br><br>

      <b>Rules and regulation:-</b><br>
            1.There will be topic based,case based or Article based Good discussion.<br>

2.In the heat of the moment dont lose your control of speech and decency. You are there to share your point of view and not to start an argument. Respect others views and do not try to dominate your views or point<br>

3.The winners will be decided on the basis of :-<br>
-How you behave and interact with a group?<br>
-How open minded are you?<br>
-Your listening skill,leadership and decision-making skills<br>
-How you put forward your view<br>
-Your analysis skill , subject knowledge, problem solving and critical thinking skill.<br>
-Your attitude and confidence<br><br>

      


       <b>Co-ordinator Details:-</b><br>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
      SOURAV KUMAR DAS  <a href="tel:7978775770  ">7978775770 </a>    <br>  
      TAPASWANEE SAHOO   <a href="tel: 7978671151  "> 7978671151 </a> <br><br>


      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

      <div class="modal fade" id="myModal20" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
       <h4 style="color: red; text-align: center;" >V-MART FASHION GALA</h4>
        <div class="modal-body">
            <b>  Description:-</b>
      <p>Fashion is a popular aesthetic expression in a certain time and context, especially in clothing, footwear, lifestyle, accessories, makeup, hairstyle and body proportions. Whereas, a trend often connotes a very specific aesthetic expression, and often lasting shorter than a season, fashion is a distinctive and industry-supported expression traditionally tied to the fashion season and collections.</p>
      <b>Criteria:-</b><br>
       1. Its a solo event.<br>
2. Only registered participants will be allowed to take part.<br>
3. Participants are informed to be present 15mins prior to the starting of the event.<br>
4. Anyone can participate of any class,any stream but must carry a valid Identity Card of School/College.<br>
 </p><br>


      <b>Rules and regulation:-</b><br>
        
      ENTRY FEE –₹30/person<br><br>
PRIZES :-    WINNER- ₹800 + VMART 20% DISCOUNT COUPON<br>
                     1ST RUNNER UP- ₹500 + VMART 20% DISCOUNT COUPON<br>
                          2ND RUNNER UP - ₹300 + VMART 20% DISCOUNT COUPON<br><br> 
      


       <b>Co-ordinator Details:-</b><br>
       <br>
       <b>For Any Query Related to this event Feel Free to Contact Us</b>
   PRAJNA PARAMITA PRADHAN <a href="tel:7978286055  ">7978286055 </a>    <br>  
   GAYATRI SAHOO    <a href="tel:7008452923   "> 7008452923  </a> <br><br>


      <b>How to Register:-</b>
      <p>Once you click on Register, it will be re-directed to the google form. Fill the required information and select the events you are interested to participate .Pay the registration fees as per your convenience . If you  are paying online then take the screenshot of the payment receipt and upload it in the given box. </p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

  