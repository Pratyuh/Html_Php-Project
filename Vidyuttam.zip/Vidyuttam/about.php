  <!--==========================
      About Us Section
    ============================-->
    <section id="about">
      <div class="container">

        <header class="section-header">
          <h3>About Us</h3>
          
        </header>
         <h4>OBJECTIVE</h4>
            <p class="" style="text-align: justify;">
            To showcase the technical knowledge and expertise focused to expose the future engineers and their role in tomorrow’s world. It exemplifies the knowledge of students and exhibits their technical brilliance. The fest is born with one goal in mind “together we make a difference to create and sustain a society of bright inquisitive minds”, who intend to learn and innovate by interacting with each other. The tech fest spread over a span of two days, will project the ideas from students of various institutes, encouraging and challenging them in a competitive manner.<br><br>

            <b>Guest Lecturers:-</b><br>
        Prof. Chandrasekhar Bhende (IIT Bhubaneswar)<br>
        Prof. Alok  Kanti  Deb (IIT Kharagpur)

        <h4>ABOUT GCE</h4>
        <p style="text-align: justify;">GOVERNMENT COLLEGE OF ENGINNERING, KEONJHAR stands in pride and honor imparting the true colours of learning and wisdom. Established in year 1995, it is only the Government College providing Engineering and Technical education in North Odisha. Government of Odisha declared it as a full- fledged Government Engineering College in the Year 2011 observing its rising excellence and potentiality in growth. It has been moving forward on the paths that don’t compromise any efforts to satisfy the students’ interest.</p>
        </p>

        <h4>ABOUT ELECTRICAL ENGINEERING </h4>
        <p style="text-align: justify;">Established as one of the major departments of the institute, since 1997, the department of Electrical engineering is actively engaged in teaching and research. With modern laboratories and excellent faculty members ,the department offers 4-year B.Tech course study which includes fundamentals of Electrical Engineering embedded with Electrical Machines, Power System, Power Electronics, Control, Electronics, Communication, Signal processing and Artificial Intelligence. Both simulation and experimental based projects are encouraged to create a research ambience among the undergraduate student community.</p>
         <h3 >REGISTRATION</h3>
          <p style="text-align: justify;">For all the Participants <i><b>Outside The Town</b></i>, need to register and pay ₹​200 which will include accomodation facility along with four Meals. If the Participant Attends The Guest Lectures On Both The Days then they will be provided a separate certificate Signed By Our Guest Lectures. </p> <b>For Any Query Contact Sourav Kumar Nayak <a href="tel:7008624044">7008624044</a></b><br><br><br>


          <center><a href="https://docs.google.com/forms/d/e/1FAIpQLSdJKxxrECUcjilKykhfRKU1oRBK9wzy3NFtx8pXBmdJbUT-RQ/viewform?usp=sf_link" target="_blank"> <button style="text-decoration: none;  background-color: #4CAF50; border: none; color: white; padding: 15px 32px;  display: inline-block;font-size: 16px; margin: 4px 2px; cursor: pointer; ">Register Now</button></a></center>
       

      </div>
    </section><!-- #about -->