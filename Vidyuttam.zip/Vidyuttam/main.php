<?php include "header.php"; ?>
<?php include "intro.php"; ?>
<?php include "service.php"; ?>
<?php include "about.php"; ?>
<?php include "portfolio.php"; ?>
<?php include "client.php"; ?>
<?php include "footer.php"; ?>

    
   
  
 




