<!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">
            <h3>VIDYUTTAM 1.0</h3>
            <h6>Government College Of Engineering, Keonjhar</h6>
                    <p style="text-transform: uppercase; ">THIS FEST WILL BE HELD ON 27<sup>th</sup> AND 28<sup>th</sup> September,2019 ORGANISED BY INNOVATORY ELECTRICAL SOCIETY .</p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><a href="#">Home</a></li>
              <li><a href="#about">About us</a></li>
              <li><a href="#services">Events</a></li>
              
            
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <u>Convener:-</u><br>
                  Prof. Rakesh Rajan Shukla<br>
                <strong>Email:</strong> <a href = "mailto:  rakeshshukla_fee@gcekjr.ac.in" style="text-decoration: none; color: #fff">   rakeshshukla_fee@gcekjr.ac.in</a> <br>
                  <u>Co-Convener:-</u><br>
                  Prof. Yogesh Kumar Nayak<br>
                  <strong>Email:</strong> <a href = "mailto:  yogeshnayak_fee@gcekjr.ac.in" style="text-decoration: none; color: #fff">  yogeshnayak_fee@gcekjr.ac.in</a><br><br><br>
                  
                
              
              
              <strong>Email:</strong> <a href = "mailto: bidyuttam.gce@gmail.com" style="text-decoration: none; color: #fff"> bidyuttam.gce@gmail.com</a><br>
            </p>

            <div class="social-links">
              <a href="https://www.facebook.com/vidyuttam1.0/" class="facebook" target="_blank"><i class="fa fa-facebook"></i></a>
              <a href="https://www.instagram.com/vidyuttam1.0/?r=nametag" class="instagram" target="_blank"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus" ><i class="fa fa-google-plus"></i></a>
            </div>

          </div>

          <div class="col-lg-3 col-md-6 footer-newsletter">
            <h4>Our Co-ordinators</h4>
                  BIRANCHI NARAYAN SAHOO <br>
                  <strong>Phone:</strong><a href="tel: 7978222370"> 7978222370</a><br>
                  SOURAV KUMAR NAYAK <br>
                  <strong>Phone:</strong><a href="tel:7008624044">7008624044</a><br>
                   SMRUTI RANJAN DAS<br>
                  <strong>Phone:</strong><a href="tel:7978636456">7978636456</a><br>
                   SHUBHANJALI UPADHYAYA<br>
                  <strong>Phone:</strong><a href="tel:7008509833">7008509833</a><br>
                   SOURAV KUMAR DAS<br>
                  <strong>Phone:</strong><a href="tel:7978775770">7978775770</a><br>
           
          </div>

        </div>
      </div>
    </div>

  
      <div class="copyright">
       © 2019 || All Rights Reserved.
                 Design By Ajit and Pratyush || Creativity By Suvendu 
                 <br> Mob: <a href="tel:7077079340">7077079340</a>
      </div>
     
    
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/mobile-nav/mobile-nav.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="lib/isotope/isotope.pkgd.min.js"></script>
  <script src="lib/lightbox/js/lightbox.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

<script>
    $(document).ready(function() {
        function getTimeRemaining(endtime) {
            var t = Date.parse(endtime) - Date.parse(new Date());
            var seconds = Math.floor((t / 1000) % 60);
            var minutes = Math.floor((t / 1000 / 60) % 60);
            var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
            var days = Math.floor(t / (1000 * 60 * 60 * 24));
            return {
                'total': t,
                'days': days,
                'hours': hours,
                'minutes': minutes,
                'seconds': seconds
            };
        }

        function initializeClock(id, endtime) {
            var clock = document.getElementById(id);
            var daysSpan = clock.querySelector('.days');
            var hoursSpan = clock.querySelector('.hours');
            var minutesSpan = clock.querySelector('.minutes');
            var secondsSpan = clock.querySelector('.seconds');

            function updateClock() {
                var t = getTimeRemaining(endtime);

                daysSpan.innerHTML = t.days;
                hoursSpan.innerHTML = ('0' + t.hours).slice(-2);
                minutesSpan.innerHTML = ('0' + t.minutes).slice(-2);
                secondsSpan.innerHTML = ('0' + t.seconds).slice(-2);

                if (t.total <= 0) {
                    $('#clockdiv').hide();
                    $('#hide-p').html('Registration started for events.');
                    $(".complete-timer").html("Event Started");
                    
                }
            }

            updateClock();
            var timeinterval = setInterval(updateClock, 1000);
        }

        var deadline = new Date(Date.parse(new Date()) + 9 * 24 * 60 * 60 * 1000);
        initializeClock('clockdiv', deadline);
    });
</script>
