 <!--==========================
    Intro Section
  ============================-->

  <section id="intro" class="clearfix">
    <div class="container">
      <marquee  width="100%" behavior="alternate"  direction="right" height="100px">
        <h3 style="color: #fff; size: 20px; font-weight: 20px;">Sponsored By TEQIP III</h3>
        </marquee>
      <div class="intro-img">
        <img src="img/i.png" alt="" class="img-responsive careerpage">
        <img src="img/bi.png" alt="" class="img-responsive careerpage mobile">
        
      </div>

      

      <div class="intro-info">
        
        <h2>Welcome to <blink>VIDYUTTAM 1.0</blink> </h2>
        <h4 style="color:#fff">(27th & 28th Sept. 2019)</h4>
        <p style="color: #fff; text-align: justify;">Vidyuttam 1.0 is a National Techno Cultural Fest organised by Electrical Department of Government College Of Engineering, Keonjhar.
New Beginnings. Endless Possibilities.</p>
        <div>
          <a href="#about" class="btn-get-started scrollto">ABOUT US</a>
          <a href="#services" class="btn-services scrollto">Our Events</a>
        </div>
      </div>

    </div>
  </section><!-- #intro -->

  <main id="main">