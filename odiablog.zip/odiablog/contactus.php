
<?php
error_reporting(0);


?>
<?php
include('include/blog_header.php'); 
error_reporting(0);
?>
     <div class="card" style="">
  <img class="card-img-top" src="https://www.csp.org.uk/sites/default/files/styles/section_index_banner/public/images/2018-08/shutterstock_711824767.jpg" alt="Card image">
  <div class="card-img-overlay">
    <h4 class="card-title">Odia News</h4>
    <p class="card-tex t">Our Latest news</p>
   
  </div>
</div>

      <div class="row mb-2">
      <?php

 include('db/connection.php');



 
   

$query3=mysqli_query($conn,"select * from news order by id desc limit 1,2 ");

while($row=mysqli_fetch_array($query3)){ 
 $category=$row['category'];
  $title=$row['title'];
  $date=$row['date'];
   $thubnail=$row['thumbline'];
    $des=$row['description'];


 

     ?>



        <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary"><?php echo $category;?></strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo $title;?></a>
              </h3>
              <div class="mb-1 text-muted"><?php echo $date;?></div>
              <p class="card-text mb-auto"><?php echo $description;?></p>

              <a href="#">Continue reading</a>
            </div>
            <img class="card-img-right flex-auto d-none d-md-block" data-src="holder.js/200x250?theme=thumb" alt="Card image cap">
          </div>
        </div>

     
<?php } ?>
      </div>

    </div>
  
    <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
        <h3>Contact Us</h3>

        <div style="">

  <form action="contactus.php" method="post" name="categoryform" onsubmit="return validateform() ">
    
  <div class="form-group">
    <label for="category">Name</label>
    <input type="text" placeholder="Enter Your Name" class="form-control" name="name" id="email">
  </div>
 <div class="form-group">
  <label for="comment">Add MSG</label>
  <textarea class="form-control" rows="5" placeholder="add description" name="desc" id="comment"></textarea>
</div>
 
  <input type="submit" name="submit" class="btn btn-default btn-primary" value="add category">
</form>
  

</div>

<?php
include('db/connection.php');

if(isset($_POST['submit'])){

   $name=$_POST['name'];
    $des=$_POST['desc'];

 
  $query = "INSERT INTO contact(name,msg)VALUES(?,?)";

  $stmt=$conn->prepare($query);
  $stmt->bind_param("ss",$name,$des);
  $stmt->execute();

  if ($query) {
    echo "<script> alert('Thanks For Contacting Us');</script>";

  }else{
          echo "<script> alert('not add');</script>";
  }

}


?>



  



       

          

        </div><!-- /.blog-main -->

        <aside class="col-md-4 blog-sidebar">
          <div class="p-3 mb-3 bg-light rounded">
            <h4 class="font-italic">About</h4>
            <p class="mb-0">Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
          </div>

  

     <div class="p-3">
       <h4 class="font-italic">Category</h4> <hr>
       <?php 
   include('db/connection.php');

   $query=mysqli_query($conn,"select * from category limit 1,4");

   while ($row=mysqli_fetch_array($query)) {
    $category= $row['category_name'];
    ?>
           
            <ol class="list-unstyled mb-0">

              <li><a href="category_page.php?single=<?php echo $category;?>"><?php echo $category; ?></a></li>
              
            </ol>
              <?php  } ?>
          </div>

            <div class="p-3">
       <h4 class="font-italic">Date</h4><hr>
       <?php 
   include('db/connection.php');

   $query=mysqli_query($conn,"select * from news  limit 1,4");

   while ($row=mysqli_fetch_array($query)) {
    $date= $row['date'];
    ?>
           
            <ol class="list-unstyled mb-0">

              <li><a href="#"><?php echo $date; ?></a></li>
              
            </ol>
              <?php  } ?>
          </div>





         

          <div class="p-3">
            <h4 class="font-italic">Elsewhere</h4>
            <ol class="list-unstyled">
              <li><a href="#">GitHub</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Facebook</a></li>
            </ol>
          </div>

        </aside><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </main><!-- /.container -->
<?php
include('include/blog_footer.php')
?>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
