
<?php 
session_start();
error_reporting(0);
if ($_SESSION['email']==true) {
  # code...
}else{
   header('location:admin_login.php');
}
$page='home';
include('include/header.php'); 

?>
 
        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
          


          <h2>User Count</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr>
                  <th>id</th>
                  <th>Date</th>
                  <th>Browser NAme</th>
                  <th>type</th>
                  <th>Os</th>
                  <th>URL</th>
                  <th>Ref</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
  include('db/connection.php');

    $page = $_GET['page'];
    
    if ($page=="" || $page=="1") {
      $page1=0;
    }else{
      $page1=($page*10)-10;
    }

   

     $query=mysqli_query($conn,"select * from visitor limit $page1,10");
     while($row=mysqli_fetch_array($query)){



  ?>
  <tr>
    <td><?php echo $row['id'];?></td>
    <td><?php echo $row['added_on'];?></td>
    <td><?php echo $row['browser_name'];?></td>
    <td><?php echo $row['type'];?></td>
    <td><?php echo $row['os'];?></td>
    <td><?php echo $row['url'];?></td>
     <td><?php echo $row['ref'];?></td>

   

    <td> <a href="visitor_delete.php?delete=<?= $row['id'] ?>" class="btn btn-danger">Delete</a></td>
    
  </tr>


<?php } $sql=mysqli_query($conn,"select * from news");
$count=mysqli_num_rows($sql);

echo$a=$count/10;
 $a=ceil($a);

  for ($i=1; $i < $a ; $i++) { 
    ?>
  </table>
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="news.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
  

<?php } ?>

</ul>
               
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>

<?php 

include('include/footer.php');
?>
