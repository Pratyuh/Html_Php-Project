
<?php
error_reporting(0);


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
       <!-- Add to HTML Head -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>


<script src="https://cdn.jsdelivr.net/sharer.js/latest/sharer.min.js"></script>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="style/bootstarp.min.css" rel="stylesheet">
    <link href="style/blog.css" rel="stylesheet">
  </head>

  <body>
 <div class="container">
  
     
        <!-- Image and text -->
<nav class="navbar sticky-top navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="img/logo.png" width="200" height="50" class="d-inline-block align-top" alt="">
  </a>
</nav>
    

  <!-- menu -->
      <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
           <a class="p-2 text-muted" href="index.php">Home</a>

            <?php 
           include('db/connection.php');

           $query5=mysqli_query($conn,"select * from category");

       while ($row3=mysqli_fetch_array($query5)) {
             $category1= $row3['category_name'];
                   ?>
           
             <a class="p-2 text-muted" href="category_page.php?single=<?php echo $category1;?>"><?php echo $category1; ?></a>

               <?php  } ?>


         
        </nav>
      </div>


      <div class="jumbotron p-3 p-md-5 text-white rounded bg-dark">
        <div class="col-md-6 px-0">
          <h1 class="display-4 font-italic">Title of a longer featured blog post</h1>
          <p class="lead my-3">Multiple lines of text that form the lede, informing new readers quickly and efficiently about what's most interesting in this post's contents.</p>
          <p class="lead mb-0"><a href="#" class="text-white font-weight-bold">Continue reading...</a></p>
        </div>
      </div>


   <!--  featured blog -->
      <div class="row mb-2">
      <?php

 include('db/connection.php');

$query3=mysqli_query($conn,"select * from news order by id desc limit 1,2 ");

while($row=mysqli_fetch_array($query3)){ 
 $category=$row['category'];
  $title=$row['title'];
  $date=$row['date'];
   $thubnail=$row['thumbline'];
    $des=$row['description'];


   ?>
 <div class="col-md-6">
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary"><?php echo $category;?></strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo $title;?></a>
              </h3>
              <div class="mb-1 text-muted"><?php echo $date;?></div>
              <p class="card-text mb-auto"><?php echo substr( $des,0,255);?></p>

              <a href="single_page.php?single=<?php echo $row['id']?>">Continue reading</a>
            </div>
      
          </div>
        </div>

     
<?php } ?>
      </div>

 
  <!--  featured blog end -->

    </div>

<!-- Main Blog -->
    <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
        

     <?php

 include('db/connection.php');

  $page = $_GET['page'];
    if ($page=="" || $page=="1") {
      $page1=0;
    }else{
      $page1=($page*5)-5;
    }

$query=mysqli_query($conn,"select * from news limit $page1,5");

while($row=mysqli_fetch_array($query)){ ?>     

          <div class="blog-post">
            <p class="blog-post-title"><a href="single_page.php?single=<?php echo $row['id']?>"><?php echo $row['title']?></a></p>

            <p class="blog-post-meta"><?php echo $row['date']?> <a href="#">Mark</a></p>

            <p><img style="width: 100%;height: 400px;" class="img img-thumbnail" src="images/<?php echo $row['thumbline']; ?>"  /></p>

            <hr>


            <p><?php echo $row['category']?></p>

            <blockquote>
             <?php echo substr( $row['description'],0,50)?>

             <a href="single_page.php?single=<?php echo $row['id']?>" class="btn btn-primary btn-sm ">Readmore</a>

            </blockquote>
           
            
             
          </div><!-- /.blog-post -->

<?php } ?>

   <!-- Pagination Start   -->

<?php 

$sql=mysqli_query($conn,"select * from news");
$count=mysqli_num_rows($sql);

$a=$count/5;
$a=ceil($a);

  for ($i=1; $i < $a ; $i++) { 
    ?>
  </table>
  <ul class="pagination">
    <li class="page-item"><a class="page-link" href="index.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
  

<?php } ?>

</ul>
  <!-- Pagination end   -->     


</div><!-- /.blog-main -->

       <aside class="col-md-4 blog-sidebar">
        <p>random Post</p>
          <?php

 include('db/connection.php');

$query6=mysqli_query($conn,"select * from news order by id desc limit 1,5 ");

while($row6=mysqli_fetch_array($query6)){ 
  $title=$row6['title'];
   $thubnail=$row6['thumbline'];


   ?>

   <div class="card" style="width: 18rem;" >
 
  <img class="card-img-top" src="images/<?php echo $thubnail; ?>"  />

  <div class="card-body">
    <h5 class="card-title"><a href="single_page.php?single=<?php echo $row['id']?>"><?php echo $title;?></a></h5>

  </div>

 <?php } ?>

          </div>

  


        </aside><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </main><!-- /.container -->

      <?php
include('include/blog_footer.php'); 

?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
