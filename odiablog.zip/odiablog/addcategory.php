
<?php 
session_start();
if ($_SESSION['email']==true) {
  # code...
}else{
   header('location:admin_login.php');
}
$page='category';
include('include/header.php'); 

?>

<div style="width:70%;margin-left: 25%;margin-top: 10%">

	<form action="addcategory.php" method="post" name="categoryform" onsubmit="return validateform() ">
		<h1>Add Category</h1><hr>
  <div class="form-group">
    <label for="category">Category:</label>
    <input type="text" placeholder="name category" class="form-control" name="category" id="email">
  </div>
 <div class="form-group">
  <label for="comment">Description:</label>
  <textarea class="form-control" rows="5" placeholder="add description" name="desc" id="comment"></textarea>
</div>
 
  <input type="submit" name="submit" class="btn btn-default btn-primary" value="add category">
</form>
	

</div>

<script>
  
function validateform(){
  var x = document.forms['categoryform']['category'].value;
  if (
    x=="") {
    alert('category must filled');
  return false;
  }
}

</script>

<?php
include('include/footer.php')

?>




<?php
include('db/connection.php');

if(isset($_POST['submit'])){

   $category_name=$_POST['category'];
    $des=$_POST['desc'];

    $check=mysqli_query($conn,"select * from category where category_name='$category_name' ");

    if (mysqli_num_rows($check)>0) {
    echo "<script> alert('Alerdy Added');</script>";
  exit();
    
    }else{
  

  


$query = "INSERT INTO category(category_name,des)VALUES(?,?)";

  $stmt=$conn->prepare($query);
  $stmt->bind_param("ss",$category_name,$des);
  $stmt->execute();

  if ($query) {
    echo "<script> alert('Added');</script>";

  }else{
          echo "<script> alert('not add');</script>";
  }

}
}

?>