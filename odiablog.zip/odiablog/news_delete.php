<?php

include('db/connection.php');

$id=$_GET['delete'];

$query=mysqli_query($conn,"delete from news where id='$id'");

if($query){

 	echo "<script> alert('delete Succe');</script>";
 	header('location:news.php');
}else{
	echo "<script> alert('not delete');</script>";
}


?>