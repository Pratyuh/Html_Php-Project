<?php
session_start();

?>


<?php
include ('db/connection.php');

if(isset($_POST['email'])){

  $email = $_POST['email'];
   $password = $_POST['password'];

   $query= mysqli_query($conn,"SELECT * FROM admin_login WHERE email='$email' AND pasword='$password'");

  if($query){
   	if (mysqli_num_rows($query)>=1) {
      $_SESSION['email'] = $email;
   		header('Location:home.php');
   		
   	}
   	else{
   		echo "<script> alert('invaild email and password');</script>";
   	} 
   } else{
   	   		echo mysqli_error($conn);

   }
} 
?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Signin Template for Bootstrap</title>

     <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <link href="style/bootstarp.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
    <form class="form-signin" action="admin_login.php" method="post">
     <h1>Admin Portal</h1>
      <h1 class="h3 mb-3 font-weight-normal"></h1>
      <label for="inputEmail" class="sr-only">Email address</label>
      <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" required autofocus><br>
      <label for="inputPassword" class="sr-only">Password</label>
      <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
     
      <input type="submit" name="submit" class="btn btn-lg btn-primary btn-block"
  value="login">
  <a href="index.php"> <p class="mt-5 mb-3 text-muted"><-- Back To Main Page</p></a>
    </form>

  </body>
</html>