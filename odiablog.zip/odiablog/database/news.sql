-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql312.byetcluster.com
-- Generation Time: Nov 24, 2020 at 01:03 AM
-- Server version: 5.6.48-88.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_25460887_news`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pasword` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `name`, `email`, `pasword`) VALUES
(1, 'pratyusa', 'abc@abc.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(100) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `des` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`, `des`) VALUES
(10, 'à¬‡à¬¤à¬¿à¬¹à¬¾à¬¸', 'This is about odisha history'),
(11, 'à¬•à¬¥à¬¾', 'Story'),
(12, 'à¬•à¬¬à¬¿à¬¤à¬¾', 'poem'),
(13, 'à¬…à¬¨à­à¬­à­‚à¬¤à¬¿', 'memories'),
(14, 'à¬¬à¬¿à¬œà­à¬žà¬¾à¬¨ à¬¸à¬®à­à¬®à¬¤', 'scientific'),
(15, 'à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ', 'About health');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `msg` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(100) NOT NULL,
  `title` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `date` date NOT NULL,
  `thumbline` varchar(255) NOT NULL,
  `category` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `date`, `thumbline`, `category`) VALUES
(73, 'à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬•à¬¿à¬ªà¬°à¬¿ à¬¬à¬¿à¬¸à­à¬¤à¬¾à¬° à¬¹à­à¬ à¬à¬¬à¬‚ à¬•à¬¿à¬ à¬…à¬§à¬¿à¬• à¬¬à¬¿à¬ªà¬¦à¬ªà­‚à¬°à­à¬£à­à¬£, à¬ªà­à¬°à¬¤à­à­Ÿà­‡à¬• à¬ªà­à¬°à¬¶à­à¬¨à¬° à¬‰à¬¤à­à¬¤à¬° à¬œà¬¾à¬£ |', 'à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬¬à¬¿à¬¶à­à­±à¬°à­‡ à¬¦à­à¬°à­à¬¤à¬¤à¬® à¬¬à¬¿à¬¸à­à¬¤à¬¾à¬° à¬¸à¬‚à¬•à­à¬°à¬®à¬£à¬°à­‡ à¬ªà¬°à¬¿à¬£à¬¤ à¬¹à­‹à¬‡à¬›à¬¿ | à¬¬à¬°à­à¬¤à­à¬¤à¬®à¬¾à¬¨ à¬ªà¬°à­à¬¯à­à­Ÿà¬¨à­à¬¤ à¬¸à¬¾à¬°à¬¾ à¬¬à¬¿à¬¶à­à­±à¬°à­‡ à¬à¬¹à¬¿ à¬œà­€à¬¬à¬¾à¬£à­ à¬°à­ 69 à¬¹à¬œà¬¾à¬°à¬°à­ à¬…à¬§à¬¿à¬• à¬²à­‹à¬• à¬ªà­à¬°à¬¾à¬£ à¬¹à¬°à¬¾à¬‡à¬›à¬¨à­à¬¤à¬¿à¥¤ à¬¬à¬°à­à¬¤à­à¬¤à¬®à¬¾à¬¨ à¬¸à­à¬¦à­à¬§à¬¾ à¬¸à¬¾à¬°à¬¾ à¬¬à¬¿à¬¶à­à­±à¬°à­‡ à¬•à¬°à­‹à¬¨à¬¾ à¬®à¬¾à¬®à¬²à¬¾ à¬°à¬¿à¬ªà­‹à¬°à­à¬Ÿ à¬œà¬¾à¬°à¬¿ à¬°à¬¹à¬¿à¬›à¬¿à¥¤ à¬¬à¬¿à¬¶à­à­± à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ à¬¸à¬‚à¬—à¬ à¬¨ WHO à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­à¬•à­ à¬à¬• à¬†à¬¨à­à¬¤à¬°à­à¬œà¬¾à¬¤à­€à­Ÿ à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ à¬œà¬°à­à¬°à­€à¬•à¬¾à¬³à­€à¬¨ à¬ªà¬°à¬¿à¬¸à­à¬¥à¬¿à¬¤à¬¿ à¬˜à­‹à¬·à¬£à¬¾ à¬•à¬°à¬¿à¬›à¬¿à¥¤  à¬¬à¬°à­à¬¤à­à¬¤à¬®à¬¾à¬¨ à¬à¬¹à¬¿ à¬°à­‹à¬— à¬à¬¤à­‡ à¬¬à¬¡ à¬¹à­‹à¬‡à¬¥à¬¿à¬¬à¬¾à¬°à­ à¬²à­‹à¬•à¬™à­à¬• à¬®à¬¨à¬°à­‡ à¬ªà­à¬°à¬¶à­à¬¨, à¬­à­Ÿ,  à¬¦à­à­±à¬¨à­à¬¦à­à­±à¬° à¬¬à¬¾à¬¤à¬¾à¬¬à¬°à¬£ à¬¥à¬¿à¬¬à¬¾ à¬¸à­à¬ªà¬·à­à¬Ÿ à¬¹à­‹à¬‡à¬›à¬¿à¥¤ à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬•â€™à¬£, à¬à¬¹à¬¾ à¬•à¬¿à¬ªà¬°à¬¿ à¬¬à¬¿à¬¸à­à¬¤à¬¾à¬° à¬¹à­à¬, à¬•à¬¿à¬ à¬¸à¬‚à¬•à­à¬°à¬®à¬£à¬°à­‡ à¬…à¬§à¬¿à¬• à¬ªà­à¬°à¬¬à­ƒà¬¤à­à¬¤, à¬à¬¹à¬¿ à¬°à­‹à¬—à¬° à¬‰à¬ªà¬¶à¬® à¬…à¬›à¬¿ à¬•à¬¿ à¬¨à¬¾à¬¹à¬¿à¬, à¬¯à¬¦à¬¿ à¬†à¬ªà¬£à¬™à­à¬• à¬®à¬¨à¬°à­‡ à¬à¬ªà¬°à¬¿ à¬ªà­à¬°à¬¶à­à¬¨ à¬¥à¬¾à¬, à¬à¬ à¬¾à¬°à­‡ à¬œà¬¾à¬£à¬¨à­à¬¤à­, à¬¸à¬®à¬¸à­à¬¤ à¬‰à¬¤à­à¬¤à¬° à¬¦à¬¿à¬…à¬¨à­à¬¤à­ ...\r\n\r\n1. à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬•â€™à¬£?<br>\r\nà¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬œà­€à¬¬à¬¾à¬£à­à¬™à­à¬•à¬° à¬à¬• à¬ªà¬°à¬¿à¬¬à¬¾à¬°à¬°, à¬¯à¬¾à¬¹à¬¾à¬° à¬¸à¬‚à¬•à­à¬°à¬®à¬£ à¬¥à¬£à­à¬¡à¬¾ à¬ à¬¾à¬°à­ à¬¨à¬¿à¬¶à­à­±à¬¾à¬¸ à¬ªà­à¬°à¬¶à­à­±à¬¾à¬¸ à¬ªà¬°à­à¬¯à­à­Ÿà¬¨à­à¬¤ à¬¸à¬®à¬¸à­à­Ÿà¬¾ à¬¹à­‹à¬‡à¬ªà¬¾à¬°à­‡ | à¬à¬¹à¬¿ à¬œà­€à¬¬à¬¾à¬£à­ à¬ªà­‚à¬°à­à¬¬à¬°à­ à¬•à­‡à¬¬à­‡ à¬¦à­‡à¬–à¬¾à¬¯à¬¾à¬‡ à¬¨à¬¥à¬¿à¬²à¬¾ | à¬à¬¹à¬¿ à¬­à­‚à¬¤à¬¾à¬£à­ à¬¸à¬‚à¬•à­à¬°à¬®à¬£ à¬¡à¬¿à¬¸à­‡à¬®à­à¬¬à¬°à¬°à­ à¬šà¬¾à¬‡à¬¨à¬¾à¬° à­±à­à¬¹à¬¾à¬¨à¬°à­‡ à¬†à¬°à¬®à­à¬­ à¬¹à­‹à¬‡à¬¥à¬¿à¬²à¬¾à¥¤ à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬œà­€à¬¬à¬¾à¬£à­à¬™à­à¬•à¬° à¬à¬• à¬¬à­ƒà¬¹à¬¤ à¬ªà¬°à¬¿à¬¬à¬¾à¬°à¬° à¬…à¬‚à¬¶, à¬•à¬¿à¬¨à­à¬¤à­ à¬à¬¹à¬¿ à¬œà­€à¬¬à¬¾à¬£à­ à¬®à¬§à­à­Ÿà¬°à­ à¬®à¬¾à¬¤à­à¬° 6 à¬Ÿà¬¿ à¬…à¬›à¬¿ à¬¯à¬¾à¬¹à¬¾ à¬®à¬£à¬¿à¬·à¬•à­ à¬¸à¬‚à¬•à­à¬°à¬®à¬¿à¬¤ à¬•à¬°à¬¿à¬ªà¬¾à¬°à­‡ | à¬¨à­‹à¬­à­‡à¬²à­ à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬¯à¬¥à¬¾ à¬à¬¹à¬¿ à¬¨à­‚à¬¤à¬¨ à¬œà­€à¬¬à¬¾à¬£à­ à¬ªà­à¬°à¬¥à¬® à¬¥à¬° à¬ªà¬¾à¬‡à¬ à¬ªà­à¬°à¬•à¬¾à¬¶ à¬ªà¬¾à¬‡à¬›à¬¿ à¬¯à¬¾à¬¹à¬¾ à¬®à¬£à¬¿à¬·à¬•à­ à¬¸à¬‚à¬•à­à¬°à¬®à¬¿à¬¤ à¬•à¬°à­à¬›à¬¿ | WHO à¬à¬¹à¬¿ à¬¨à­‚à¬¤à¬¨ à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ 2019-nCoV à¬¨à¬¾à¬®à¬•à¬°à¬£ à¬•à¬°à¬¿à¬›à¬¿ |<br>\r\n2. à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­à¬° à¬²à¬•à­à¬·à¬£à¬—à­à¬¡à¬¼à¬¿à¬• à¬•â€™à¬£?<br>\r\nà¬à¬¹à¬¿ à¬°à­‹à¬—à¬° à¬²à¬•à­à¬·à¬£ à¬¬à¬¿à¬·à­Ÿà¬°à­‡ à¬•à¬¹à¬¿à¬¬à¬¾à¬•à­ à¬—à¬²à­‡ à¬à¬¹à¬¾ à¬¸à¬¾à¬§à¬¾à¬°à¬£ à¬¥à¬£à­à¬¡à¬¾ à¬•à¬¿à¬®à­à¬¬à¬¾ à¬¨à¬¿à¬®à­‹à¬¨à¬¿à¬† à¬­à¬³à¬¿ à¬…à¬Ÿà­‡ | à¬à¬¹à¬¿ à¬œà­€à¬¬à¬¾à¬£à­ à¬¸à¬‚à¬•à­à¬°à¬®à¬£ à¬ªà¬°à­‡ à¬œà­à­±à¬°, à¬¥à¬£à­à¬¡à¬¾, à¬¨à¬¿à¬¶à­à­±à¬¾à¬¸ à¬ªà­à¬°à¬¶à­à­±à¬¾à¬¸, à¬¨à¬¾à¬• à¬ªà­à¬°à¬¬à¬¾à¬¹à¬¿à¬¤ à¬¹à­‡à¬¬à¬¾ à¬à¬¬à¬‚ à¬—à¬³à¬¾ à¬¯à¬¨à­à¬¤à­à¬°à¬£à¬¾ à¬­à¬³à¬¿ à¬¸à¬®à¬¸à­à­Ÿà¬¾ à¬¦à­‡à¬–à¬¾à¬¯à¬¾à¬ | à¬à¬¹à¬¿ à¬œà­€à¬¬à¬¾à¬£à­ à¬œà¬£à¬™à­à¬•à¬ à¬¾à¬°à­ à¬…à¬¨à­à­Ÿ à¬œà¬£à¬•à­ à¬¬à­à­Ÿà¬¾à¬ªà¬¿à¬¥à¬¾à¬, à¬¤à­‡à¬£à­ à¬à¬¥à¬¿à¬ªà­à¬°à¬¤à¬¿ à¬¬à¬¹à­à¬¤ à¬¯à¬¤à­à¬¨ à¬¨à¬¿à¬†à¬¯à¬¾à¬‰à¬›à¬¿ |<br>\r\n3.à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­ à¬¸à¬¹à¬¿à¬¤ à¬®à­à¬•à¬¾à¬¬à¬¿à¬²à¬¾ à¬•à¬°à¬¿à¬¬à¬¾ à¬ªà¬¾à¬‡à¬ à¬à¬• à¬Ÿà¬¿à¬•à¬¾ à¬…à¬›à¬¿ à¬•à¬¿?<br>\r\nà¬à¬ªà¬°à­à¬¯à­à­Ÿà¬¨à­à¬¤ à¬• a à¬£à¬¸à¬¿ à¬Ÿà¬¿à¬•à¬¾ à¬•à¬¿à¬®à­à¬¬à¬¾ à¬Ÿà¬¿à¬•à¬¾ à¬¨à¬¾à¬¹à¬¿à¬ à¬¯à¬¾à¬¹à¬¾ à¬à¬¹à¬¿ à¬®à¬¾à¬°à¬¾à¬¤à­à¬®à¬• à¬•à¬°à­‹à¬¨à¬¾ à¬œà­€à¬¬à¬¾à¬£à­à¬°à­ à¬¸à­à¬°à¬•à­à¬·à¬¾ à¬¯à­‹à¬—à¬¾à¬‡à¬ªà¬¾à¬°à­‡à¥¤ à¬…à¬§à­à­Ÿà­Ÿà¬¨ à¬šà¬¾à¬²à¬¿à¬›à¬¿ à¬à¬¬à¬‚ à¬…à¬¨à­à¬¸à¬¨à­à¬§à¬¾à¬¨à¬•à¬¾à¬°à­€à¬®à¬¾à¬¨à­‡ à¬à¬¹à¬¾ à¬‰à¬ªà¬°à­‡ à¬…à¬¨à­à¬¸à¬¨à­à¬§à¬¾à¬¨ à¬•à¬°à­à¬›à¬¨à­à¬¤à¬¿, à¬«à¬¾à¬°à­à¬®à¬¾à¬¸à­à­Ÿà­à¬Ÿà¬¿à¬•à¬¾à¬²à­ à¬•à¬®à­à¬ªà¬¾à¬¨à­€à¬—à­à¬¡à¬¿à¬• à¬®à¬§à­à­Ÿ à¬à¬¹à¬¾à¬° à¬‰à¬ªà¬¶à¬® à¬¤à¬¥à¬¾ à¬°à­‹à¬—à¬•à­ à¬°à­‹à¬•à¬¿à¬¬à¬¾ à¬ªà¬¾à¬‡à¬ à¬Ÿà¬¿à¬•à¬¾ à¬ªà­à¬°à¬¸à­à¬¤à­à¬¤ à¬•à¬°à­à¬›à¬¨à­à¬¤à¬¿ | WHO à¬®à¬§à­à­Ÿ à¬•à¬°à­‹à¬¨à¬¾ à¬ªà­à¬°à¬¤à¬¿ à¬¸à¬œà¬¾à¬— à¬°à¬¹à¬¿à¬›à¬¿ à¬à¬¬à¬‚ à¬à¬¹à¬¾à¬° à¬‰à¬ªà¬¶à¬® à¬ªà¬¾à¬‡à¬¬à¬¾ à¬ªà¬¾à¬‡à¬ à¬¯à¬¥à¬¾à¬¸à¬®à­à¬­à¬¬ à¬šà­‡à¬·à­à¬Ÿà¬¾ à¬•à¬°à­à¬›à¬¿ | à¬¬à¬°à­à¬¤à­à¬¤à¬®à¬¾à¬¨, à¬à¬¹à¬¾à¬•à­ à¬à¬¡à¬¾à¬‡à¬¬à¬¾ à¬ªà¬¾à¬‡à¬ à¬¸à¬°à­à¬¬à­‹à¬¤à­à¬¤à¬® à¬‰à¬ªà¬¾à­Ÿ à¬¹à­‡à¬‰à¬›à¬¿ à¬¸à¬¤à¬°à­à¬•à¬¤à¬¾ à¬…à¬¬à¬²à¬®à­à¬¬à¬¨ à¬•à¬°à¬¿à¬¬à¬¾ |', '2020-04-16', 'covid19-cdc-unsplash.jpg', 'à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ'),
(74, 'Red Bull à¬ªà¬¾à¬¨à­€à­Ÿ à¬²à¬¾à¬­ à¬à¬¬à¬‚ à¬ªà¬¾à¬°à­à¬¶à­à­± à¬ªà­à¬°à¬¤à¬¿à¬•à­à¬°à¬¿à­Ÿà¬¾ |', 'Red Bull  à¬¹à­‡à¬‰à¬›à¬¿  à¬¸à¬°à­à¬¬à¬¾à¬§à¬¿à¬• à¬¬à¬¿à¬•à­à¬°à¬¿ à¬¹à­‡à¬‰à¬¥à¬¿à¬¬à¬¾ à¬ªà¬¾à¬¨à­€à­Ÿ , à¬ªà­à¬°à¬¤à¬¿à¬¬à¬°à­à¬· 630 à¬¨à¬¿à­Ÿà­à¬¤à¬°à­ à¬…à¬§à¬¿à¬• à¬•à­à­Ÿà¬¾à¬¨à­ à¬¬à¬¿à¬•à­à¬°à¬¿ à¬¹à­à¬ | à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬à¬¨à¬°à­à¬œà¬¿ à¬ªà¬¾à¬¨à­€à­Ÿ à¬…à¬·à­à¬Ÿà­à¬°à¬¿à¬† à¬à¬• à¬¦à­‡à¬¶ à¬•à¬®à­à¬ªà¬¾à¬¨à­€ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ GmbH à¬‰à¬¤à­à¬ªà¬¾à¬¦à¬¨ à¬•à¬°à­‡ | à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬°à­‡  Caffeine, Taurine, Sugar  à¬­à¬¿à¬Ÿà¬¾à¬®à¬¿à¬¨à­ à¬¬à¬¿ (B3, B5, B6, B12)  à¬•à¬¾à¬°à­à¬¬à­‹à¬¨à­‡à¬Ÿà­‡à¬¡à­ à­±à¬¾à¬Ÿà¬°à­, à¬¬à­‡à¬•à¬¿à¬‚ à¬¸à­‹à¬¡à¬¾, à¬®à­à­Ÿà¬¾à¬—à­à¬¨à­‡à¬¸à¬¿à­Ÿà¬®à­ à¬•à¬¾à¬°à­à¬¬à­‹à¬¨à¬¾à¬Ÿà­ à¬¥à¬¾à¬ |\r\n<br><br>\r\n à¬°à­‡à¬¡à­ à¬¬à­à¬²à­  à¬ªà¬¿à¬‡à¬¬à¬¾ à¬¦à­à­±à¬¾à¬°à¬¾ à¬•â€™à¬£ à¬¹à­à¬?<br>\r\nà¬°à­‡à¬¡à­ à¬¬à­à¬²à­  à¬…à¬£-à¬®à¬¦à­à­Ÿà¬ªà¬¾à¬¨à­€à­Ÿ (Non-Alcoholic beverage) , à¬…à¬°à­à¬¥à¬¾à¬¤à­ à¬à¬¥à¬¿à¬°à­‡ à¬®à¬¦à­à­Ÿà¬ªà¬¾à¬¨ à¬¨à¬¾à¬¹à¬¿à¬ | à¬¤à­‡à¬£à­ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬ªà¬¾à¬¨à­€à­Ÿ à¬ªà¬¿à¬‡à¬¬à¬¾ à¬à¬• à¬¨à¬¿à¬¶à¬¾ à¬¨à­à¬¹à­‡à¬ | à¬®à­‚à¬³à¬¤ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­  à¬°à­‡ à¬•à­à­Ÿà¬¾à¬«à­‡à¬¨à­ (à¬•à­à­Ÿà¬¾à¬«à­‡à¬¨à­) à¬¥à¬¾à¬ | à¬•à¬«à¬¿à¬¨à­ à¬¹à­‡à¬‰à¬›à¬¿ à¬à¬• à¬°à¬¾à¬¸à¬¾à­Ÿà¬¨à¬¿à¬• à¬ªà¬¦à¬¾à¬°à­à¬¥ à¬¯à¬¾à¬¹à¬¾ à¬šà¬¾, à¬•à¬«à¬¿, à¬•à­‹à¬²à¬¾ à¬à¬¬à¬‚ à¬…à¬¨à­à­Ÿà¬¾à¬¨à­à­Ÿ à¬–à¬¾à¬¦à­à­Ÿ à¬ªà¬¦à¬¾à¬°à­à¬¥à¬°à­‡ à¬ªà­à¬°à¬¾à¬•à­ƒà¬¤à¬¿à¬• à¬­à¬¾à¬¬à¬°à­‡ à¬®à¬¿à¬³à¬¿à¬¥à¬¾à¬ | à¬•à¬«à¬¿à¬¨à­ à¬–à¬¾à¬‡à¬¬à¬¾ à¬¤à¬¤à¬•à­à¬·à¬£à¬¾à¬¤à­ à¬®à¬¾à¬¨à¬¸à¬¿à¬• à¬¸à¬¤à¬°à­à¬•à¬¤à¬¾ à¬†à¬£à¬¿à¬¥à¬¾à¬, à¬¸à­‡à¬¥à¬¿à¬ªà¬¾à¬‡à¬ à¬šà¬¾, à¬•à¬«à¬¿ à¬ªà¬¿à¬‡à¬¬à¬¾ à¬¦à­à­±à¬¾à¬°à¬¾ à¬…à¬³à¬¸à­à¬†à¬¤à¬¾ à¬¦à­‚à¬° à¬¹à­à¬, à¬®à¬¨à¬•à­ à¬¸à¬¤à­‡à¬œ à¬¹à­à¬ à¬à¬¬à¬‚ à¬¥à¬•à¬¾à¬ªà¬£ à¬®à¬§à­à­Ÿ à¬•à¬®à¬¿à¬¯à¬¾à¬ |  à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬° à¬à¬• à¬ªà¬¾à¬¤à­à¬°à¬°à­‡ à¬à¬• à¬•à¬ªà­ à¬•à¬«à¬¿ à¬¸à¬¹à¬¿à¬¤ à¬¸à¬®à¬¾à¬¨ à¬•à¬«à¬¿à¬¨à­ à¬¥à¬¾à¬ | à¬°à­‡à¬¡à­ à¬¬à­à¬²à­  à¬°  à¬à¬• à¬•à­à­Ÿà¬¾à¬¨à­ 80 mg à¬•à­à­Ÿà¬¾à¬«à­‡à¬¨à­ à¬§à¬¾à¬°à¬£ à¬•à¬°à¬¿à¬¥à¬¿à¬¬à¬¾à¬¬à­‡à¬³à­‡ à¬à¬• à¬®à¬¾à¬¨à¬• à¬•à¬«à¬¿ à¬•à¬ªà¬°à­‡ 80â€“90 mg à¬•à¬«à¬¿à¬¨à­ à¬¥à¬¾à¬ |<br>\r\nà¬à¬¹à¬¾ à¬¬à­à­Ÿà¬¤à­€à¬¤,à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬°à­‡  Taurine à¬¥à¬¾à¬, à¬¯à¬¾à¬¹à¬¾ à¬à¬• à¬ªà­à¬°à¬•à¬¾à¬° à¬†à¬®à¬¿à¬¨à­‹ à¬à¬¸à¬¿à¬¡à­ |  à¬¬à¬°à­à¬¤à­à¬¤à¬®à¬¾à¬¨ à¬†à¬ªà¬£ à¬œà¬¾à¬£à¬¿à¬ªà¬¾à¬°à¬¿ à¬¯à­‡ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬ªà¬¿à¬‡à¬¬à¬¾ à¬à¬• à¬¨à¬¿à¬¶à¬¾ à¬¨à­à¬¹à­‡à¬, à¬¬à¬°à¬‚ à¬•à¬¿à¬›à¬¿ à¬¸à¬®à­Ÿ à¬ªà¬¾à¬‡à¬ à¬®à¬¨ à¬à¬¬à¬‚ à¬¶à¬¾à¬°à­€à¬°à¬¿à¬• à¬•à¬¾à¬°à­à¬¯à­à­Ÿà¬•à¬³à¬¾à¬ª à¬¬à­ƒà¬¦à­à¬§à¬¿ à¬ªà¬¾à¬‡à¬¥à¬¾à¬ | à¬®à¬¾à¬¤à­à¬° à¬°à­‡à¬¡à­ à¬¬à­ƒà¬· à¬ªà¬¿à¬‡à¬¬à¬¾à¬° à¬ªà­à¬°à¬­à¬¾à¬¬ à¬®à¬¾à¬¤à­à¬° 3-4 à¬˜à¬£à­à¬Ÿà¬¾ à¬ªà¬°à­‡ à¬²à­‹à¬ª à¬ªà¬¾à¬‡à¬¬à¬¾à¬•à­ à¬²à¬¾à¬—à¬¿à¬²à¬¾ |<br><br>\r\n\r\n à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬ªà¬¿à¬‡à¬¬à¬¾à¬° à¬…à¬¸à­à¬¬à¬¿à¬§à¬¾ |<br>\r\nà¬…à¬§à¬¿à¬• à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬ªà¬¿à¬‡à¬¬à¬¾à¬¦à­à¬¬à¬¾à¬°à¬¾  à¬‰à¬¤à­à¬¤à­‡à¬œà¬¨à¬¾, à¬…à¬¨à¬¿à¬¦à­à¬°à¬¾, à¬‰à¬šà­à¬š à¬°à¬•à­à¬¤à¬šà¬¾à¬ª, à¬•à¬·à­à¬Ÿ, à¬¦à­à¬°à­à¬¤ à¬¹à­ƒà¬¦à¬¸à­à¬ªà¬¨à­à¬¦à¬¨, à¬…à¬¸à­à¬¥à¬¿à¬°à¬¤à¬¾, à¬¸à­à¬¨à¬¾à­Ÿà­, à¬…à¬¤à­à­Ÿà¬§à¬¿à¬• à¬ªà¬°à¬¿à¬¸à­à¬°à¬¾,  à¬¬à¬¾à¬¨à­à¬¤à¬¿, à¬®à­à¬£à­à¬¡ à¬¬à­à¬²à¬¾à¬‡à¬¬à¬¾ à¬¸à¬®à¬¸à­à­Ÿà¬¾ à¬¹à­‹à¬‡à¬ªà¬¾à¬°à­‡ | à¬•à­‡à¬¤à­‡à¬• à¬•à­à¬·à­‡à¬¤à­à¬°à¬°à­‡, à¬°à­‡à¬¡à­ à¬¬à­à¬²à­   à¬ªà¬¿à¬‡à¬¬à¬¾ à¬ªà¬°à­‡ à¬¹à­ƒà¬¦à¬¸à­à¬ªà¬¨à­à¬¦à¬¨ à¬¬à­ƒà¬¦à­à¬§à¬¿ à¬¹à­‡à¬¤à­ à¬¹à­ƒà¬¦à¬˜à¬¾à¬¤ à¬®à¬§à­à­Ÿ à¬¦à­‡à¬–à¬¾à¬—à¬²à¬¾ | à¬à¬¹à¬¿à¬ªà¬°à¬¿ à¬²à­‹à¬•à¬®à¬¾à¬¨à­‡ à¬—à­‹à¬Ÿà¬¿à¬ à¬¦à¬¿à¬¨à¬°à­‡ 8-10 à¬•à­à­Ÿà¬¾à¬¨à­ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬•à¬¿à¬®à­à¬¬à¬¾ à¬…à¬¨à­à­Ÿà¬¾à¬¨à­à­Ÿ à¬¶à¬•à­à¬¤à¬¿ à¬ªà¬¾à¬¨à­€à­Ÿ à¬ªà¬¿à¬‡à¬¥à¬¿à¬²à­‡ |  à¬°à­‡à¬¡à­ à¬¬à­à¬²à­  à¬¶à¬°à­€à¬°à¬°à­‡ à¬•à¬«à¬¿à¬¨à­ à¬¬à­ƒà¬¦à­à¬§à¬¿ à¬•à¬°à¬¿à¬¥à¬¾à¬ | à¬•à¬«à¬¿à¬¨à­â€Œà¬° à¬à¬• à¬…à¬¤à­à­Ÿà¬§à¬¿à¬• à¬®à¬¾à¬¤à­à¬°à¬¾ à¬‡à¬¨à¬¸à­à¬²à¬¿à¬¨à­ à¬¸à¬®à­à¬¬à­‡à¬¦à¬¨à¬¶à­€à¬³à¬¤à¬¾ à¬¹à­à¬°à¬¾à¬¸ à¬•à¬°à­‡, à¬¯à¬¾à¬¹à¬¾ à¬Ÿà¬¾à¬‡à¬ªà­-à­¨ à¬¡à¬¾à¬‡à¬¬à­‡à¬Ÿà¬¿à¬¸à­ à¬¹à­‹à¬‡à¬ªà¬¾à¬°à­‡ |<br>\r\nà¬•à­‡à¬¬à¬³ à¬à¬¤à¬¿à¬•à¬¿ à¬¨à­à¬¹à­‡à¬, à¬…à¬¨à­‡à¬• à¬¦à­‡à¬¶à¬°à­‡ à¬¶à¬¿à¬¶à­ à¬à¬¬à¬‚ à¬•à¬¿à¬¶à­‹à¬°à¬®à¬¾à¬¨à¬™à­à¬• à¬ªà¬¾à¬‡à¬ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬¬à¬¿à¬•à­à¬°à­Ÿ à¬•à¬°à¬¿à¬¬à¬¾ à¬¬à­‡à¬†à¬‡à¬¨ à¬…à¬Ÿà­‡, à¬•à¬¾à¬°à¬£ à¬à¬¥à¬¿à¬°à­‡ à¬®à­‡à¬¦à¬¬à¬¹à­à¬³à¬¤à¬¾, à¬¯à¬•à­ƒà¬¤ à¬•à­à¬·à¬¤à¬¿, à¬œà¬¬à¬°à¬¦à¬–à¬² à¬­à¬³à¬¿ à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ à¬¸à¬®à¬¸à­à­Ÿà¬¾ à¬¦à­‡à¬–à¬¾à¬¦à­‡à¬‡à¬›à¬¿ | <b>à¬¯à­‡à¬‰à¬à¬®à¬¾à¬¨à­‡ à¬œà¬¿à¬®à­ à¬•à¬¿à¬®à­à¬¬à¬¾ à¬¬à­à­Ÿà¬¾à­Ÿà¬¾à¬®à¬•à­ à¬¯à¬¾à¬†à¬¨à­à¬¤à¬¿ à¬¸à­‡à¬®à¬¾à¬¨à­‡ à¬°à­‡à¬¡à­ à¬¬à­à¬²à­ à¬ªà¬¿à¬‡à¬¬à¬¾ à¬‰à¬šà¬¿à¬¤à­ à¬¨à­à¬¹à­‡à¬</b> | ', '2020-05-16', 'maxresdefault.jpg', 'à¬¸à­à­±à¬¾à¬¸à­à¬¥à­à­Ÿ'),
(75, 'à¬—à­à¬°à­à¬¤à­à­±à¬ªà­‚à¬°à­à¬£à­à¬£ à¬•à¬®à­à¬ªà­à­Ÿà­à¬Ÿà¬° à¬¸à¬°à­à¬Ÿà¬•à¬Ÿà­ à¬¯à¬¾à¬¹à¬¾ à¬†à¬ªà¬£ à¬œà¬¾à¬£à¬¿à¬¬à¬¾ à¬‰à¬šà¬¿à¬¤à­ | Computer Shortcuts in Odia', '1.  &nbsp &nbsp <b> Alt + e </b>  &nbsp &nbsp  à¬à¬¡à¬¿à¬Ÿà­ à¬®à­‡à¬¨à­ à¬–à­‹à¬²à¬¿à¬¬à¬¾à¬•à­ | <br>\r\n2. &nbsp &nbsp  <b> Alt + Enter </b>  &nbsp &nbsp à¬®à¬¨à­‹à¬¨à­€à¬¤ à¬«à¬¾à¬‡à¬²à­ à¬•à¬¿à¬®à­à¬¬à¬¾ à¬¡à¬•à­à­Ÿà­à¬®à­‡à¬£à­à¬Ÿà­ à¬—à­à¬£à¬—à­à¬¡à¬¿à¬• à¬¦à­‡à¬–à¬¿à¬¬à¬¾à¬•à­ | <br>\r\n3. &nbsp &nbsp <b> Alt + F4 </b> &nbsp &nbsp à¬¸à¬•à­à¬°à¬¿à­Ÿ à¬¸à¬«à­à¬Ÿà­±à­‡à¬°à­ à¬¬à¬¨à­à¬¦ à¬•à¬°à¬¿à¬¬à¬¾à¬•à­ |<br>\r\n4. &nbsp &nbsp  <b> Ctrl + C </b> &nbsp &nbspà¬®à¬¨à­‹à¬¨à­€à¬¤ à¬ªà¬¾à¬ à­à­Ÿà¬•à­ à¬•à¬ªà¬¿ à¬•à¬°à¬¿à¬¬à¬¾à¬•à­ |<br>\r\n5.  &nbsp &nbsp  <b> Ctrl + V </b> &nbsp &nbspà¬®à¬¨à­‹à¬¨à­€à¬¤ à¬ªà¬¾à¬ à­à­Ÿà¬•à­ à¬ªà­‡à¬¸à­à¬Ÿ  à¬•à¬°à¬¿à¬¬à¬¾à¬•à­ |<br>\r\n6.  &nbsp &nbsp  <b>Ctrl + End </b> &nbsp &nbsp à¬¡à¬•à­à­Ÿà­à¬®à­‡à¬£à­à¬Ÿà­ à¬° à¬¶à­‡à¬·à¬•à­ à¬¯à¬¿à¬¬à¬¾à¬•à­ |<br>\r\n7.  &nbsp &nbsp  <b> Ctrl + Shift + n </b> &nbsp &nbsp New Folder |<br>\r\n8.  &nbsp &nbsp  <b> Ctrl + P </b> &nbsp &nbsp à¬à¬• à¬¡à¬•à­à­Ÿà­à¬®à­‡à¬£à­à¬Ÿà­ à¬ªà­à¬°à¬¿à¬£à­à¬Ÿà­ à¬•à¬°à¬¿à¬¬à¬¾à¬•à­  |<br>\r\n9.  &nbsp &nbsp  <b>F5 </b> &nbsp &nbsp Refresh |<br>\r\n10.  &nbsp &nbsp  <b> Shift + Del </b> &nbsp &nbsp à¬ªà¬°à¬®à¬¾à¬¨à­‡à¬£à­à¬Ÿ à¬¡à¬¿à¬²à­€à¬Ÿ  |<br>\r\n', '2020-05-17', 'Computer Shortcut Key Download In Hindi Pdf Large Format.JPG', 'à¬¬à¬¿à¬œà­à¬žà¬¾à¬¨ à¬¸à¬®à­à¬®à¬¤');

-- --------------------------------------------------------

--
-- Table structure for table `visitor`
--

CREATE TABLE `visitor` (
  `id` int(11) NOT NULL,
  `browser_name` varchar(255) NOT NULL,
  `browser_version` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `os` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor`
--

INSERT INTO `visitor` (`id`, `browser_name`, `browser_version`, `type`, `os`, `url`, `ref`, `added_on`) VALUES
(35, 'Chrome', '71.0.3578.141', 'Mobile', 'Android', 'http//odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', 'http://odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', '2020-04-16 12:37:25'),
(34, 'Chrome', '71.0.3578.141', 'Mobile', 'Android', 'http//odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', 'http://odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', '2020-04-16 12:37:14'),
(26, 'Chrome', '80.0.3987.162', 'Mobile', 'Android', 'http//odiablog.ml/?fbclid=IwAR1iDZjMQjtElLrSEagbMS22C87tSF-pebfAmwm5hmPtj_j_hJkzTKn4POU&i=1', 'http://odiablog.ml/?fbclid=IwAR1iDZjMQjtElLrSEagbMS22C87tSF-pebfAmwm5hmPtj_j_hJkzTKn4POU', '2020-04-16 11:09:33'),
(27, 'Chrome', '80.0.3987.162', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-16 11:10:13'),
(28, 'Chrome', '78.0.3904.96', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-16 11:27:52'),
(29, 'Chrome', '78.0.3904.96', 'Mobile', 'Android', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-04-16 11:28:02'),
(30, 'Chrome', '80.0.3987.162', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-16 11:29:38'),
(31, 'Chrome', '80.0.3987.162', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-16 11:34:06'),
(32, 'Chrome', '71.0.3578.141', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-16 12:36:29'),
(45, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:18:54'),
(46, 'Chrome', '78.0.3904.97', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-04-16 17:19:44'),
(42, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:18:50'),
(43, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:18:52'),
(44, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:18:53'),
(37, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 16:18:08'),
(38, 'Chrome', '78.0.3904.97', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-04-16 16:18:08'),
(39, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 16:18:10'),
(40, 'Chrome', '78.0.3904.97', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-04-16 16:18:10'),
(41, 'Chrome', '81.0.4044.113', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-04-16 16:20:06'),
(47, 'Chrome', '78.0.3904.97', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-04-16 17:19:45'),
(48, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:20:02'),
(49, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:20:04'),
(50, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:20:05'),
(51, 'Chrome', '78.0.3904.97', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-16 17:20:05'),
(52, 'Chrome', '80.0.3987.163', 'PC', 'Window', 'http//odiablog.ml/?fbclid=IwAR1Qq7wTOk5ykI6EBrrdgK8toVu4-Od7EFxwgIjG14a93GISr5pvPJHJ6Jw&i=1', 'http://odiablog.ml/?fbclid=IwAR1Qq7wTOk5ykI6EBrrdgK8toVu4-Od7EFxwgIjG14a93GISr5pvPJHJ6Jw', '2020-04-17 07:59:56'),
(53, 'Chrome', '80.0.3987.163', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', 'http://odiablog.ml/?fbclid=IwAR1Qq7wTOk5ykI6EBrrdgK8toVu4-Od7EFxwgIjG14a93GISr5pvPJHJ6Jw&i=1', '2020-04-17 08:00:36'),
(54, 'Chrome', '74.0.3729.136', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-17 16:19:39'),
(55, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-18 05:05:18'),
(56, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-18 05:54:33'),
(57, 'Chrome', '79.0.3945.93', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-18 05:55:20'),
(58, 'Chrome', '79.0.3945.93', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', '', '2020-04-18 06:34:32'),
(59, 'Chrome', '79.0.3945.88', 'PC', 'Window', 'http//odiablog.ml/?fbclid=IwAR1vYWdqM0cRs3THi-KVDNne58rUYyrOjSvdmOFcpKvJ5IE1tP6-JEIKy2Y', '', '2020-04-18 16:03:39'),
(60, 'Chrome', '81.0.4044.113', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-20 19:04:32'),
(61, 'Chrome', '78.0.3904.96', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-21 18:37:11'),
(62, 'Chrome', '79.0.3945.88', 'PC', 'Window', 'http//odiablog.ml/?fbclid=IwAR3TWOIYtsHlg1L97O7mxJHW_Q2StQNLoEC4uW2bHeiOf0uhvs_jutcpGug', '', '2020-04-21 19:53:21'),
(63, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/', '', '2020-04-28 07:55:14'),
(64, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-28 07:55:14'),
(65, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/', '2020-04-28 07:55:23'),
(66, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/index.php', 'http://odiablog.ml/single_page.php?single=73', '2020-04-28 07:55:39'),
(67, 'Chrome', '81.0.4044.122', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-29 17:57:31'),
(68, 'Chrome', '81.0.4044.122', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%AC%E0%AC%BF%E0%AC%9C%E0%AD%8D%E0%AC%9E%E0%AC%BE%E0%AC%A8%20%E0%AC%B8%E0%AC%AE%E0%AD%8D%E0%AC%AE%E0%AC%A4', 'http://odiablog.ml/?i=1', '2020-04-29 17:57:46'),
(69, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-04-30 15:43:38'),
(70, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=2', 'http://odiablog.ml/?i=1', '2020-04-30 16:14:13'),
(71, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=2', '2020-04-30 16:14:19'),
(72, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/index.php?i=1', 'http://odiablog.ml/index.php', '2020-04-30 16:14:27'),
(73, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-01 16:15:03'),
(74, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-05-01 16:15:15'),
(75, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73&i=1', 'http://odiablog.ml/single_page.php?single=73', '2020-05-01 16:15:21'),
(76, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/single_page.php?single=73&i=1', '2020-05-01 16:15:24'),
(77, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-01 17:22:24'),
(78, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?fbclid=IwAR2VPO5-vTY6WIUjgcuFg0-2MDSffLit6wpmQMr9hPmrgREYAJ8rS8j-jAo&i=1', 'http://odiablog.ml/?fbclid=IwAR2VPO5-vTY6WIUjgcuFg0-2MDSffLit6wpmQMr9hPmrgREYAJ8rS8j-jAo', '2020-05-04 09:04:06'),
(79, 'Edge', '18.18362', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-05 10:14:38'),
(80, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-05 11:42:04'),
(81, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-06 13:57:24'),
(82, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-06 14:12:30'),
(83, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-06 15:05:42'),
(84, 'Firefox', '76.0', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-06 16:49:43'),
(85, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-07 06:58:25'),
(86, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-07 09:43:02'),
(87, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=2%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00', 'http://odiablog.ml/?i=1%20%3Cimg%20src=%22%22%20onerror=alert(0)%3E', '2020-05-07 09:43:07'),
(88, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/', 'http://13.127.27.168/Cross-Site-Scripting/Temporary-XSS-Variant-4/', '2020-05-07 09:43:59'),
(89, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=2%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00', 'http://odiablog.ml/?i=1%20%3Cimg%20src=%22%22%20onerror=alert(0)%3E', '2020-05-07 09:51:39'),
(90, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/?i=2%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00%00', 'http://odiablog.ml/?i=1%20%3Cimg%20src=%22%22%20onerror=alert(0)%3E', '2020-05-07 09:51:53'),
(91, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-07 09:51:59'),
(92, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8&i=1', 'http://odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', '2020-05-07 09:52:22'),
(93, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8&i=1%20%3Cu%3EHii%27%3C/u%3E', '', '2020-05-07 09:52:33'),
(94, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/index.php?i=1', 'http://odiablog.ml/index.php', '2020-05-07 09:54:21'),
(95, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/index.php?i=1%3CsCript%3Ealert(%22hacked%22);%3C/script%3E', '', '2020-05-07 09:54:24'),
(96, 'Chrome', '81.0.4044.129', 'PC', 'Window', 'http//odiablog.ml/index.php?i=1%3Cscript%3Ealert(%22hacked%22);%3C/script%3E', '', '2020-05-07 09:54:32'),
(97, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-07 16:36:58'),
(98, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-05-07 16:37:02'),
(99, 'Firefox', '76.0', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-08 06:34:44'),
(100, 'Firefox', '76.0', 'PC', 'Window', 'http//odiablog.ml/?i=2', 'http://odiablog.ml/?i=1', '2020-05-08 17:56:53'),
(101, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-09 14:59:10'),
(102, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-09 18:23:07'),
(103, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=2', 'http://odiablog.ml/?i=1', '2020-05-09 18:23:38'),
(104, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=3', 'http://odiablog.ml/?i=2', '2020-05-09 18:24:39'),
(105, 'Chrome', '80.0.3987.149', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-09 18:24:59'),
(106, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=3', 'http://odiablog.ml/?i=2', '2020-05-09 18:26:01'),
(107, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-09 18:26:11'),
(108, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=3', 'http://odiablog.ml/?i=2', '2020-05-09 18:27:47'),
(109, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-10 16:09:16'),
(110, 'Chrome', '77.0.3865.120', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-16 08:56:00'),
(111, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-16 08:56:32'),
(112, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-05-16 09:00:36'),
(113, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/single_page.php?single=73', '2020-05-16 09:01:17'),
(114, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', 'http://odiablog.ml/index.php', '2020-05-16 09:01:20'),
(115, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/index.php', '2020-05-16 09:01:27'),
(116, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=74', '', '2020-05-16 09:01:31'),
(117, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', 'http://odiablog.ml/index.php', '2020-05-16 09:04:23'),
(118, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', '2020-05-16 09:04:26'),
(119, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/index.php', '2020-05-16 09:04:29'),
(120, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/single_page.php?single=73', '2020-05-16 09:04:46'),
(121, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-16 09:23:44'),
(122, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', 'http://odiablog.ml/', '2020-05-16 09:24:01'),
(123, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%AC%E0%AC%BF%E0%AC%9C%E0%AD%8D%E0%AC%9E%E0%AC%BE%E0%AC%A8%20%E0%AC%B8%E0%AC%AE%E0%AD%8D%E0%AC%AE%E0%AC%A4', 'http://odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', '2020-05-16 09:24:19'),
(124, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%95%E0%AC%AC%E0%AC%BF%E0%AC%A4%E0%AC%BE', 'http://odiablog.ml/category_page.php?single=%E0%AC%AC%E0%AC%BF%E0%AC%9C%E0%AD%8D%E0%AC%9E%E0%AC%BE%E0%AC%A8%20%E0%AC%B8%E0%AC%AE%E0%AD%8D%E0%AC%AE%E0%AC%A4', '2020-05-16 09:24:24'),
(125, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-16 09:53:43'),
(126, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=74', 'http://odiablog.ml/', '2020-05-16 09:53:51'),
(127, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/single_page.php?single=74', '2020-05-16 09:54:36'),
(128, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/index.php', '2020-05-16 09:54:42'),
(129, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%B8%E0%AD%8D%E0%AD%B1%E0%AC%BE%E0%AC%B8%E0%AD%8D%E0%AC%A5%E0%AD%8D%E0%AD%9F', 'http://odiablog.ml/index.php', '2020-05-16 09:54:50'),
(130, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%B8%E0%AD%8D%E0%AD%B1%E0%AC%BE%E0%AC%B8%E0%AD%8D%E0%AC%A5%E0%AD%8D%E0%AD%9F', 'http://odiablog.ml/index.php', '2020-05-16 10:10:15'),
(131, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/category_page.php?single=%E0%AC%B8%E0%AD%8D%E0%AD%B1%E0%AC%BE%E0%AC%B8%E0%AD%8D%E0%AC%A5%E0%AD%8D%E0%AD%9F', '2020-05-16 10:10:20'),
(132, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=75', 'http://odiablog.ml/index.php', '2020-05-16 10:10:56'),
(133, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%AC%E0%AC%BF%E0%AC%9C%E0%AD%8D%E0%AC%9E%E0%AC%BE%E0%AC%A8%20%E0%AC%B8%E0%AC%AE%E0%AD%8D%E0%AC%AE%E0%AC%A4', 'http://odiablog.ml/single_page.php?single=75', '2020-05-16 10:11:14'),
(134, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%B8%E0%AD%8D%E0%AD%B1%E0%AC%BE%E0%AC%B8%E0%AD%8D%E0%AC%A5%E0%AD%8D%E0%AD%9F', 'http://odiablog.ml/category_page.php?single=%E0%AC%AC%E0%AC%BF%E0%AC%9C%E0%AD%8D%E0%AC%9E%E0%AC%BE%E0%AC%A8%20%E0%AC%B8%E0%AC%AE%E0%AD%8D%E0%AC%AE%E0%AC%A4', '2020-05-16 10:11:22'),
(135, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-16 15:06:52'),
(136, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=75', 'http://odiablog.ml/?i=1', '2020-05-16 15:07:03'),
(137, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-16 15:07:24'),
(138, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/single_page.php?single=74', 'http://odiablog.ml/?i=1', '2020-05-16 15:07:40'),
(139, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/single_page.php?single=74', 'http://odiablog.ml/single_page.php?single=74', '2020-05-16 15:08:01'),
(140, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=74', '', '2020-05-16 15:08:07'),
(141, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-17 15:02:18'),
(142, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', '', '2020-05-17 15:02:23'),
(143, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-05-17 15:02:57'),
(144, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:02:59'),
(145, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:03:13'),
(146, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:03:15'),
(147, 'unknown', 'unknown', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:03:16'),
(148, 'unknown', 'unknown', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:03:16'),
(149, 'unknown', 'unknown', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', '', '2020-05-17 15:03:16'),
(150, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', 'http://odiablog.ml/admin_login.php', '2020-05-17 17:27:09'),
(151, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', '', '2020-05-17 17:27:11'),
(152, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/index.php', '', '2020-05-17 17:27:18'),
(153, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-18 05:11:35'),
(154, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-05-18 05:11:54'),
(155, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/contactus.php', 'http://odiablog.ml/', '2020-05-18 05:11:59'),
(156, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-18 08:44:33'),
(157, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-19 09:03:57'),
(158, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-21 17:23:20'),
(159, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-22 16:56:56'),
(160, 'Chrome', '81.0.4044.138', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-22 18:02:03'),
(161, 'Chrome', '77.0.3865.120', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-05-28 11:49:08'),
(162, 'Chrome', '80.0.3987.132', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-01 15:21:25'),
(163, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-02 19:36:05'),
(164, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-06-02 19:36:14'),
(165, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-10 16:55:59'),
(166, 'Chrome', '72.0.3626.121', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-12 10:05:05'),
(167, 'Chrome', '69.0.3497.100', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-16 15:13:06'),
(168, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-17 04:09:02'),
(169, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-21 18:49:51'),
(170, 'Chrome', '83.0.4103.116', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-06-30 04:31:28'),
(171, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-07-07 20:48:58'),
(172, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-07-08 04:53:49'),
(173, 'Chrome', '81.0.4044.138', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-07-18 19:17:28'),
(174, 'Chrome', '85.0.4183.101', 'Mobile', 'Android', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-09-13 04:17:00'),
(175, 'Chrome', '86.0.4240.183', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-11-06 09:19:47'),
(176, 'Chrome', '86.0.4240.193', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-11-17 09:55:27'),
(177, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-11-20 16:01:08'),
(178, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/?i=1', '2020-11-20 16:02:44'),
(179, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/?i=1', 'http://odiablog.ml/', '2020-11-21 13:46:05'),
(180, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', 'http://odiablog.ml/?i=1', '2020-11-21 13:46:51'),
(181, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/category_page.php?single=%E0%AC%B8%E0%AD%8D%E0%AD%B1%E0%AC%BE%E0%AC%B8%E0%AD%8D%E0%AC%A5%E0%AD%8D%E0%AD%9F', 'http://odiablog.ml/category_page.php?single=%E0%AC%87%E0%AC%A4%E0%AC%BF%E0%AC%B9%E0%AC%BE%E0%AC%B8', '2020-11-21 13:49:39'),
(182, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-11-24 04:06:04'),
(183, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/single_page.php?single=73', 'http://odiablog.ml/', '2020-11-24 04:36:13'),
(184, 'Chrome', '86.0.4240.198', 'PC', 'Window', 'http//odiablog.ml/', '', '2020-11-24 06:01:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitor`
--
ALTER TABLE `visitor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `visitor`
--
ALTER TABLE `visitor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
