
<?php 
error_reporting(0);
session_start();
if ($_SESSION['email']==true) {
  # code...
}else{
   header('location:admin_login.php');
}
$page='conctview';
include('include/header.php'); 

?>

<div style="width:70%;margin-left: 25%;margin-top: 10%">

	  
<h1>Conctus Page</h1>


<table class="table table-boardered">
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Description</th>
		<!-- <th>Delete</th> -->
	   
	</tr>

	<?php
	include('db/connection.php');

    $page = $_GET['page'];
    
    if ($page=="" || $page=="1") {
    	$page1=0;
    }else{
    	$page1=($page*7)-7;
    }


     $query=mysqli_query($conn,"select * from contact limit $page1,7");
     while($row=mysqli_fetch_array($query)){



	?>
	<tr>
		<td><?php echo $row['id'];?></td>
		<td><?php echo $row['name'];?></td>
		<td><?php echo $row['msg']?></td>
	


 

  
		<!-- <td> <a href="news_delete.php?delete=<?= $row['id'] ?>" class="btn btn-danger">Delete</a></td> -->
		
	</tr>


<?php }

$sql=mysqli_query($conn,"select * from news");
$count=mysqli_num_rows($sql);

$a=$count/3;
 $a=ceil($a);

	for ($i=1; $i < $a ; $i++) { 
		?>
	</table>
	<ul class="pagination">
		<li class="page-item"><a class="page-link" href="news.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
	

<?php } ?>

</ul>
	
</table>




</div>

<?php
include('include/footer.php')

?>
