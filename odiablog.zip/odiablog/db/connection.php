<!-- <?php
         $username = "epiz_25460887";
         $host = "sql312.epizy.com";
         $password = "FoyLwMQzQ0z";
         $database_name = "epiz_25460887_news";
           $conn =mysqli_connect($host, $username, $password, $database_name);
        


?> -->

<?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "news";

  // Create connection
  // $conn = new mysqli($servername, $username, $password, $dbname);
   $conn =mysqli_connect($servername, $username, $password, $dbname);

?>
