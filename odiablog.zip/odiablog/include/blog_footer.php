<!DOCTYPE html>
<html>
<head>
	<title></title>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<style type="text/css">
	* Footer */
@import url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
section {
    padding: 40px 0;
}

section .section-title {
    text-align: center;
    color: #007b5e;
    margin-bottom: 50px;
    text-transform: uppercase;
}
#footer {
    background: #007b5e !important;
    width: 100%;
}
#footer h5{
	padding-left: 10px;
    border-left: 3px solid #eeeeee;
    padding-bottom: 6px;
    margin-bottom: 20px;
    color:#ffffff;
}
#footer a {
    color: #ffffff;
    text-decoration: none !important;
    background-color: transparent;
    -webkit-text-decoration-skip: objects;
}
#footer ul.social li{
	padding: 3px 0;
}
#footer ul.social li a i {
    margin-right: 5px;
	font-size:25px;
	-webkit-transition: .5s all ease;
	-moz-transition: .5s all ease;
	transition: .5s all ease;
}
#footer ul.social li:hover a i {
	font-size:30px;
	margin-top:-10px;
}
#footer ul.social li a,
#footer ul.quick-links li a{
	color:#ffffff;
}
#footer ul.social li a:hover{
	color:#eeeeee;
}
#footer ul.quick-links li{
	padding: 3px 0;
	-webkit-transition: .5s all ease;
	-moz-transition: .5s all ease;
	transition: .5s all ease;
}
#footer ul.quick-links li:hover{
	padding: 3px 0;
	margin-left:5px;
	font-weight:700;
}
#footer ul.quick-links li a i{
	margin-right: 5px;
}
#footer ul.quick-links li:hover a i {
    font-weight: 700;
}

@media (max-width:767px){
	#footer h5 {
    padding-left: 0;
    border-left: transparent;
    padding-bottom: 0px;
    margin-bottom: 10px;
}
}

</style>
</head>
<body>



<!-- Footer -->
	<section id="footer">
		<div class="container">
			<div class="row text-center text-xs-center text-sm-left text-md-center">
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5 style="margin-top: 50px">ମୁଁ କିଏ!!!</h5>
					<p style="text-align: justify;">ଓଡିଶା ପୂର୍ବ ଓଡ଼ିଶା ମଧ୍ୟ ଭାରତର ପୂର୍ବ ଉପକୂଳରେ ଅବସ୍ଥିତ ଏକ ଭାରତୀୟ ରାଜ୍ୟ | ଏହା ପଶ୍ଚିମବଙ୍ଗ ଏବଂ ଉତ୍ତରରେ h ାଡଖଣ୍ଡ, ପଶ୍ଚିମରେ ଛତିଶଗଡ ଏବଂ ଦକ୍ଷିଣରେ ଆନ୍ଧ୍ରପ୍ରଦେଶର ପଡୋଶୀ ଦେଶ ଅଟେ। ବଙ୍ଗୋପସାଗରରେ ଓଡ଼ିଶାର ଉପକୂଳ 485 କିଲୋମିଟର (301 ମାଇଲ) ରହିଛି। କ୍ଷେତ୍ର ଅନୁଯାୟୀ ଏହା ଅଷ୍ଟମ ବୃହତ୍ତମ ରାଜ୍ୟ ଏବଂ ଜନସଂଖ୍ୟା ଅନୁଯାୟୀ ଏକାଦଶ ବୃହତ୍ତମ ରାଜ୍ୟ | ଭାରତରେ ଅନୁସୂଚିତ ଜନଜାତିର ତୃତୀୟ ବୃହତ୍ତମ ଜନସଂଖ୍ୟା ଅଛି।</p>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5 style="margin-top: 50px">ବର୍ଗ</h5>
					<ul class="list-unstyled quick-links">

						 <?php 
           include('db/connection.php');

           $query5=mysqli_query($conn,"select * from category limit 1,5");

       while ($row3=mysqli_fetch_array($query5)) {
             $category1= $row3['category_name'];
                   ?>
           
            <li > <a  class="p-2 text-muted" href="category_page.php?single=<?php echo $category1;?>"><i class="fa fa-angle-double-right" style="color: white"></i>'<span style="color:#AFA;text-align:center;"><?php echo $category1;   ?></span>'</a></li>

               <?php  } ?>


					
						
					</ul>
				</div>
				<div class="col-xs-12 col-sm-4 col-md-4">
					<h5 style="margin-top: 50px">ଦ୍ରୁତ ଲିଙ୍କ୍ |</h5>
					<ul class="list-unstyled quick-links">
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>ମୂଳ ପୃଷ୍ଠା</a></li>
						<li><a href="contactus.php"><i class="fa fa-angle-double-right"></i>ଯୋଗାଯୋଗ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>ବିଜ୍ଞାପନ</a></li>
						<li><a href="javascript:void();"><i class="fa fa-angle-double-right"></i>ନିୟମାବଳୀ</a></li>
						<li><a href="admin_login.php"><i class="fa fa-angle-double-right"></i>ପ୍ରଶାସକ</a></li> 
					</ul>
				</div>
			</div><hr>
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
					<ul class="list-unstyled list-inline social text-center">
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
						<li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
					</ul>
				</div>
				</hr>
			</div>	
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
					
					<p class="h6">&copy All right Reversed.<a class="text-green ml-2" href="#" >ODiablog</a></p>
				</div>
				</hr>
			</div>	
		</div>
	</section>
	<!-- ./Footer -->

	</body>
</html>