<?php
error_reporting(0);


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">
<title>My Odisha</title>

    <!-- Add to HTML Head -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<script src="https://cdn.jsdelivr.net/sharer.js/latest/sharer.min.js"></script>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="style/bootstarp.min.css" rel="stylesheet">
    <link href="style/blog.css" rel="stylesheet">

  
  </head>

  <body>

    <div class="container" >
      <header class="blog-header py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
          <div class="col-4 pt-1">
           
          </div>
          <div class="col-4 text-center">
            <a class="blog-header-logo text-dark" href="#">| ଓଡିଆ ଚ୍ୟାନେଲ୍ |</a>
          </div>
          <div class="col-4 d-flex justify-content-end align-items-center">
           <div class="md-form mt-0">
           <!--  <form action="search.php" method="post">
  <input class="form-control" type="text" placeholder="Search" </form> -->
</div>&nbsp&nbsp
           
          </div>
        </div>
      </header>
  <!-- menu -->
      <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
           <a class="p-2 text-muted" href="index.php">Home</a>

            <?php 
           include('db/connection.php');

           $query5=mysqli_query($conn,"select * from category");

       while ($row3=mysqli_fetch_array($query5)) {
             $category1= $row3['category_name'];
                   ?>
           
             <a class="p-2 text-muted" href="category_page.php?single=<?php echo $category1;?>"><?php echo $category1; ?></a>

               <?php  } ?>


         
        </nav>
      </div>