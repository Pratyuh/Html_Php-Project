<?php
include('visitor/Mobile_Detect.php');
include('visitor/BrowserDetection.php');
include('db/connection.php');
error_reporting(0);

$browser=new Wolfcast\BrowserDetection;

$browser_name=$browser->getName();
$browser_version=$browser->getVersion();

$detect=new Mobile_Detect();

if($detect->isMobile()){
  $type='Mobile';
}elseif($detect->isTablet()){
  $type='Tablet';
}else{
  $type='PC';
}

if($detect->isiOS()){
  $os='IOS';
}elseif($detect->isAndroidOS()){
  $os='Android';
}else{
  $os='Window';
}

$url=(isset($_SERVER['HTTPS'])) ? "https":"http";
$url.="//$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$ref='';
if(isset($_SERVER['HTTP_REFERER'])){
  $ref=$_SERVER['HTTP_REFERER'];
}
$sql="insert into visitor(browser_name,browser_version,type,os,url,ref) values('$browser_name','$browser_version','$type','$os','$url','$ref')";
mysqli_query($conn,$sql);
?>

<?php
error_reporting(0);


?>

<?php
error_reporting(0);


?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
       <!-- Add to HTML Head -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<script src="https://cdn.jsdelivr.net/sharer.js/latest/sharer.min.js"></script>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap core CSS -->
    <link href="style/bootstarp.min.css" rel="stylesheet">
    <link href="style/blog.css" rel="stylesheet">
  </head>

  <body>

    <div class="container">
      <nav class="navbar sticky-top navbar-light bg-light">
  <a class="navbar-brand" href="#">
    <img src="img/logo.png" width="200" height="50" class="d-inline-block align-top" alt="">
  </a>
</nav>
  <!-- menu -->
      <div class="nav-scroller py-1 mb-2">
        <nav class="nav d-flex justify-content-between">
           <a class="p-2 text-muted" href="index.php">Home</a>

            <?php 
           include('db/connection.php');

           $query5=mysqli_query($conn,"select * from category");

       while ($row3=mysqli_fetch_array($query5)) {
             $category1= $row3['category_name'];
                   ?>
           
             <a class="p-2 text-muted" href="category_page.php?single=<?php echo $category1;?>"><?php echo $category1; ?></a>

               <?php  } ?>


         
        </nav>
      </div>


      <div class="jumbotron p-3 p-md-5 text-white rounded bg-dark">
        <div class="col-md-6 px-0">
          <h1 class="display-4 font-italic">Title of a longer featured blog post</h1>
          <p class="lead my-3">Multiple lines of text that form the lede, informing new readers quickly and efficiently about what's most interesting in this post's contents.</p>
          <p class="lead mb-0"><a href="#" class="text-white font-weight-bold">Continue reading...</a></p>
        </div>
      </div>


   

    </div>

 <main role="main" class="container">
      <div class="row">
        <div class="col-md-8 blog-main">
<div class="row mb-2">
    <?php

 include('db/connection.php');
  $id=$_GET['single'];

$query3=mysqli_query($conn,"select * from news where category='$id' ");

while($row=mysqli_fetch_array($query3)){ 
 $category=$row['category'];
  $title=$row['title'];
  $date=$row['date'];
   $thubnail=$row['thumbline'];
    $des=$row['description'];


   ?>
 <div class="col-md-6" style="margin-top: 20px">
  
          <div class="card flex-md-row mb-4 box-shadow h-md-250">
            <div class="card-body d-flex flex-column align-items-start">
              <strong class="d-inline-block mb-2 text-primary"><?php echo $category;?></strong>
              <h3 class="mb-0">
                <a class="text-dark" href="#"><?php echo $title;?></a>
              </h3>
              <div class="mb-1 text-muted"><?php echo $date;?></div>
              <p class="card-text mb-auto"><?php echo substr( $des,0,50);?></p>

              <a href="single_page.php?single=<?php echo $row['id']?>">Continue reading</a>
            </div>
      
          </div>
        </div>

     
<?php } ?>
  
    
</div>
   


       

          

        </div><!-- /.blog-main -->

        <aside class="col-md-4 blog-sidebar">
          <div class="p-3 mb-3 bg-light rounded">
            <h4 class="font-italic">About</h4>
            <p class="mb-0">Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
          </div>

  

     <div class="p-3">
       <h4 class="font-italic">Category</h4> <hr>
       <?php 
   include('db/connection.php');

   $query=mysqli_query($conn,"select * from category limit 1,4");

   while ($row=mysqli_fetch_array($query)) {
    $category= $row['category_name'];
    ?>
           
            <ol class="list-unstyled mb-0">

               <li><a href="category_page.php?single=<?php echo $category;?>"><?php echo $category; ?></a></li>
              
            </ol>
              <?php  } ?>
          </div>

            <div class="p-3">
       <h4 class="font-italic">Date</h4><hr>
       <?php 
   include('db/connection.php');

   $query=mysqli_query($conn,"select * from news  limit 1,4");

   while ($row=mysqli_fetch_array($query)) {
    $date= $row['date'];
    ?>
           
            <ol class="list-unstyled mb-0">

              <li><a href="#"><?php echo $date; ?></a></li>
              
            </ol>
              <?php  } ?>
          </div>





         

          <div class="p-3">
            <h4 class="font-italic">Elsewhere</h4>
            <ol class="list-unstyled">
              <li><a href="#">GitHub</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Facebook</a></li>
            </ol>
          </div>

        </aside><!-- /.blog-sidebar -->

      </div><!-- /.row -->

    </main><!-- /.container -->

      <?php
include('include/blog_footer.php'); 

?>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <script>
      Holder.addTheme('thumb', {
        bg: '#55595c',
        fg: '#eceeef',
        text: 'Thumbnail'
      });
    </script>
  </body>
</html>
