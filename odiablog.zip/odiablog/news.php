
<?php 
error_reporting(0);
session_start();
if ($_SESSION['email']==true) {
  # code...
}else{
   header('location:admin_login.php');
}
$page='news';
include('include/header.php'); 

?>

<div style="width:70%;margin-left: 25%;margin-top: 10%">

	  <div class="breadcrumb">
 
  
  <li class="breadcrumb-item active"><a href="news.php">News</a></li>
   <li class="breadcrumb-item ">
   <a href="addnews.php">Add News</a>
   </li>
   

  </div>

	<div class="text-right">
		<button class="btn btn-secondary"><a href="addnews.php">Add News</a></button>
	</div>


<table class="table table-boardered">
	<tr>
		<th>ID</th>
		<th>Title</th>
		<th>Description</th>
	    <th>Date</th>
		<th>Category</th>
		<th>Thumbline</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>

	<?php
	include('db/connection.php');

    $page = $_GET['page'];
    
    if ($page=="" || $page=="1") {
    	$page1=0;
    }else{
    	$page1=($page*7)-7;
    }


     $query=mysqli_query($conn,"select * from news limit $page1,7");
     while($row=mysqli_fetch_array($query)){



	?>
	<tr>
		<td><?php echo $row['id'];?></td>
		<td><?php echo $row['title'];?></td>
		<td><?php echo substr($row['description'],0,200);?></td>
		<td><?php echo $row['date'];?></td>
		<td><?php echo $row['category'];?></td>

		<td> <img src="images/<?php echo $row['thumbline']; ?>" width="150" height="150" /> </td>

 

     <td> <a href="news_edit.php?edit=<?= $row['id'] ?>" class="btn btn-info">Edit</a></td>
		<td> <a href="news_delete.php?delete=<?= $row['id'] ?>" class="btn btn-danger">Delete</a></td>
		
	</tr>


<?php }

$sql=mysqli_query($conn,"select * from news");
$count=mysqli_num_rows($sql);

$a=$count/3;
 $a=ceil($a);

	for ($i=1; $i < $a ; $i++) { 
		?>
	</table>
	<ul class="pagination">
		<li class="page-item"><a class="page-link" href="news.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
	

<?php } ?>

</ul>
	
</table>




</div>

<?php
include('include/footer.php')

?>
