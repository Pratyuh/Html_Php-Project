$(document).ready(function(){

$(".scrolltop").click(function(){$("html,body").animate({scrollTop:$("#content").offset().top},"1000");return false})

  $("#scroll").click(function(){$("html,body").animate({scrollTop:$("#about").offset().top},"1000");return false})
})