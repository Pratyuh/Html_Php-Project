<?php
include "header.php"; ?>
<?php include "intro-about.php"; ?>
<?php include "gallery.php"; ?>
<?php include "expert.php"; ?>
<?php include "sponser.php"; ?>
<style type="text/css">
input[type="text"]
{
font-size:15px;
border-radius: 10px;
}
input[type="email"]
{
font-size:15px;
border-radius: 10px;
}
input[type="password"]
{
font-size:15px;
border-radius: 10px;
}
@media (max-height: 600px) {
#modalLRForm{
margin: 50px;
}
}
</style>
<!--==========================
Subscribe Section
============================-->
<footer id="footer">
  <div class="footer-top">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6 footer-info">
         <img src="img/lo.png" style="width: 300px; height: 150px;">
          <h2 style="color: #fff; size: 60px; font-weight: 50px; text-align: center;">mXplore Vol.1</h2>
          <p style="text-align: justify;">MXplore Vol.1 is a Mechanical Engineering Techno Symposium organised by Dept. of Mechanical Engineering and Society Of Mechanical Advancements of Government College of Engineering, Keonjhar</p>
        </div>
        <div class="col-lg-4 col-md-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="fa fa-angle-right"></i> <a href="main">Home</a></li>
            <li><i class="fa fa-angle-right"></i> <a href="event">Events</a></li>
            <li><i class="fa fa-angle-right"></i> <a href="schedule">Schedule</a></li>
            <li><i class="fa fa-angle-right"></i> <a href=""data-toggle="modal" data-target="#exampleModal">Contact Us</a></li>
          </ul>
        </div>
        <div class="col-lg-4 col-md-6 footer-contact">
          <h4>Follow Us</h4>
          
          <div class="social-links">
            
            <a href="https://m.facebook.com/Mxplore-106201624152956/?view_public_for=106201624152956" class="facebook"><i class="fa fa-facebook"></i></a>
            <a href="https://www.instagram.com/mxplore_v1?r=nametag"><i class="fa fa-instagram"></i></a>
            <a href="mailto:mxplore@gcekjr.ac.in" target="_top"><i class="fa fa-envelope"></i></a>
            <a href="tel:8895384889" target="_top"><i class="fa fa-phone"></i></a>
            <a href="https://youtu.be/nVtsKddpd2I"><i class="fa fa-youtube"></i></a>
            
          </div><br><br>
          <div class="social-links">
            <div class="mapouter"><div class="gmap_canvas"><iframe width="290" height="170" id="gmap_canvas" src="https://maps.google.com/maps?q=GOVERNMENT%20COLLEGE%20OF%20ENGINEERING%2C%20KEONJHAR&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div><style>.mapouter{position:relative;text-align:right;height:180px;width:290px;margin-left: 10px;}.gmap_canvas {overflow:hidden;background:none!important;height:180px;width:290px;margin-left: 10px;}</style></div>
            
          </div>
        </div>
        <div class="col-lg-2 col-md-2 footer-info">
        </div>
        
      </div>
    </div>
  </div>
  <div class="container">
    <div class="copyright">
      &copy; Designed By Pratyusa and Ajit
    </div>
    <div class="credits">
    </div>
  </div>
  </footer><!-- #footer -->
  
  <!-- MODAL SIGNIN SIGNUP FORM -->
  
  <!--Modal: Login / Register Form-->
  <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true"style="height: 520px;padding: 0px; margin: 0px; margin-top: 55px;">
      
    <div class="modal-dialog cascading-modal" role="document" style="padding:0px;">
      <!--Content-->
      
      <div class="modal-content"  style="background-color: #F1F0EC; border: 25px solid #E1DDD3; " >
          
          
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="font-size: 50px;">&times;</span>
        </button>
        
        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab" style="font-size:20px; font-weight: bold;width: 150px;">
            Log in</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" data-toggle="tab" href="#panel8" role="tab" style="font-size: 20px; font-weight: bold;width: 150px;">
            Register</a>
          </li>
        </ul>
        <!-- Tab panels -->
        <div class="tab-content p-3">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">
            <!--Body-->
            <div class="modal-body mb-1">
              <form method="post" action="login">
                <div class="md-form form-sm mb-5">
                  <input type="email" id="login-email" class="form-control form-control-sm validate p-3" name="email">
                  <label data-error="wrong" data-success="right" for="modalLRInput10" required>Your email</label>
                </div>
                <div class="md-form form-sm mb-4">
                  <input type="password" id="login-password" class="form-control form-control-sm validate p-3" name="password" required>
                  <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label>
                </div>
                <a href="forgetpass" style="float: right; color: red; margin-bottom: 10px;">Forget Password</a>
                <div class="text-center mt-2">
                  <input style="font-size: 20px; font-weight: bold; background-color:#1FA80C;color: white;" type="submit" class="btn btn-success btn-block p-3" id="user_login-btn" value="Log in">
                </div>
              </form>
            </div>
          </div>
          <!--/.Panel 7-->
          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">
            <!--Body-->
            <div class="modal-body">
              <form method="post" action="registration">
                <div class="md-form form-sm mb-5">
                 
                  <label data-error="wrong" data-success="right" for="modalLRInput12" >Name:</label>
                   <input type="text" id="name" class="form-control form-control-sm validate p-3" required name="name">
                </div>
                <div class="md-form form-sm mb-5">
                
                  <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail:</label>
                    <input type="email" id="email" class="form-control form-control-sm validate p-3" required name="email">
                </div>
                <div class="md-form form-sm mb-5">
                 
                  <label data-error="wrong" data-success="right" for="modalLRInput12">School/College Name:</label>
                   <input type="text" id="college_name" class="form-control form-control-sm validate p-3" name="college_name"  required name="college_name">
                </div>
                <div class="md-form form-sm mb-5">
                
                  <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no:</label>
                    <input type="text" id="phone_no" class="form-control form-control-sm validate p-3" name="phone_no" required name="phone_no">
                </div>
                <div class="md-form form-sm mb-5">
                                                <input id="phone_no" class="form-control form-control-sm validate p-3" name="payment"  value="Pending" type="hidden">
                                               
                                            </div>
                
                <div class="md-form form-sm mb-5">
                  <input id="phone_no" class="form-control form-control-sm validate p-3" name="submitbtn"  value="SUBMIT" type="hidden">
                  
                </div>
                
                <div class="md-form form-sm mb-4">
                 
                  <label data-error="wrong" data-success="right" for="modalLRInput14" required>Password (6 characters minimum):</label>
                   <input type="password" id="password" class="form-control form-control-sm validate p-3" name="password" minlength="6">
                </div>
                <div class="text-center form-sm mt-2">
                  <input style="font-size: 20px; font-weight: bold; background-color:#1FA80C;color: white;" type="submit" name="submit" class="btn btn-info btn-block  p-3" id="signup" value="Sign up">
                </div>
              </form>
            </div>
         
          </div>
          <!--/.Panel 8-->
        </div>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->
<!-- JavaScript Libraries -->
<script src="lib/jquery/jquery.min.js"></script>
<script src="lib/jquery/jquery-migrate.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/superfish/hoverIntent.js"></script>
<script src="lib/superfish/superfish.min.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/venobox/venobox.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="js/modal.js"></script>
<!-- Contact Form JavaScript File -->
<script src="contactform/contactform.js"></script>
<!-- Template Main Javascript File -->
<script src="js/main.js"></script>
<script>
$(document).ready(function(){
$("#login-btn").on("click", function() {
var login_email = $("#login-email").val();
var login_password = $("#login-password").val();
if(login_email.length == 0 && login_password.length == 0){
alert("Please enter all the field");
}else{
$.ajax({
url: "login.php",
type: "post",
data: {
email: login_email,
password: login_password
},
success: function(result) {
if (result == "success refresh Your Page") {
window.location.href = "event";
} else {
alert(result);
}
},
error: function(error) {
alert(error);
}
});
}
});
//     $("#signup").on("click", function() {
//     var name = $("#name").val();
//     var email = $("#email").val();
//     var college_name = $("#college_name").val();
//     var branch = $("#branch").val();
//     var password = $("#password").val();
//     var phone_no = $("#phone_no").val();
//     if(name.length == 0 && college_name.length == 0){
//         alert("Please enter all fields");
//     } else {
//     $.ajax({
//         url: "registration.php",
//         type: "post",
//         data: {
//             registration: "success",
//             name: name,
//             email: email,
//             password: password,
//             college_name: college_name,
//             branch: branch,
//             phone_no: phone_no
//         },
//         success: function(result) {
//             if (result == "success") {
//                 window.location.href = "event.php";
//             } else {
//                 alert(result);
//             }
//         },
//         error: function(error) {
//             alert(error);
//         }
//     });
//     }
// });
});
</script>
</body>
</html>