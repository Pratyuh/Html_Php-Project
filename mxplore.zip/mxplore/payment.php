<?php

    echo $id = $_GET['id'];
    include "DbConnect.php";

    $update = "UPDATE users SET sucess = 'SUBMITTED' WHERE id = '$id'";

    $query_result = mysqli_query($con, $update);

    if(!$query_result) {
        
        echo mysqli_error($con);
    }
    
    header('Location: registered_event.php?msg=Updated Successfully');
    mysqli_close($con);
?>