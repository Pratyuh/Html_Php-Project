-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2019 at 06:08 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mxplore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `time_stamp`) VALUES
(15454, 'mxplore', 'mxplore', '2019-09-10 10:45:28');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `event_name` varchar(500) NOT NULL,
  `event_desc` varchar(700) NOT NULL,
  `event_image` varchar(255) NOT NULL DEFAULT 'event.jpg',
  `event_pdf` varchar(500) NOT NULL,
  `event_date` date NOT NULL,
  `event_rules` varchar(255) NOT NULL,
  `event_price` varchar(255) NOT NULL,
  `prize_money` varchar(1000) NOT NULL,
  `added_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_desc`, `event_image`, `event_pdf`, `event_date`, `event_rules`, `event_price`, `prize_money`, `added_time`) VALUES
(48, 'ved', 'Writer Aaron Mahnke launched his podcast ', 'Screenshot (17).png', '', '2019-11-09', 'Writer Aaron Mahnke launched his podcast ', '20', '232', '2019-11-06 19:17:46'),
(50, 'Paper Dance', '1. Lorem Ipsum is simply dummy text of the printing and typesetting industry. <br><br> 2.Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.<br><br> 3. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, <br><br>and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', '', '', '0000-00-00', 'gfgf', '1st 1000 <br> 2nd 2000', '1st Prize Rs:1000 <br> 2nd Prize Rs: 2000 <br> 3rd Prize is:50', '2019-11-23 17:53:14'),
(49, 'Paper Dance', '', '', '', '2019-11-14', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has su', '522', '852', '2019-11-07 15:40:12');

-- --------------------------------------------------------

--
-- Table structure for table `notice`
--

CREATE TABLE `notice` (
  `id` int(11) NOT NULL,
  `event_desc` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice`
--

INSERT INTO `notice` (`id`, `event_desc`) VALUES
(20, 'hello\r\n'),
(21, 'kguygyghfh\'\'\';;\'\';;-='),
(22, 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but');

-- --------------------------------------------------------

--
-- Table structure for table `registered_events`
--

CREATE TABLE `registered_events` (
  `regd_id` int(11) NOT NULL,
  `event_id` int(20) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_price` varchar(100) NOT NULL,
  `user_id` int(10) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_mobile` varchar(10) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `college_name` varchar(300) NOT NULL,
  `regd_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registered_events`
--

INSERT INTO `registered_events` (`regd_id`, `event_id`, `event_name`, `event_price`, `user_id`, `user_name`, `user_mobile`, `branch_name`, `college_name`, `regd_time`) VALUES
(207, 49, 'Paper Dance', '522', 137, 'Pratyusa Dwibedy', '0707707934', '', 'gce', '2019-11-07 18:53:47'),
(200, 49, 'Paper Dance', '522', 138, 'Prasant Dwibedy', '0943904239', '', 'gce', '2019-11-07 17:50:32'),
(215, 48, 'ved', '20', 143, 'Pratyusa Dwibedy', '0707707934', '', 'fdz', '2019-11-23 18:39:30'),
(217, 49, 'Paper Dance', '522', 144, 'Pratyusa Dwibedy', '0707707934', '', 'Govt. College Of Engineering,Keonjhar', '2019-11-25 12:51:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `image` varchar(500) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Payment` varchar(20) NOT NULL,
  `sucess` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `branch`, `mobile_no`, `college_name`, `image`, `login_time`, `Payment`, `sucess`) VALUES
(144, 'Pratyusa Dwibedy', 'pratyushcool04@gmail.com', '123456', '', '0707707934', 'Govt. College Of Engineering,Keonjhar', '', '2019-11-25 12:42:30', 'Pending', 'SUBMIT'),
(143, 'Pratyusa Dwibedy', 'pratyusacool@gmail.com', 'fdzfdzda', '', '0707707934', 'fdz', '', '2019-11-21 14:56:47', 'Pending', 'SUBMIT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registered_events`
--
ALTER TABLE `registered_events`
  ADD PRIMARY KEY (`regd_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15455;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `notice`
--
ALTER TABLE `notice`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `registered_events`
--
ALTER TABLE `registered_events`
  MODIFY `regd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
