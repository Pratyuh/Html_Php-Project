<?php
session_start();
include "DbConnect.php";
$u_id = $_SESSION['id'];

$s_sql = "SELECT * FROM registered_events WHERE user_id = '$u_id'";
$result = mysqli_query($con, $s_sql);

$s_sql1 = "SELECT * FROM users WHERE id = '$u_id'";
$result1 = mysqli_query($con, $s_sql1);

$s_sql2 = "SELECT * FROM users WHERE id = '$u_id'";
$result2 = mysqli_query($con, $s_sql2);

$s_sql3 = "SELECT * FROM users WHERE id = '$u_id'";
$result3 = mysqli_query($con, $s_sql3);

$s_sql4 = "SELECT * FROM users WHERE id = '$u_id'";
$result4 = mysqli_query($con, $s_sql4);


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Registered Event</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">
        <!-- Favicons -->
        <link href="img/favicon.png" rel="icon">
        <link href="img/apple-touch-icon.png" rel="apple-touch-icon">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


        <!-- Bootstrap CSS File -->
        <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Libraries CSS Files -->
        <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/venobox/venobox.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <!-- Main Stylesheet File -->
        <link href="css/style.css" rel="stylesheet">
        <link rel="stylesheet" href="css/event.css">
        <link rel="stylesheet" href="css/style2.css">
    </head>
    <body>
        <header id="header" style="background: rgba(0,0,0,0.6);">
            <div class="container">
                <div id="logo" class="pull-left">
                    <!-- Uncomment below if you prefer to use a text logo -->
                    <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                    <a href="index.php"><img src="img/kk.png" alt="" title="" style="width: 200px; height: 40px;"></a>
                </div>
                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <?php if(isset($_SESSION['id'])){
                        
                        ?>
                        <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                        <li><a href="main">Home</a></li>
                        <li><a href="event">Events</a></li>
                        <li class="menu-active"><a href="registered_event">My Registered Events</a></li>
                        <li><a href="schedule">Schedule</a></li>
                        <li><a href="logout"><i class="fa fa-sign-out"> </i> Logout </a></li>
                        <?php }else{ ?>
                        <li><a href="main">Home</a></li>
                        <li class="menu-active"><a href="event">Events</a></li>
                        <li><a href="schedule">Schedule</a></li>
                        <li><a href='' data-toggle="modal" data-target="#modalLRForm">Create a account</a></li>
                        <?php } ?>
                    </ul>
                    </nav><!-- #nav-menu-container -->
                </div>
                </header><!-- #header -->
                <div class="container" style = "padding-top:120px; margin-top:50px;padding-bottom:80px;margin-bottom:80px; ">
                    <div class="row">
                        <div class="col-sm-12 col-md-2 col-lg-2">
                        </div>
                        <div class="col-sm-12 col-md-8 col-lg-8">
                            <h1 class="text-center ">
                            Registered Events by <u style="text-transform: uppercase;"> <?php echo $_SESSION['name']; ?></u>

                             <h3 style="margin-top: 20px; font-size: 20px; color: red; text-align: justify;font-weight: bold;">Note:- Kindly verify before submitting. After clicking on submit button You Can't be able to add or delete any event .</h3>

                            </h1>
                            <table class="table" id="table">
                                <thead>
                                    <th>No.</th>
                                    <th>Event Name </th>
                                    <th>Registration Fee (In Rs:)</th>
                                   
                                    
                                </thead>

                                <tbody>
                                    <?php
                                    $i =0;
                                     while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                                    ?>
                                    <tr>
                                        <td> <?php echo $i =$i+1; ?> </td>
                                        <td><?php echo $row['event_name']; ?></td>
                                    <center> <td><?php echo $row['event_price']; ?></td></center>



                                       
                                        
                                    </tr>
                                    <?php } ?>

                                </tbody>
                             
                            </table>

                            <center>
                             <span id="val"></span>  
                            

                             


                                 <p>   <span id="val"></span>  </p>


                                <table>
                                    <?php if ((mysqli_num_rows($result1)) > 0) {
                                    while($row1 = mysqli_fetch_array($result1)) {
                                    ?>
                                    <tr>
                                        
                                        <?php
                                        
                                        $status = $row1["sucess"];
                                        
                                        if($status == 'SUBMIT') {
                                        
                                        
                                        ?>
                                        
                                        <td><a style="background-color: red; color: white;font-size: 18px; border-radius: 12px;" href="payment.php?id=<?php echo $name = $row1['id']; ?>" class="btn red submitted"><?php echo $name = $row1["sucess"]; ?><a/></td>
                                        
                                        <?php  } else {?>
                                        <td><a style="background-color:gray;color: white;font-size: 18px; border-radius: 12px;" href="" class="btn  submitted disabled"><?php echo $name = $row1["sucess"]; ?><a/></td>
                                        
                                        <?php } ?>
                                        
                                    </tr>
                                    <?php
                                    
                                    }
                                    } else {
                                    echo "no results";
                                    }
                                    
                                    ?>
                                </table>

                                 <b style="padding: 10px; font-size: 16px; color: red;">After submitting Click On "scan to pay" complete the payment and upload your payment confirmation by clicking on the "Browse" button below.</b> <br> <b style="padding: 10px; font-size: 16px; color: red;">Kindly wait for 24hr your registration status will be verified once we verify the payment.</b>


                                   <br>

                         
                                    <?php if ((mysqli_num_rows($result3)) > 0) {
                                    while($row3 = mysqli_fetch_array($result3)) {
                                    ?>
                                    <tr>
                                        
                                        <?php
                                        
                                        $status1 = $row3["sucess"];
                                        
                                        if($status1 == 'SUBMITTED') {
                                        
                                        
                                        ?>
                                        
                                     
                                            <a style="background-color: green;  color: white; padding: 10px; font-size: 18px;border-radius: 12px;" href="" data-toggle="modal" data-target="#myModal1" >Scan To Pay</a>

                                              <a style="background-color: green;  color: white; padding: 5px;border-radius: 12px; font-size: 18px;" target="_blank" href="https://docs.google.com/forms/d/e/1FAIpQLSeU88ezh7izN1e_PrqwMdwthxFXXD1ZsvSRLWo_20WpyDQa0w/viewform?usp=sf_link" >Browse</a>

                                        
                                        <?php  } else {?>

                                       <a style="background-color: gray;  color: white; padding: 5px;border-radius: 12px; font-size: 15px;" href="" class="btn disabled" data-toggle="modal" data-target="#myModal1" >Scan To Pay</a>

                                         <a style="background-color:gray;border-radius: 12px;  color: white; padding: 5px; font-size: 15px;" href="" class="btn disabled" >Browse</a>
                                        
                                        <?php } ?>
                                        
                                    </tr>
                                    <?php
                                    
                                    }
                                    } else {
                                    echo "no results";
                                    }
                                    
                                    ?>
                              






                                <?php if ((mysqli_num_rows($result2)) > 0) {
                                    while($row2 = mysqli_fetch_array($result2)) {
                                    ?>
                                    <tr>
                                        
                                        <?php
                                        
                                        $status = $row2["Payment"];
                                        
                                        if($status == 'Pending') {
                                        
                                        
                                        ?>
                                        
                                        <p style="color: black; text-align: center; margin-top: 50px;font-size: 20px; font-weight: bold; "> YOUR REGISTRATION STATUS IS <k style="color: red;font-size: 35px;"><br>
                                        <a style="color: #fff; padding: 10px; background-color: red;border-radius: 10px; text-decoration: none;cursor: context-menu;">  <?php echo $row2['Payment']; ?>  </a> </k> </p>
                                        
                                        <?php  } else {?>
                                        <p style="color: black; text-align: center; margin-top: 50px;font-size: 20px; font-weight: bold; "> YOUR REGISTRATION STATUS IS<k style="color: green;font-size: 35px;"> <br>  <a style="color: #fff; padding: 10px; background-color: green; border-radius: 10px; cursor: context-menu;">  <?php echo $row2['Payment']; ?> </a> </k> </p>
                                        
                                        <?php } ?>
                                        
                                    </tr>
                                    <?php
                                    
                                    }
                                    } else {
                                    echo "no results";
                                    }
                                    
                                    ?>


                        </div> </center>
                        
                        <!-- SECOND TABLE -->
                        <div class="col-sm-12 col-md-8 col-lg-8">
                            
                            





                                
                                
                        
                            
                        </div>
                         
                    </div>
                   
                </div>




        
        <script>
            
            var table = document.getElementById("table"), sumVal = 0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[2].innerHTML);
            }
            
            document.getElementById("val").innerHTML = "Total Registration Fee is Rs: " + sumVal;
            console.log(sumVal);
            
        </script>


  <!-- Modal For Notice -->
  <div id="myModal1" class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="margin-top: 50px;">
    <div class="modal-dialog" role="document"  >
      <div class="modal-content" style="height: 500px;" >
        <div class="modal-header" >
          <p style="font-size: 20px;">Payment Section</p>
        </div>
        <div class="modal-body" style="overflow-y: scroll;">

             <p style="text-align: justify;margin-top: 10px;">Instruction:-</p>

             <p style="text-align: justify;margin-top: 10px;">While Doing The Payment Please Mention Remark As <b style="color: red; text-transform: uppercase;">"payment for Event MXPLORE"</b>After Successful payment , you  have to  click browse button and upload the screenshot or picture of transaction details. Once your registration is verified , Your registration status will be updated and you will  receive a message in your registered phone number within 24 hours.</p>

            <img src="img/pay.jpg" style="width: 100%; height: 550px;"><br><br><br>


             
      </div>
      
      </div>
    </div>
  </div>
</div>
</div>

</div>


                 
                
                <?php include "event_footer.php"; ?>