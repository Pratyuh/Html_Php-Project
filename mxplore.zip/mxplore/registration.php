
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<style type="text/css">
  body{
    background: linear-gradient(217deg, rgba(255,0,0,.8), rgba(255,0,0,0) 70.71%),
            linear-gradient(127deg, rgba(0,255,0,.8), rgba(0,255,0,0) 70.71%),
            linear-gradient(336deg, rgba(0,0,255,.8), rgba(0,0,255,0) 70.71%);
  }
</style>

</head>
<body>

</body>
</html>


<?php 
    session_start();

    include "DbConnect.php";
if(isset($_POST['submit'])){
     $registration = $_POST['registration'];
     $name = $_POST['name'];
     $email = $_POST['email'];
     $password = $_POST['password'];
     $collge_name = $_POST['college_name'];
     $branch = $_POST['branch'];
     $phone_no = $_POST['phone_no'];
      $payment = $_POST['payment'];
       $submitbtn = $_POST['submitbtn'];

    $select_query = "SELECT * FROM users WHERE email='$email'";

    $select_query_result = mysqli_query($con,$select_query);
   
    if(mysqli_num_rows($select_query_result) > 0 ){
        echo '<script language="javascript">';
        echo 'swal({
  title: "Oops! Email Already Exits",
  type: "error",
  timer: 500,
  showConfirmButton: false
}, function(){
      window.location.href = "main";
});';
        echo '</script>';

    }else{
         $query = "INSERT INTO users (name, email, password, branch, mobile_no, college_name,Payment,sucess) 
                  VALUES ('$name', '$email', '$password', '$branch', '$phone_no','$collge_name','$payment','$submitbtn')";
        $result_insert = mysqli_query($con, $query);
        $id =  mysqli_insert_id($con);
        if($result_insert){
            $_SESSION['id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['college_name'] = $collge_name;
            $_SESSION['phone_no'] = $phone_no;
            $_SESSION['branch'] = $branch;
             $_SESSION['payment'] = $payment;
              $_SESSION['submitbtn'] = $submitbtn;
              
            header('Location: event');
        }else{
            echo mysqli_connect_error($con);
        }
    }
    
}
    
?>