<?php
         $username = "root";
         $host = "localhost";
         $password = "";
         $database_name = "mxplore";
           $con =mysqli_connect($host, $username, $password, $database_name);
        


?>