
   


  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">

            <img src="img/lo.png" style="width: 300px; height: 150px;">
            

            <h2 style="color: #fff; size: 60px; font-weight: 50px;text-align: center;">mXplore Vol.1</h2>
            <p style="text-transform: uppercase;text-align: justify;">Mxplore is a Mechanical Engineering Techno Symposium Organised by Mechanical Department of GOVERNMENT COLLEGE OF ENGINEERING, KEONJHAR</p>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="main">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="event">Events</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="schedule">Schedule</a></li>
                  <li><i class="fa fa-angle-right"></i> <a href="hospitality">Hospitality</a></li>
                  <li><i class="fa fa-angle-right"></i> <a href=""data-toggle="modal" data-target="#exampleModal">Contact Us</a></li>
            </ul>
          </div>

            <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Follow Us</h4>
            

            <div class="social-links">
           <a href="https://m.facebook.com/Mxplore-106201624152956/?view_public_for=106201624152956" class="facebook"><i class="fa fa-facebook"></i></a>

              <a href="https://www.instagram.com/mxplore_v1?r=nametag"><i class="fa fa-instagram"></i></a>
             <a href="mailto:mxplore@gcekjr.ac.in" target="_top"><i class="fa fa-envelope"></i></a>
              <a href="tel:8895384889" target="_top"><i class="fa fa-phone"></i></a>
               <a href="https://youtu.be/nVtsKddpd2I"><i class="fa fa-youtube"></i></a>
            </div><br><br>
            
            
           <div class="social-links">

       <div class="mapouter"><div class="gmap_canvas"><iframe width="290" height="170" id="gmap_canvas" src="https://maps.google.com/maps?q=GOVERNMENT%20COLLEGE%20OF%20ENGINEERING%2C%20KEONJHAR&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Google Maps Generator by <a href="https://www.embedgooglemap.net">embedgooglemap.net</a></div><style>.mapouter{position:relative;text-align:right;height:170px;width:290px;margin-left: 10px;}.gmap_canvas {overflow:hidden;background:none!important;height:170px;width:300px;margin-left: 10px;}</style></div>

           
          </div>
     

          </div>


       


        
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Designed By Pratyusa and Ajit 
      </div>
      <div class="credits">
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="js/modal.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>


  <!-- Modal For Contact US -->
  <div  class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 50px;" >
      <div class="modal-content" >

         <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
        
        <div class="modal-body" >
           <section id="speakers" class="wow fadeInUp" style="background-color: #fff; padding-top: 2px">
      <div class="container" >

         <center><b> <u>Convenor</u></b><br>
            <img src="img/cov-c.png" style="width: 85px; height: 85px;"><br>
        Dr. Ramesh Chandra Mohapatra <br>
        <a href = "mailto: rameshmohapatra75@gmail.com" style="color: red;">rameshmohapatra75@gmail.com</a><br><br>
        <u><b>Co-Convenor</u></b><br>
          <img src="img/cov.png" style="width: 85px; height: 85px;"><br>
        Mr. Dayanidhi Jena <br>
    <a href = "mailto: dayanidhijena_fme@gcekjr.ac.in" style="color: red;">dayanidhijena_fme@gcekjr.ac.in</a><br><br>


        <u><b>Faculty Co-Ordinator</u></b><br>
         Mr. Suchit Kumar Gupta :
        <a href = "mailto: suchitgupta23@gmail.com" style="color: red;">suchitgupta23@gmail.com</a><br>
        Ms. Partha Sarathi Mishra:
        <a href = "mailto: mpartha09002@gmail.com" style="color: red;">mpartha09002@gmail.com</a>
         <br><br>


         <b><u>Student Co-ordinators</u></b><br>
            Chinmaychiranjeeb Nayak : <a href="tel:8895384889" style="color: red;">8895384889</a><br>
            Jyoti Prakash Pattaink : <a href="tel:8249115158" style="color: red;">8249115158</a><br>
            Vishal Jaiswal : <a href="tel:6370509764" style="color: red;">6370509764</a><br>
            K Raghuram Naidu : <a href="tel:7978523335" style="color: red;">7978523335</a><br>
   
      Mail Us:
      <a href = "mailto: mxplore@gcekjr.ac.in" style="color: red;">mxplore@gcekjr.ac.in</a>
       </center> 
       
         </div>

    </section>
        </div>

      
      </div>
    </div>
  </div>
</div>
</div>

</div>

  
 
</body>

</html>



