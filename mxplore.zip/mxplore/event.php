
<?php
include "DbConnect.php";
session_start();



$u_id = $_SESSION['id'];

$s_sql1 = "SELECT * FROM registered_events WHERE user_id = '$u_id'";
$result1 = mysqli_query($con, $s_sql1);






$s_sql = "SELECT * FROM events";
$result = mysqli_query($con, $s_sql);



                                           



?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>EVENTS</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta name="keywords" content="mxplore events,mxplore event page, mxplore mechanical engineering, mechanical gce kjr,mechanical brnch,mechanical branch gce kjr,mechanical gce,mxplore vol.1 ">
        <meta name="description" content="In Mxplore Vol.1 various events are oraganised at GCE,kjr so participated">
        <!-- Favicons -->
           <!-- Favicons -->
  <link href="img/favicon.ico" rel="icon">
  <link href="img/favicon.jpg" rel="favicon">

        
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">
        <!-- Bootstrap CSS File -->
        <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Libraries CSS Files -->
        <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/venobox/venobox.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
        <!-- Main Stylesheet File -->
        <link href="css/style.css" rel="stylesheet">
        <link rel="stylesheet" href="css/event.css">
        <link rel="stylesheet" href="css/style2.css">
        <style>
        
        .btn-info {
        width: 200px;
        height: 40px;
        }
        .participated-btn{
        width: 200px;
        height: 40px;
        }
        .regi-btn{
        background-color: #808080;
        border: none;
        color: white;
        padding: 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        border-radius: 8px;
        }
        @media only screen and (max-width: 600px) {
        .btn-info {
        width: 200px;
        height: 40px;
        }
        .participated-btn{
        width: 200px;
        height: 40px;
        }
        .modal {
        margin-top: 10px;
        }
        #modalLRForm{
        margin: 50px;
        }
        }
        
        .panel {
        border-radius: 4px;
        padding: 1rem;
        margin-top: 0.2rem;
        background-color: #F5F5F5;
        color: #323B40;
        }
        input[type="text"]
        {
        font-size:15px;
        border-radius: 10px;
        }
        input[type="email"]
        {
        font-size:15px;
        border-radius: 10px;
        }
        input[type="password"]
        {
        font-size:15px;
        border-radius: 10px;
        }
        </style>
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-149346447-2"></script>
        <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-149346447-2');
        </script>
        
        <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-152055986-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152055986-1');
</script>



    </head>
    <body>
        <!--==========================
        Header
        ============================-->
        <header id="header" style="background: rgba(0,0,0,0.6);">
            <div class="container" >
                <div id="logo" class="pull-left">
                    <!-- Uncomment below if you prefer to use a text logo -->
                    <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                    <a href="main"><img src="img/kk.png" alt="" title="" style="width: 200px; height: 40px;"></a>
                </div>
                <nav id="nav-menu-container">
                    <ul class="nav-menu">
                        <?php if(isset($_SESSION['id'])){
                        
                        ?>
                        <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                        <li><a href="main">Home</a></li>
                        <li class="menu-active"><a href="event">Events</a></li>
                      
                        <li><a href="registered_event">My Registered Events</a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out"> </i> Logout </a></li>
                        <?php }else{ ?>
                        <li><a href="main">Home</a></li>
                        <li class="menu-active"><a href="event">Events</a></li>
                        <li><a href="schedule">Schedule</a></li>
                       
                           
                     
                        <li><a href='' data-toggle="modal" data-target="#modalLRForm">Create a account</a></li>
                        
                        <?php } ?>
                    </ul>
                    </nav><!-- #nav-menu-container -->
                </div>
                </header><!-- #header -->
                <section id="events" class="wow fadeInUp" >
                    <section class="wrapper">
                        <div class="container">
                            <div class="row">
                                <div class="container">


                                    <h2 class="text-center" style="color: #112363;font-size: 28px; font-weight: 700; ">EVENTS</h2>

                                     <p style="color: white; text-align: center; padding: 10px;"> <a href="pdf/EVENT LIST.pdf" download style="background-color: green; padding: 10px; border-radius: 12px; text-decoration: none; color: white"> EVENTS AT A GLANCE </a>  </p>
                                     <p class="text-center text-black">For Event Schedule Click <a href="schedule" style="color: red;"><u>Here</u></a></p>

                                     <p style="text-align: center;color: red;">After participating in any event if you want to unparticipate, then just click on <b>"UNPARTICIPATE"</b> button.</p>
                                     
                                       <p style="text-align: center;color: red;">For Group Event Only One Participant Should Register On Behalf Of The Group.</p>
                                       
                                     <p>
                                     
                                     </p>
                                </div>
                            </div>
                            <div class="row">
                                <?php
                                if ((mysqli_num_rows($result)) > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <div class="col-sm-12 col-md-6 col-lg-3">
                                    <div class="card" >
                                        <div class="embed-responsive embed-responsive-16by9">
                                            <a ><img alt="Card image cap" class="card-img-top embed-responsive-item" src="admin/upload/<?php echo $row['event_image']; ?>" /></a>
                                        </div>
                                        <div class="card-content card-block">
                                            <h2 style="font-weight: bold;"><a href="#" style="color:#000000; cursor: default; "><?php echo $row['event_name']; ?></a></h2>
                                            <input type="hidden" value="<?php echo $row['id']; ?>" id="hidden_data">
                                            <p class="card-text text event_id_for_data "
                                                style=" overflow: hidden;
                                                height: 60px;
                                                display: -webkit-box;
                                                color: black;
                                                -webkit-line-clamp: 3;
                                                -webkit-box-orient: vertical;"><?php
                                            echo $row['event_desc']; ?></p>



                                                
                                  
                                
                                        
                                     
                                   
                                        
                                       
                                
                                  
                              
                                
                                            
                                            <center>    <p><button style="width: 200px; height: 40px;" type="button" class="button btn btn-secondary btn-lg" data-toggle="modal" data-target="#myModal" val="<?php echo $row['id']; ?>">Read More</button></p></center>
                                            <?php if(isset($_SESSION['id'])){
                                            
                                            ?>
                                            
                                            
                                            <?php
                                            
                                            $user_id = $_SESSION['id'];
                                            $event_id = $row['id'];
                                            $select_query = "SELECT * FROM registered_events WHERE user_id='$user_id' AND event_id = '$event_id'";
                                            $select_query_result = mysqli_query($con,$select_query);



                                          $user_id = $_SESSION['id'];

                                          $event_id = $row['id'];

                                          $s_sql1 = "SELECT * FROM users WHERE id = '$user_id'";
                                           $result1 = mysqli_query($con, $s_sql1);

                                        
                                            $row1 = mysqli_fetch_assoc($result1);
                                                


                                        
                                         if($row1['sucess'] == 'SUBMITTED') {
                                        
                                        
                                        ?>


                                 <?php
                                        if(mysqli_num_rows($select_query_result ) == 1) {
                                            ?>


                                            <center> <button style="border-radius: 12px;" class="btn participated-btn btn-success btn-lg disabled">
                                            Participated
                                            </button></center>
                                            
                                            <?php
                                            }else {

                                            
                                            
                                            
                                            
                                            ?>

                                         
                                            <center><p><button style="width: 200px; height: 40px;" type="button" class="button btn btn-secondary btn-lg disabled">Participate</button></p></center>
                                            
                                            <?php
                                            }?>




                                        
                                        <?php  } 


                                          elseif(mysqli_num_rows($select_query_result ) == 1) {
                                            ?>

                                           

                                       <center>      <a  class="btn-reg-original btn btn-info btn-lg " style="background-color: red;  color: white; padding: 8px; font-size: 15px;" href="delete_register_event.php?event_id=<?php echo $row['id']; ?>">Unparticipate</a>
                                            </center>  

                                             
                                            <?php
                                            }else {

                                            
                                            
                                            
                                            
                                            ?>
                                            <center>   <p><button class="btn-reg-original btn btn-info btn-lg  js-signin-modal-trigger" href="" data-toggle="modal" data-target="#registerEvent" reg="<?php echo $row['id']; ?>">Participate</button></p></center>
                                            
                                            <?php
                                            }

                                            ?>
                                            
                                            
                                            
                                            <?php }else{ ?>
                                            
                                            <center><p><button style="width: 200px; height: 40px;" type="button" class="button btn btn-danger btn-lg" data-toggle="modal" data-target="#modalLRForm">Register this   event</button></p></center>
                                            
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                }
                                } else {
                          echo '<span style="color:red; font-size:30px;">Events Are Added Soon</span>';
                                }
                                ?>
                            </div>
                        </div>
                    </section>
                    </section>
                
                <div class="modal fade" id="modalEventForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header text-center bg-secondary">
                                <h4 class="modal-title w-100 font-weight-bold  text-white">Register On Event</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body mx-5">
                                <div class="md-form mb-5 form-group">
                                    <input type="text" id="defaultForm-email" class="form-control p-3 validate" value="<?php echo $_SESSION['name']; ?>">
                                    <label data-error="wrong" data-success="right" for="defaultForm-email">Name</label>
                                </div>
                                <div class="md-form mb-4 form-group">
                                    <input type="text" id="branch" class="form-control p-3 ">
                                    <label data-error="wrong" data-success="right" for="defaultForm-pass">Branch</label>
                                </div>
                                <div class="md-form mb-4 form-group">
                                    <input type="text" id="clg-name" class="form-control validate p-3 ">
                                    <label data-error="wrong" data-success="right" for="defaultForm-pass">College Name</label>
                                </div>
                                <input type="hidden" value="<?php echo $_SESSION['name']; ?>" id="u_name">
                                <input type="hidden" value="<?php echo $_SESSION['id']; ?>" id="u_id">
                            </div>
                            <div class="modal-footer d-flex justify-content-center">
                                <button class="btn-event-register btn btn-success btn-block p-3" id="register-btn">Register Event</button>
                            </div>
                        </div>
                    </div>
                </div>
            </body>
            
            
            <!-- Modal For ReadMore -->
            <div class="modal fade" id="myModal" role="dialog">
                <div class="modal-dialog" style="max-width:800px !important; margin-top:65px;
                    max-height: 400px !important;">
                    
                    <!-- Modal content-->
                    <div class="modal-content " style="background-color: #000; border: 25px solid #F16026;  height: 500px;" >
                       
                        <div class="modal-body" style="overflow-y: scroll;">
                            <div id="login_for_review">
                                <div>
                                    
                                    <u> <p class="lead price" style="color: #fff; text-align: center; font-size: 14px;font-weight: bold;"></p></u>

                                    <h1 class="" style="background-color: #F12626; color: #fff;text-align: center;">
                                    Description
                                    </h1>
                                    <p class="lead" style="font-size: 17px; text-align: justify;color: #fff"></p>
                                </div>
                                <div>
                                    <h1 class=""  style="background-color: #F12626; color: #fff; text-align: center;">
                                    Rules
                                    </h1>
                                    <p class="lead rules" style="font-size: 17px; text-align: justify;color: #fff"></p>
                                </div>

                                 <div>
                                    <h1 class=""  style="background-color: #F12626; color: #fff; text-align: center;">
                                    Problem And Settelment
                                    </h1>
                                    <p style="font-size: 17px; text-align: justify;color: #fff"><a href="/pdf/SCHEDULE.pdf" download>Clickhere</a></p>
                                </div>

                                

                                <div>
                                    <h1 class=""  style="background-color: #F12626;color: #fff;text-align: center;">
                                    Prize Money
                                    </h1>
                                    <p class="lead prize" style="font-size: 16px; color: #fff"></p>
                                </div>
                            </div>
                        </div>

                      
                   <center>   <button type="button" class="btn btn-danger" data-dismiss="modal" style="font-size: 20px;margin-top: 10px;margin-bottom: 10px;  ">Close!!</button></center> 
                      

                    </div> 
                </div>
            </div> 
            
            <!-- Modal Submit user info -->
            <div class="modal fade" id="registerEvent" role="dialog">
                <div class="modal-dialog" style="padding:0px;margin-top:px;65">
                    <!-- Modal content-->
                    <div class="modal-content"  style="background-color: #FAFAF9; border: 15px solid #FF0624; ">
                        <button type="button" class="close" data-dismiss="modal" style="font-size: 50px;">&times;</button>
                        <div class="modal-body ">
                            <div class="form-group">
                                <input type="hidden" id="event_id_reg">
                                <input type="hidden" id="user_id_reg">
                                <label for="email1">Event name</label>
                                <input type="text" class="form-control p-3 " id="event_name_reg" disabled>
                                <!--            <small id="emailHelp" class="form-text text-muted">Your information is safe with us.</small>-->
                            </div>
                            <div class="form-group">
                                <!--  <label for="email1">Event Price</label> -->
                                <input type="hidden" class="form-control p-3" id="event_price_reg" disabled>
                            </div>
                            <div class="form-group">
                                <label for="email1">User name</label>
                                <input type="text" class="form-control p-3" id="user_name_reg" disabled>
                            </div>
                            <div class="form-group">
                                <label for="email1">Phone no</label>
                                <input type="text" class="form-control p-3" id="phone_no_reg" disabled>
                            </div>
                            
                            <div class="form-group">
                                <label for="email1">College name</label>
                                <input type="text" class="form-control p-3" id="college_name_reg" disabled>
                            </div>
                        </div>
                        <div class="modal-footer border-top-0 d-flex justify-content-center">
                            <button type="submit" class="btn-register-event btn btn-primary
                            btn-lg p-3 btn-block
                            ">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- MODAL SIGNIN SIGNUP FORM -->
            <!-- MODAL SIGNIN SIGNUP FORM -->
            
            <!--Modal: Login / Register Form-->
            <div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="height: 550px;padding: 0px; margin: 0px; margin-top: 65px; ">
                
                <div class="modal-dialog cascading-modal" role="document" style="padding:0px;" >
                    <!--Content-->
                    <div class="modal-content" style="background-color: #FAFAF9; border: 30px solid #E1DDD3; ">
                        
                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="font-size: 50px;">&times;</span>
        </button>
        
        
                        <!--Modal cascading tabs-- Bootstrapmdb>
                        <div class="modal-c-tabs"-->
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
                                <li class="nav-item">
                                     <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab" style="font-size:20px; font-weight: bold;width: 120px;">Log in</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" data-toggle="tab" href="#panel8" role="tab" style="font-size: 20px; font-weight: bold;width: 120px;"> Register</a>
                                </li>
                            </ul>
                            <!-- Tab panels -->
                            <div class="tab-content p-3">
                                <!--Panel 7-->
                                <div class="tab-pane fade in show active" id="panel7" role="tabpanel">
                                    <!--Body-->
                                    <div class="modal-body mb-1">
                                        <form method="post" action="login">
                                            <div class="md-form form-sm mb-5">
                                                  <label data-error="wrong" data-success="right" for="modalLRInput10">Your email :</label>
                                                <input type="email" id="login-email" class="form-control form-control-sm validate p-3" name="email">
                                              
                                            </div>
                                            <div class="md-form form-sm mb-4">
                                                 <label data-error="wrong" data-success="right" for="modalLRInput11">Your password :</label>
                                                <input type="password" id="login-password" class="form-control form-control-sm validate p-3" name="password" minlength="6">
                                               
                                            </div>
                                            <a href="forgetpass" style="float: right; color: red; margin-bottom: 10px;">Forget Password</a>
                                            <div class="text-center mt-2">
                                                <input style="font-size: 20px; font-weight: bold; background-color:#1FA80C;color: white;" type="submit" class="btn btn-success btn-block p-2" id="user_login-btn" value="Log in">
                                            </div>
                                            
                                        </form>
                                    </div>
                                </div>
                                <!--/.Panel 7-->
                                <!--Panel 8-->
                                <div class="tab-pane fade" id="panel8" role="tabpanel">
                                    <!--Body-->
                                    <div class="modal-body">
                                        <form method="post" action="registration">
                                            <div class="md-form form-sm mb-5">
                                               
                                                <label data-error="wrong" data-success="right" for="modalLRInput12" >Name:</label>
                                                 <input type="text" id="name" class="form-control form-control-sm validate p-3" required name="name">
                                            </div>
                                            <div class="md-form form-sm mb-5">
                                               
                                                <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail:</label>
                                                 <input type="email" id="email" class="form-control form-control-sm validate p-3" required name="email">
                                            </div>
                                            <div class="md-form form-sm mb-5">
                                               
                                                <label data-error="wrong" data-success="right" for="modalLRInput12">School/College Name:</label>
                                                 <input type="text" id="college_name" class="form-control form-control-sm validate p-3" name="college_name" required name="college_name" >
                                            </div>
                                            <div class="md-form form-sm mb-5">
                                              
                                                <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no:</label>
                                                  <input type="text" id="phone_no" class="form-control form-control-sm validate p-3" name="phone_no" required name="phone_no">
                                            </div>

                                              <div class="md-form form-sm mb-5">
                                                <input id="phone_no" class="form-control form-control-sm validate p-3" name="payment"  value="Pending" type="hidden">
                                               
                                            </div>

                                             <div class="md-form form-sm mb-5">
                                                <input id="phone_no" class="form-control form-control-sm validate p-3" name="submitbtn"  value="SUBMIT" type="hidden">
                                               
                                            </div>


                                            
                                            <div class="md-form form-sm mb-4">
                                               
                                                <label data-error="wrong" data-success="right" for="modalLRInput14" required>Password (6 characters minimum):</label>
                                                 <input type="password" id="password" class="form-control form-control-sm validate p-3" name="password" minlength="6">
                                            </div>
                                            <div class="text-center form-sm mt-2">
                                                <input style="font-size: 20px; font-weight: bold; background-color:#1FA80C;color: white;"  type="submit" name="submit" class="btn btn-info btn-block  p-2" id="signup" value="Sign up">
                                            </div>
                                        </form>
                                    </div>
                                   
                                </div>
                                <!--/.Panel 8-->
                            </div>
                        </div>
                    </div>
                    <!--/.Content-->
                </div>
            </div>
            <!--Modal: Login / Register Form-->
            <script src="js/placeholders.min.js"></script>
            <script src="js/jquery-3.4.1.min.js"></script>
            <!-- polyfill for the HTML5 placeholder attribute -->
            <script>
            $(".btn-register-event").on('click',function() {
            var event_name = $("#event_name_reg").val();
            var event_price = $("#event_price_reg").val();
            var event_id = $("#event_id_reg").val();
            //alert(event_id);
            var user_name = $("#user_name_reg").val();
            var user_mobile = $("#phone_no_reg").val();
            var college_name = $("#college_name_reg").val();
            var branch_name = $("#user_branch_reg").val();
            var user_id = $("#user_id_reg").val();
            
            $.ajax({
            url: "add_register_event.php",
            type: "post",
            data: {
            event_name: event_name,
            event_price: event_price,
            event_id: event_id,
            user_name: user_name,
            user_id: user_id,
            user_mobile: user_mobile,
            branch_name: branch_name,
            college_name: college_name
            },
            success: function(result) {
            if (result == "success") {
            
            alert("Successfully Registered");
            window.location.href = "event.php";
            
            } else {
            alert(result);
            }
            },
            error: function(error) {
            alert(error);
            }
            });
            });
            $(".btn-reg-original").click(function() {
            var id = $(this).attr('reg');
            $.ajax({
            url: "seteventDetails.php",
            type: "post",
            data: {
            id: id
            },
            success: function(response) {
            var jsonData = JSON.parse(response);
            for (var i = 0; i < jsonData.length; i++) {
            var counter = jsonData[i];
            var event_name = counter.event_name;
            var event_price = counter.event_price;
            var event_image = counter.event_image;
            var event_id = counter.event_id;
            var user_name = counter.user_name;
            var user_id = counter.user_id;
            var user_mobile = counter.user_phone;
            var user_branch = counter.user_branch;
            var user_college = counter.user_college;
            $("#event_name_reg").attr("value",event_name);
            $("#event_id_reg").attr("value", event_id);
            $("#event_price_reg").attr("value", event_price);
            $("#user_name_reg").attr("value", user_name);
            $("#user_id_reg").attr("value", user_id);
            $("#phone_no_reg").attr("value", user_mobile);
            $("#college_name_reg").attr("value", user_college);
            $("#user_branch_reg").attr("value", user_branch);
            }
            }
            });
            });
            $(".button").on('click', function() {
            var id = $(this).attr("val");
            $.ajax({
            url: "get_event_details.php",
            type: "post",
            data: {
            id: id
            },
            success: function(response) {
            var jsonData = JSON.parse(response);
            for (var i = 0; i < jsonData.length; i++) {
            var counter = jsonData[i];
            var event_name = counter.event_name;
            var event_desc = counter.event_desc;
            var event_rules = counter.event_rules;
            var event_price = counter.event_price;
            var prize_money = counter.prize_money;
            var event_image = counter.event_image;
            var event_pdf = counter.event_pdf;
            $(".event_name").html(event_name);
            $(".lead").html(event_desc);
            $(".price").html("This Event Registration Fee is Rs: " + event_price);
            $(".prize").html("" + prize_money);
            $(".rules").html(event_rules);
            $(".event_image").attr("src", "admin/upload/" + event_image);
            $(".event_doc").attr("href", "/admin/upload/pdf/"+event_pdf);
            }
            }
            });
            });
            
              </script>
            <!-- Modal For Group Event --> 

            <div class="modal fade" id="Gmodal1" role="dialog">
                <div class="modal-dialog" style="max-width:800px !important; margin-top:40px;
                    max-height: 500px !important;">
                    <!-- Modal content-->
                    <div class="modal-content" style="height: 450px;">
                        <div class="modal-header" >
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body" style="overflow-y: scroll;">
                            <div id="login_for_review">
                                <div>
                                    
                                    <u> <p  style="color: red; text-align: center; font-size: 25px;font-weight: bold;">This Event Price is 50</p></u>
                                    <h1 class="">
                                    Description
                                    </h1>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
                                    
                                </div>
                                <div>
                                    <h1 class="">
                                    Rules
                                    </h1>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, </p>
                                    
                                </div>
                                <div>
                                    <h1 class="">
                                    Prize Money
                                    </h1>
                                    <p>Rs: 1000</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

        


            <?php include "event_footer.php"; ?>