<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Schedule</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="keywords" content="mxplore events,mxplore event page, mxplore mechanical engineering, mechanical gce kjr,mechanical brnch,mechanical branch gce kjr,mechanical gce,mxplore vol.1,mxplore schedule page,schedule organised in 2 days,">
        <meta name="description" content="Here is Mxplore Vol.1 Schedule which contain various event">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: TheEvent
    Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6);" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="main.php"><img src="img/kk.png" alt="" title="" style="width: 200px; height: 40px;"></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="main">Home</a></li>
                       <li class="menu-active"><a href="schedule">Schedule</a></li>
                    <li ><a href="event" >Events</a></li>
                     <li ><a href="hospitality" >Hospitality</a></li>
                      <li><a href=""  data-toggle="modal" data-target="#exampleModal" >Contact Us</a></li>
                    <li><a href="registered_event" >My Registered Events</a></li>

                    
                    <li><a href="logout.php" ><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }else{ ?>
                    <li><a href="main" >Home</a></li>
                     <li ><a href="event" >Events</a></li>
                     <li class="menu-active"><a href="schedule">Schedule</a></li>
                     <li ><a href="hospitality" >Hospitality</a></li>
                    
                      <li><a href=""  data-toggle="modal" data-target="#exampleModal" >Contact Us</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                  
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">

   
   

    <!--==========================
      Schedule Section
    ============================-->
     <section id="schedule" class="section-with-bg" style="background-color: #E9EBB3;">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2 >Event Schedule</h2>
         <p>Here is our event Schedule</p>
        </div>

       

   <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3</a>
          </li>
        </ul>

        <p class="sub-heading" style="color: black; font-weight: bold; font-size: 25px;">LUNCH BREAK <br> <time>01.00 PM - 02.00 PM</time> </p>

        <div class="tab-content row justify-content-center">
        <!-- Schdule Day 1 --> 
         <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

            <img src="img/0001.jpg" class="img-rounded img-responsive " alt="day 1" width="100%" > 
           

          </div>
          <!-- End Schdule Day 1 -->

          <!-- Schdule Day 2 -->
          <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">


         <img src="img/0002.jpg" class="img-rounded img-responsive " alt="day 2" width="100%" > 
            

          </div>
          <!-- End Schdule Day 2 -->

          <!-- Schdule Day 3 -->
         <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-3">

           
  <img src="img/0003.jpg" class="img-rounded img-responsive " alt="day 3" width="100%" > 
            

          </div>
          <!-- End Schdule Day 3 -->  

  </div>

 


      </div>
       <center><a href="pdf/SCHEDULE.pdf" download>  <button type="button" class="btn  btn-lg" style="margin-top: 20px; background: #451414; color: white;">Download Event Schedule</button></a> </center> 

    </section>

    
   <!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:70px;">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-- Bootstrapmdb>
      <div class="modal-c-tabs"-->

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel8" role="tab">
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content p-3">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
              <div class="md-form form-sm mb-5">
                <input type="email" id="login-email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput10">Your email</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="login-password" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label>
              </div>
              <div class="text-center mt-2">
                <button class="btn btn-success btn-block p-3" id="user_login-btn">Log in </button>
              </div>
            </div>

          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">

            <!--Body-->
            <div class="modal-body">
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Name</label>
              </div>

              <div class="md-form form-sm mb-5">
                <input type="email" id="signup_email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_college_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">College Name</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_phone_no" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_user_branch" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput12">Branch</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="signup_password" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput14">Password</label>
              </div>


              <div class="text-center form-sm mt-2">
                <button class="btn btn-success btn-block  p-3" id="signup-btn">Sign up </button>
              </div>

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->

<script>

    $(document).ready(function() {

         $("#user_login-btn").on("click", function() {

            var login_email = $("#login-email").val();
            var login_password = $("#login-password").val();
            if(login_email.length == 0 && login_password.length == 0){
              alert("Please enter all the field");
        }else{
            $.ajax({
                url: "login.php",
                type: "post",
                data: {
                    email: login_email,
                    password: login_password
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
          
          
          
          
            $("#signup-btn").on("click", function() {
            var name = $("#signup_name").val();
            var email = $("#signup_email").val();
            var college_name = $("#signup_college_name").val();
            var branch = $("#signup_user_branch").val();
            var password = $("#signup_password").val();
            var phone_no = $("#signup_phone_no").val();

            if(name.length == 0 && college_name.length == 0){
                alert("Please enter all fields");
            } else {
            $.ajax({
                url: "registration.php",
                type: "post",
                data: {
                    registration: "success",
                    name: name,
                    email: email,
                    password: password,
                    college_name: college_name,
                    branch: branch,
                    phone_no: phone_no
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
        });
            
</script>

  

  
<?php include "footer.php"; ?>


    <!-- Modal For Contact US -->
  <div  class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 50px;" >
      <div class="modal-content" >

         <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
        
        <div class="modal-body" >
           <section id="speakers" class="wow fadeInUp" style="background-color: #fff; padding-top: 2px">
      <div class="container" >

         <center><b> <u>Convenor</u></b><br>
            <img src="img/cov-c.png" style="width: 85px; height: 85px;"><br>
        Dr. Ramesh Chandra Mohapatra <br>
        <a href = "mailto: rameshmohapatra75@gmail.com">rameshmohapatra75@gmail.com</a><br><br>
        <u><b>Co-Convenor</u></b><br>
          <img src="img/cov.png" style="width: 85px; height: 85px;"><br>
        Mr. Dayanidhi Jena <br>
    <a href = "mailto: dayanidhijena_fme@gcekjr.ac.in">dayanidhijena_fme@gcekjr.ac.in</a><br><br>


        <u><b>Faculty Co-Ordinator</u></b><br>
         Mr. Suchit Kumar Gupta :
        <a href = "mailto: suchitgupta23@gmail.com">suchitgupta23@gmail.com</a><br>
        Ms. Partha Sarathi Mishra:
        <a href = "mailto: mpartha09002@gmail.com">mpartha09002@gmail.com</a>
         <br><br>


         <b><u>Student Co-ordinators</u></b><br>
            Chinmaychiranjeeb Nayak : <a href="tel:8895384889">8895384889</a><br>
            Jyoti Prakash Pattaink : <a href="tel:8249115158">8249115158</a><br>
            Vishal Jaiswal : <a href="tel:6370509764">6370509764</a><br>
            K Raghuram Naidu : <a href="tel:7978523335">7978523335</a><br>
   
      Mail Us:
      <a href = "mailto: mxplore@gcekjr.ac.in">mxplore@gcekjr.ac.in</a>
       </center> 
       
         </div>
    

