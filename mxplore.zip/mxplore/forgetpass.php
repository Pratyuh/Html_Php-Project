<?php
    session_start();
    include "DbConnect.php";
    $s_sql = "SELECT * FROM users";
     $result = mysqli_query($con, $s_sql);


?>



<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Reset Password | mxplore</title>
<link href="css/style-forget.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Reset Password Form Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

 <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

<!--google fonts-->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>
</head>
<body>
<!--element start here-->
<div class="elelment">
	
	<div class="element-main" style="margin-top: 100px;">
		<h1 style="margin-bottom: 10px;">Forgot Password</h1>

		<form name="form1" action="" method="post">

			<input type="text" name="t1" value="Your Register e-mail address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Register e-mail address';}">

			<input type="text" name="t2" minlength="6" value="New Password  (6 Char. Min)" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter New Password (6 Char)';}">

			<input type="submit" name="submit2" value="Reset Password">
			<a href="main" style="float: right; margin-top: 10px; text-decoration: none; color: red;">Back To Main Page</a>
		</form>

		<?php

if(isset($_POST["submit2"]))
{
	$update_Query= "UPDATE `users` SET password ='$_POST[t2]' where email ='$_POST[t1]' ";

	try{
        $update_Result = mysqli_query($con, $update_Query);
        
        if($update_Result)
        {
            if(mysqli_affected_rows($con) > 0)
            {
                  echo '<script language="javascript">';
        echo 'swal({
  title: "Password SuccessFully Reset!! Go And Login Again",
  type: "success",
  showConfirmButton: true
}, function(){
      window.location.href = "forgetpass";
});';
        echo '</script>';
            }else{
                echo 'Email Id Not Registered';
            }
        }
    } catch (Exception $ex) {
        echo 'Error Update '.$ex->getMessage();
    }

}



?>


	</div>
</div>


<!--element end here-->
</body>
</html>