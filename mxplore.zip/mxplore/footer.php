
   


  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">

            <img src="img/lo.png" style="width: 300px; height: 150px;">
            

            <h2 style="color: #fff; size: 60px; font-weight: 50px;text-align: center;">mXplore Vol.1</h2>
            <p style="text-transform: uppercase;text-align: justify;">Mxplore is a Mechanical Engineering Techno Symposium Organised by Mechanical Department of GOVERNMENT COLLEGE OF ENGINEERING, KEONJHAR</p>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="main">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="event">Events</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="schedule">Schedule</a></li>
                  <li><i class="fa fa-angle-right"></i> <a href="hospitality">Hospitality</a></li>
                  <li><i class="fa fa-angle-right"></i> <a href=""data-toggle="modal" data-target="#exampleModal">Contact Us</a></li>
            </ul>
          </div>

            <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Follow Us</h4>
            

            <div class="social-links">
           <a href="https://m.facebook.com/Mxplore-106201624152956/?view_public_for=106201624152956" class="facebook"><i class="fa fa-facebook"></i></a>

              <a href="https://www.instagram.com/mxplore_v1?r=nametag"><i class="fa fa-instagram"></i></a>
             <a href="mailto:mxplore@gcekjr.ac.in" target="_top"><i class="fa fa-envelope"></i></a>
              <a href="tel:8895384889" target="_top"><i class="fa fa-phone"></i></a>
               <a href="https://youtu.be/nVtsKddpd2I"><i class="fa fa-youtube"></i></a>
            </div><br><br>
            
            
           <div class="social-links">

       <div class="mapouter"><div class="gmap_canvas"><iframe width="290" height="170" id="gmap_canvas" src="https://maps.google.com/maps?q=GOVERNMENT%20COLLEGE%20OF%20ENGINEERING%2C%20KEONJHAR&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Google Maps Generator by <a href="https://www.embedgooglemap.net">embedgooglemap.net</a></div><style>.mapouter{position:relative;text-align:right;height:170px;width:290px;margin-left: 10px;}.gmap_canvas {overflow:hidden;background:none!important;height:170px;width:300px;margin-left: 10px;}</style></div>

           
          </div>
     

          </div>


       


        
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Designed By Pratyusa and Ajit 
      </div>
      <div class="credits">
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="js/modal.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>

  
 
</body>

</html>

