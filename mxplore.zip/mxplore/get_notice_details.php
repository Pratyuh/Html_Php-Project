<?php
    session_start();
    include "DbConnect.php";

     $id = $_POST['id'];
     $s_sql = "SELECT * FROM notice WHERE id = '$id'";
     $result = mysqli_query($con, $s_sql);
    if($result){
        
    }else{
        echo mysqli_error($con);
    }
        while($row = mysqli_fetch_array($result)){;
        
        
            $event_desc = $row['event_desc'];
          

    $return_arr[] = array(
                  
                    "event_desc" => $event_desc
                 
                );

                                                 }
// Encoding array in JSON format
echo json_encode($return_arr);
        
?>