<?php include "includes/header.php";
       include "connection.php";
?>

<?php
if($_SESSION['is_login']){
      $uname = $_SESSION['uname'];
}else{
    header("Location: index.php");
}
?>

<style>
    .card {
        margin: 10px;
    }

    #main-container {
        margin-left:10% ;
       
    }
    .modal {
        overflow-y: auto;
        height: 100% !important;
         padding-bottom: 20px;
         padding-top: 0;
         margin-top: -30px;
       
    }
    .modal-content {
         margin-bottom: 80px !important;
    }

    @media only screen and (max-width: 600px) {
        .card {
            margin: 30px;
            margin-left: 30px;
            margin-left: 30px;
        }

        #main-container {
            margin-left: 0%;
            padding: 20px;
        }
    }
</style>

<section id="other_admin_section" style="margin-top:10%;">
   
    <div  id="main-container">
        <div class="row center">
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">DEATH RACE</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=DEATH RACE" class="btn text-white">Click</a>
                </div>
            </div>

              <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">SENSOBOTICS</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SENSOBOTICS" class="btn text-white">Click</a>
                </div>
            </div>
          
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">SPACEX</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SPACEX" class="btn text-white">Click</a>
                </div>
            </div>
            
              <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">MEMORONICS</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=MEMORONICS" class="btn text-white">Click</a>
                </div>
            </div>
            
              <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">MXFX</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=MXFX" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">ROUND TABLE</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=ROUND TABLE" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">L ARENA</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=LEGENDS ARENA" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">TALENT HUNT</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=TALENT HUNT" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">HORIZON</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=HORIZON" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">ABCD</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=ABCD" class="btn text-white">Click</a>
                </div>
            </div>
            
                   <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">SARGAM</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SARGAM" class="btn text-white">Click</a>
                </div>
            </div>
            
                   <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">C.P.DANCE</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=CHANCE PE DANCE" class="btn text-white">Click</a>
                </div>
            </div>
            
                   <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">S.HUNTER</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SQUAD HUNTER" class="btn text-white">Click</a>
                </div>
            </div>
            
                   <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">LONESURVIVER</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=LONESURVIVER" class="btn text-white">Click</a>
                </div>
            </div>
            
                   <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">P.PRESENTATION</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=PAPER PRESENTATION" class="btn text-white">Click</a>
                </div>
            </div>
            
               <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">QURIOUS</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=QURIOUS" class="btn text-white">Click</a>
                </div>
            </div>
            
               <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">KHOJ</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=KHOJ" class="btn text-white">Click</a>
                </div>
            </div>
            
               <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">LIFT UP</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=LIFT UP" class="btn text-white">Click</a>
                </div>
            </div>
            
               <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">S.STRUCTURE</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SUPER STRUCTURE" class="btn text-white">Click</a>
                </div>
            </div>
            
               <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">A.K.BAATEN</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=AAN KAHI BAATEN" class="btn text-white">Click</a>
                </div>
            </div>
          
              <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">SNAP IT</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=SNAP IT" class="btn text-white">Click</a>
                </div>
            </div>
            
                <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">ART MELA</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=ART MELA" class="btn text-white">Click</a>
                </div>
            </div>
            
        </div>
    </div>
</section>
<!-- Footer -->
<footer class="section blue darken-2 white-text center" style="margin-top: 20%;">
    <p>Mxplore Vol.1 Admin Panel &copy; 2020</p>
</footer>

<!-- Fixed Action Button -->
<div class="fixed-action-btn">
    <a href="#add-event-modal" class="modal-trigger btn-floating btn-large red">
        <i class="material-icons">add</i>
    </a>
</div>




<div id="add-event-modal" class="modal" >
    <div class="modal-content">
        <h4>Add New Event</h4>
        <form action="event_add.php" method="post" enctype="multipart/form-data">
            <label>Select an image of event</label>
            <div class="file-field input-field">
                <div class="btn">
                    <span>Browse</span>
                    <input type="file" multiple name="event_image" />
                </div>

                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload multiple files" />
                </div>
            </div>
            <div class="input-field">
                <input type="text" id="title" name="event_name">
                <label for="title">Event Name</label>
            </div>
            <div class="input-field">
                <textarea name="event_desc" id="body" class="" rows="30"></textarea>
                <label for="body">Event Description</label>
            </div>

         


            <div class="input-field">
                <textarea name="event_rule" class="" rows="30"></textarea>
                <label for="body">Event Rules</label>
            </div>
            <div class="input-field">

                <input type="text" id="title" name="Registration Fee">
                <label for="title">Event Price</label>
            </div>

                <div class="input-field">

                <input type="text" id="title" name="prize_money">
                <label for="title">Prize Money</label>
            </div>

          
            <div class="modal-footer">
                <input type="submit" class=" btn blue white-text" value="Add Event" name="submit">
            </div>
        </form>
    </div>
</div>
<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>
<script src="js/chart.js"></script>

<script>
    // Hide Sections
    $('.section').hide();
    $(document).ready(function() {

        // Show sections
        $('.section').fadeIn();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();
    });
</script>
</body>

</html>