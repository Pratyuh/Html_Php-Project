<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_desc'])){
          $event_desc = addslashes($_POST['event_desc']);
     
        
        
        
        $query = "INSERT INTO notice(event_desc) VALUES('$event_desc')";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            echo "<script>alert('Added event '$event_desc' successfully);</script>";
            echo "<script>window.location.href = 'notice.php';</script>";
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>

