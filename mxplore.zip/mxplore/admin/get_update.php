<?php

    echo $id = $_GET['id'];
    include "DbConnect.php";

    $update = "UPDATE users SET branch = 'paid' WHERE id = '$id'";

    $query_result = mysqli_query($con, $update);

    if(!$query_result) {
        
        echo mysqli_error($con);
    }
    
    header('Location: users.php?msg=Updated Successfully');
?>