<?php
    include "connection.php";
    echo $id = $_GET['id'];


    $s_sql = "DELETE FROM notice WHERE id = '$id'";
    $result = mysqli_query($con, $s_sql);

    if($result){
        header('Location:notice.php');
    }else{
        echo mysqli_error($con);
    }
?>