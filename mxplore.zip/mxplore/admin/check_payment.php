<?php

    echo $id = $_GET['id'];
    include "connection.php";

    $update = "UPDATE users SET Payment = 'VERIFIED' WHERE id = '$id'";

    $query_result = mysqli_query($con, $update);

    if(!$query_result) {
        
        echo mysqli_error($con);
    }
    
    header('Location: users.php?msg=Updated Successfully');
?>