<?php include "connection.php"; ?>
<?php include "includes/header.php"; ?>

<?php
if($_SESSION['is_login']){
      $uname = $_SESSION['uname'];
}else{
    header("Location: index.php");
}
?>

<style type="text/css">
    .custom-container {
    max-width: 1200px;
    margin: 0 auto;
}

</style>
 <?php  

    $s_sql = "SELECT * FROM events";
    $result = mysqli_query($con, $s_sql);
 ?>
<!-- Section: Posts -->
<section class="section section-posts grey lighten-4">
    <div class="custom-container">
        <div class="row">
            <div class="col s12 m12 l12">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Total Events Added users

                            <bold style="font-weight:600;"><?php
                                $rows_total = mysqli_num_rows($result);
                                echo $rows_total;
                            ?></bold>
                        </span>
                        <table class="striped responsive-table">
                            <thead>
                                <tr>
                                    <th>Event Image</th>
                                    <th>Event Name</th>
                                    <th>Event Desc</th>
                                    <th>Event Rule</th>
                                    <th>Registration Fee</th>
                                  
                                    <th>prize_money</th>
                                    <th>Edit</th>
                                    <th>Delete</th>

                                </tr>
                            </thead>
                            <tbody>

                               <?php if ((mysqli_num_rows($result)) > 0) {
                                        while($row = mysqli_fetch_array($result)) {
                                ?>

                                <tr>
                                    <td><img src="upload/<?php echo $row['event_image']; ?>" alt="" class="materialboxed" width="50px"></td>
                                    <td><?php echo $row['event_name']; ?></td>
                                    <td><?php echo $row['event_desc']; ?></td>
                                    <td><?php echo $row['event_rules']; ?></td>
                                    <td><?php echo $row['event_price']; ?></td>
                                  
                                    <td><?php echo $row['prize_money']; ?></td>
                                    <td>
                                        <a href="edit_event.php?id=<?php echo $row['id']; ?>" class="btn blue lighten-2 ">Edit</a>
                                    </td>
                                    
                                    <td>
                                        <a href="delete_event.php?id=<?php echo $row['id']; ?>" class="btn red lighten-2 ">Remove</a>
                                    </td>
                                </tr>
                                <?php

                                    }
                                    } else {
                                        echo "no results";
                                    }

                                    ?>
                                <tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Footer -->
<footer class="section blue darken-2 white-text center">
    <p>Mxplore Panel Copyright &copy; 2020</p>
</footer>




<!-- Add Post Modal -->

        <!-- Preloader -->
<!--
        <div class="loader preloader-wrapper big active">
            <div class="spinner-layer spinner-blue-only">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="gap-patch">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>
-->

        <!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>

        <script>
            // Hide Sections
            $('.section').hide();

            $(document).ready(function() {
            // Show sections
            $('.section').fadeIn();

            // Hide preloader
//            $('.loader').fadeOut();

            //Init Side nav
            $('.button-collapse').sideNav();

            // Init Modal
            $('.modal').modal();

             

            });
        </script>
        </body>

        </html>