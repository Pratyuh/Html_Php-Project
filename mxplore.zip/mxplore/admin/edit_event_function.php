<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_name'])){
        echo $event_name = addslashes($_POST['event_name']);
        echo $event_id = $_POST['event_id'];
        echo $event_desc = addslashes($_POST['event_desc']);
        echo $event_rule = addslashes($_POST['event_rule']);
        echo $event_date = addslashes($_POST['event_date']);
        $event_price = addslashes($_POST['event_price']);
         $prize_money = addslashes($_POST['prize_money']);
       
        
        
        $file_name=$_FILES["event_image"]["name"];
	    $file_type=$_FILES['event_image']['type'];
	    $file_size=$_FILES['event_image']['size'];
	    $file_temp_loc=$_FILES['event_image']['tmp_name'];
        
        $file_store = "upload/".$file_name;
	    move_uploaded_file($file_temp_loc,$file_store);

        
        
        
        $query = "UPDATE `events` SET `event_name` = '$event_name',`event_desc` = '$event_desc', `event_image` = '$file_name', `event_date` = '$event_date', `event_rules` = '$event_rule', `event_price` = '$event_price', `prize_money` = '$prize_money' WHERE id = '$event_id'";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            header('Location: manage_events.php');
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>