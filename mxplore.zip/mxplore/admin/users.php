<?php include "includes/header.php";
       include "connection.php";
?>

<?php
if($_SESSION['is_login']){
      $uname = $_SESSION['uname'];
}else{
    header("Location: index.php");
}
?>


<?php

    

    $s_sql = "SELECT * FROM users";
    $result = mysqli_query($con, $s_sql);
            ?>
            
            
<section class="section section-users grey lighten-4">
    <div class="custom-container">
       <h4 class="center">User Page</h4>
        <div class="row">
            <div class="col s12 m12 l2">
            </div>
            <div class="col s12 m12 l8">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Total Registered users

                            <bold style="font-weight:600;"><?php
                                $rows_total = mysqli_num_rows($result);
                                echo $rows_total;
                            ?></bold>
                        </span>
                        <table  id="tblexportData" class="striped responsive-table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                
                                    <th>College Name</th>
                                  
                                    <th>Payment</th>

                                   
                                    

                                </tr>
                            </thead>
                            <tbody>
                                <?php if ((mysqli_num_rows($result)) > 0) {
                                        while($row = mysqli_fetch_array($result)) {
                                         ?>

                                <tr>
                                    <td><?php echo $name = $row["name"]; ?></td>
                                    <td><?php echo $name = $row["email"]; ?></td>
                                    <td><?php echo $name = $row["mobile_no"]; ?></td>

                                
                                      <td><?php echo $name = $row["college_name"]; ?></td>
                                      

                                        <?php
                                    
                                            $status = $row["Payment"];
                                            
                                            if($status == 'Pending') {
                                                
                                           
                                        ?>
                                        <td><a href="check_payment.php?id=<?php echo $name = $row['id']; ?>" class="btn red  verified"><?php echo $name = $row["Payment"]; ?><a/></td>
                                        
                                        <?php  } else {?>
                                         <td><a href="" class="btn green verified  disabled"><?php echo $name = $row["Payment"]; ?><a/></td>
                                         
                                         <?php } ?>


                                    
                                </tr>
                                <?php
            
                                    }
                                    } else {
                                        echo "no results";
                                    }
    
                                    ?>
                            </tbody>
                        </table>

                        
                    </div>

                </div>

                 <button onclick="exportToExcel('tblexportData', 'user-data')" class="btn btn-success">Export Table Data To Excel File</button>
            </div>
        </div>
    </div>
</section>

<div id="add-event-modal" class="modal">
    <div class="modal-content">
        <h4>Add New Event</h4>
        <form action="event_add.php" method="post" enctype="multipart/form-data">
            <label>Select an image of event</label>
            <div class="file-field input-field">
                <div class="btn">
                    <span>Browse</span>
                    <input type="file" multiple name="event_image" />
                </div>

                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload multiple files" />
                </div>
            </div>
            <div class="input-field">
                <input type="text" id="title" name="event_name">
                <label for="title">Event Name</label>
            </div>
            <div class="input-field">
                <textarea name="event_desc" id="body" class="" rows="30"></textarea>
                <label for="body">Event Description</label>
            </div>

            <div class="input-field">
                <textarea name="event_rule" class="" rows="30"></textarea>
                <label for="body">Event Rules</label>
            </div>
            <label for="title">Event Date</label>
            <div class="input-field">

                <input type="date" id="title" name="event_date">

            </div>
            <div class="modal-footer">
                <input type="submit" class=" btn blue white-text" value="Add Event" name="submit">
            </div>
        </form>
    </div>
</div>

<!-- Footer -->
<footer class="section blue darken-2 white-text center">
    <p>Mxplore admin Panel Copyright &copy; 2020</p>
</footer>

<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>
<script src="js/chart.js"></script>

<script>
    // Hide Sections
    $('.section').hide();
    $(document).ready(function() {
        // Show sections
        $('.section').fadeIn();

        // Hide preloader
        $('.loader').fadeOut();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();
    });
</script>

<!-- export -->

<script type="text/javascript">
function exportToExcel(tableID, filename = ''){
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'export_excel_data.xls';
    
    // Create download link element
    downloadurl = document.createElement("a");
    
    document.body.appendChild(downloadurl);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTMLData], {
            type: dataFileType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;
    
        // Setting the file name
        downloadurl.download = filename;
        
        //triggering the function
        downloadurl.click();
    }
}
 
</script>

</body>

</html>