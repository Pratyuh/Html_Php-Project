
<?php include "connection.php"; ?>
<?php include "includes/header.php";

if(isset($_GET['id'])){
        $event_edit_id = $_GET['id'];
    }
?>


 <?php  

    $s_sql = "SELECT * FROM events WHERE id = '$event_edit_id'";
    $result = mysqli_query($con, $s_sql);
    $row = mysqli_fetch_array($result);
 ?>
<!-- Section: Posts -->
<div class="container">
   <div class="col s12 m12 l12 card" style="padding:30px;">
       <h4>Edit Event </h4>
        <form action="edit_event_function.php" method="post" enctype="multipart/form-data">
            <label>Change event image</label>
            <div class="file-field input-field">
                <div class="btn">
                    <span>Browse</span>
                    <input type="file" multiple name="event_image" value="" />
                </div>

                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload multiple files" value="<?php echo $row['event_image']; ?>" />
                    <img src="upload/<?php echo $row['event_image']; ?>" alt="" width="50px;">
                </div>
            </div>
                <div class="input-field">
                    <input type="text" id="title" name="event_name" value="<?php echo $row['event_name']; ?>">
                    <label for="title">Event Name</label>
                </div>
                 <div class="input-field">
                           <label for="body">Event Description</label><br>
                <textarea name="event_desc" id="body" class="" rows="30"><?php echo $row['event_desc']; ?></textarea>
             
            </div><br>

                
                    <div class="input-field">
                            <label for="body">Event Rules</label><br>
                <textarea style="height: 150px;" name="event_rule" id="body" class="" rows="30"><?php echo $row['event_rules']; ?></textarea>
            
            </div>
        
        
                <div class="input-field">
                   
                    <input type="hidden" id="title"  name="event_date" value="<?php echo $row['event_date']; ?>">
                    <input type="hidden" value="<?php echo $row['id']; ?>" name="event_id">
                    
                </div>


              


                <label for="title">Registration Fee/</label>
                <div class="input-field">
                   
                    <input type="text" id="title" name="event_price" value="<?php echo $row['event_price']; ?>">
                    
                </div>


                <label for="title">Prize Money Rs/</label>
                <div class="input-field">
                   
                    <input type="text" id="title" name="prize_money" value="<?php echo $row['prize_money']; ?>">
                    
                </div>

                <div class="modal-footer">
                    <input type="submit" class=" btn blue white-text" value="Edit Event" name="submit">
                    
                    <a href="manage_events.php"style="background-color: red; padding: 5px;color: white;float:right; ">Cancel </a>
                </div>
        </form>

   </div>
    
</div>
<!-- Footer -->
<footer class="section blue darken-2 white-text center">
    <p>Madmin Panel Copyright &copy; 2018</p>
</footer>



<!-- Add Post Modal -->

        <!-- Preloader -->
<!--
        <div class="loader preloader-wrapper big active">
            <div class="spinner-layer spinner-blue-only">
                <div class="circle-clipper left">
                    <div class="circle"></div>
                </div>
                <div class="gap-patch">
                    <div class="circle"></div>
                </div>
                <div class="circle-clipper right">
                    <div class="circle"></div>
                </div>
            </div>
        </div>
-->

        <!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>

        <script>
            // Hide Sections
            $('.section').hide();

            $(document).ready(function() {
            // Show sections
            $('.section').fadeIn();

            // Hide preloader
//            $('.loader').fadeOut();

            //Init Side nav
            $('.button-collapse').sideNav();

            // Init Modal
            $('.modal').modal();
            
            });
        </script>
        </body>

        </html>