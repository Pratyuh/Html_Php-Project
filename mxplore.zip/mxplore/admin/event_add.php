<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_name'])){
         $event_name = addslashes($_POST['event_name']);
         $event_desc = addslashes ($_POST['event_desc']);
         $event_rule =addslashes ($_POST['event_rule']);
         $event_date =addslashes ($_POST['event_date']);
         $event_price = addslashes($_POST['event_price']);
          $prize_money = addslashes($_POST['prize_money']);
        
       $file_name=$_FILES["event_image"]["name"];
      $file_type=$_FILES['event_image']['type'];
      $file_size=$_FILES['event_image']['size'];
      $file_temp_loc=$_FILES['event_image']['tmp_name'];
        
        $file_store = "upload/".$file_name;
        move_uploaded_file($file_temp_loc,$file_store);

       
        
        
        
        $query = "INSERT INTO events(event_name, event_desc, event_image,event_date,event_rules,event_price,prize_money) VALUES('$event_name','$event_desc','$file_name','$event_date','$event_rule','$event_price','$prize_money')";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            echo "<script>alert('Added event '$event_name' successfully);</script>";
            echo "<script>window.location.href = 'manage_events.php';</script>";
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>

