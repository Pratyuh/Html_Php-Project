
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

</head>

<?php include "includes/header.php"; ?>
<?php
include "connection.php";

if(isset($_POST['but_submit'])){

    $uname = mysqli_real_escape_string($con,$_POST['txt_uname']);
    $password = mysqli_real_escape_string($con,$_POST['txt_pwd']);

    if ($uname != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from admin where username='".$uname."' and password='".$password."'";
        $result = mysqli_query($con,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){

          
          $_SESSION['is_login']=true;
          
            $_SESSION['uname'] = $uname;
             echo '<script language="javascript">';
        echo 'swal({
  title: "Success!",
  type: "success",
  timer: 500,
  showConfirmButton: false
}, function(){
      window.location.href = "main.php";
});';
        echo '</script>';
       }else{
             echo '<script language="javascript">';
        echo 'swal("Opps!", "InCorrect Email And Password!", "error");';
        echo '</script>';
        }

    }

}
?>



<section class="section section-login">
    <div class="container">
        <div class="row">
            <div class="col s12 m8 offset-m2 l6 offset-l3" >
                <div class="card-panel login " style=" background-color:#D48230;" >
                    <h4 style="color:#ffffff;">Mxplore Admin Panel</h4>

                    <form  method="post">

                       
                        <div class="input-field">
                            <i class="material-icons prefix white-text">email</i>
                            <input type="text" id="txt_uname" name="txt_uname">
                            <label class="white-text" for="email">Username</label>
                        </div>

                        <div class="input-field">
                            <i class="material-icons prefix white-text">lock</i>
                            <input type="password" id="txt_uname" name="txt_pwd">
                            <label class="white-text" for="password">Password</label>
                        </div>

                        
                       
                        <button type="submit" value="Submit" name="but_submit" class="btn btn-large btn-extended green lighten-3 black-text" id="but_submit">Login</button>
                      <!--   <p style="text-align: center;color: #fff; font-size: 15px;">Username- mxplore && Pwd- mxplore</p> -->
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>







<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/jquery-3.4.1.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>


</script>
</body>

</html>