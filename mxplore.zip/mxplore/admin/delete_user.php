<?php
    include "connection.php";
    echo $id = $_GET['id'];


    $s_sql = "DELETE FROM registered_events WHERE regd_id = '$id'";
    $result = mysqli_query($con, $s_sql);

    if($result){
        header('Location:main.php');
    }else{
        echo mysqli_error($con);
    }
?>