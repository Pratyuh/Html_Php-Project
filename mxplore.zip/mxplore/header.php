<?php
session_start();
include "DbCOnnect.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    
    <title>mXplore Vol.1</title>
    
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="keywords" content="mxplore,mxplore'19, mechnical events, mxplore 2k19,mxplore 19 mxplore, mechanical gce kjr, mxplore gce kjr,mechnicalgce kjr,mxplore,Mxplore">
    <meta name="description" content="mXplore Vol.1 is a grand tech symphosium Which Is Going To be Organise by Department Of Mechanical Engineering  GOVERNMENT COLLEGE OF ENGINEERING, KEONJHAR From 18 to 20 January 2020.">
    
    
    <!-- Favicons -->
  <link href="img/favicon.ico" rel="icon">
  <link href="img/favicon.jpg" rel="favicon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">
    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/event.css">
    <link rel="stylesheet" href="css/style2.css">
    <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/archicoco" type="text/css"/>
    <link rel="stylesheet" href="./css/bell1.css">
    <link rel="stylesheet" href="./css/bellbox.css">
    <link rel="stylesheet" href="./css/notifiy.css">
    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <!-- Notice -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    
    <script type="text/javascript" src="./js/scrolltop1.js"></script>
    <script type="text/javascript" src="./js/notify1.js"></script>
    
    
    <link rel="stylesheet" href="./css/bell1.css">
    <link rel="stylesheet" href="./css/bellbox.css">
    <link rel="stylesheet" href="./css/notifiy.css">
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-149346447-2"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'UA-149346447-2');

    
    </script>
    
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-152055986-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152055986-1');
</script>


   


  </head>
  <body >
    <!--==========================
    Header
    ============================-->
    <header id="header" >
      <div class="container">
        <div id="logo" class="pull-left">
          <!-- Uncomment below if you prefer to use a text logo -->
          <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
          <a href="main.php"><img src="img/kk.png" alt="" title="" style="height: 300px;"></a>
          
        </div>
        <nav id="nav-menu-container">
          <ul class="nav-menu">
            <?php if(isset($_SESSION['id'])){
            
            ?>
            <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
            <li class="menu-active"><a href="main">Home</a></li>
            
            <li><a href="event">Events</a></li>
            <li><a href="registered_event">My Registered Events</a></li>
            <li><a href="hospitality">Hospitality</a></li>
            <li><a href="" data-toggle="modal" data-target="#exampleModal">Contact Us</a></li>
            
            <li><a href="logout.php"><i class="fa fa-sign-out"> </i> Logout </a></li>
            <?php }else{ ?>
            <li><a href="admin/index.php">Admin</a></li>
            <li class="menu-active"><a href="main">Home</a></li>
            <li ><a href="event">Events</a></li>
            <li><a href="schedule">Schedule</a></li>
            <li><a href="" data-toggle="modal" data-target="#exampleModal">Contact Us</a></li>
            <li><a href=""  data-toggle="modal" data-target="#modalLRForm">LogIn/Register</a></li>
            
            
            <?php } ?>
          </ul>
          </nav><!-- #nav-menu-container -->
        </div>
        </header><!-- #header -->

       <!-- Modal For Contact US -->
  <div  class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 50px;" >
      <div class="modal-content" >

         <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
        
        <div class="modal-body" >
           <section id="speakers" class="" style="background-color: #fff; padding-top: 2px">
      <div class="container" >

         <center><b> <u>Convenor</u></b><br>
         		<img src="img/cov-c.png" style="width: 85px; height: 85px;"><br>
        Dr. Ramesh Chandra Mohapatra <br>
        <a href = "mailto: rameshmohapatra75@gmail.com">rameshmohapatra75@gmail.com</a><br><br>
        <u><b>Co-Convenor</u></b><br>
        	<img src="img/cov.png" style="width: 85px; height: 85px;"><br>
        Mr. Dayanidhi Jena <br>
    <a href = "mailto: dayanidhijena_fme@gcekjr.ac.in">dayanidhijena_fme@gcekjr.ac.in</a><br><br>


        <u><b>Faculty Co-Ordinator</u></b><br>
         Mr. Suchit Kumar Gupta :
        <a href = "mailto: suchitgupta23@gmail.com">suchitgupta23@gmail.com</a><br>
        Ms. Partha Sarathi Mishra:
        <a href = "mailto: mpartha09002@gmail.com">mpartha09002@gmail.com</a>
         <br><br>


         <b><u>Student Co-ordinators</u></b><br>
            Chinmaychiranjeeb Nayak : <a href="tel:8895384889">8895384889</a><br>
            Jyoti Prakash Pattaink : <a href="tel:8249115158">8249115158</a><br>
            Vishal Jaiswal : <a href="tel:6370509764">6370509764</a><br>
            K Raghuram Naidu : <a href="tel:7978523335">7978523335</a><br>
   
      Mail Us:
      <a href = "mailto: mxplore@gcekjr.ac.in">mxplore@gcekjr.ac.in</a>
       </center> 
       
         </div>

    </section>
        </div>

      
      </div>
    </div>
  </div>
</div>
</div>

</div>