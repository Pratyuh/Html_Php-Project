<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Hospitality</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="keywords" content="mxplore events,mxplore event page, mxplore mechanical engineering, mechanical gce kjr,mechanical brnch,mechanical branch gce kjr,mechanical gce,mxplore vol.1,mxplore hospitailty page, expert , hospitality mxplore,hospitality">
        <meta name="description" content="Here is our hospitality facility decribe">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: TheEvent
    Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6);" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="main.php"><img src="img/kk.png" alt="" title="" style="width: 200px; height: 40px;"></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="main" >Home</a></li>
                    <li ><a href="event" >Events</a></li>
                     <li class="menu-active"><a href="hospitality">Hospitality</a></li>
                    <li><a href="registered_event" >My Registered Events</a></li>
                   <li><a href=""  data-toggle="modal" data-target="#exampleModal" >Contact Us</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }else{ ?>
                    <li><a href="main" >Home</a></li>
                     <li ><a href="event" >Events</a></li>
                     <li class="menu-active"><a href="hospitality">Hospitality</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                     <li><a href=""  data-toggle="modal" data-target="#exampleModal" >Contact Us</a></li>
                  
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">
      
        <!--==========================
     Hospitaliy Section
    ============================-->
     <section id="schedule" class="section-with-bg" style="background-color: #E9EBB3;">
      <div class="container wow fadeInUp">
       <div class="section-header">
          <h2 >Hospitality</h2>
         
        </div>
        
        
           <center><h4 style="margin-bottom: 10px;font-weight: bold;"><u>Accommodation</u></h4></b></center>
               <p style="text-align: justify;">Our campus is a very beautyful campus like as it is situated on the lap of nature surrounded by hills and green lands. In keonjhar most of the tourist attractions are also nearest to our campus.<br>
               We have well maintained canteen facilities and an awesome cafeteria where you can enjoy delecious foods. And we also provide separate and secure accomodation facilities for both boys and girls.<br>
               So, during mXplore if you want a stay at our campus you have to fill the form below.<br>
               If you are facing any problem or having any query kindly contact on the contact details provided below. We will be happy to help you...<br>
               Kindly read the below instructons carefully before proceeding further.<br><br><br>
               
               
               Mr. Chinmay <a href="tel:8895384889">8895384889</a> <br>
                    Mr. Vishal <a href="tel:8093644524">8093644524</a> <br> 
                      Mr. Jyoti <a href="tel:8249115158">8249115158</a> </p><br><br><br>
                    
                    





      <h4><u>INSTRUCTIONS</u></h4> 
   <p style="text-align: justify;">   1. Only participants from outside of keonjhar will be considered for accommodation.<br>
2. All the participants are required to carry their college identity cards which will be
verified at the Registration Desk with your registered names.<br>
3.We can only provide free accomodation, for lunch and dinner you have to pay at the canteen.<br>
4.For availing the accomodation facility you have to undertake that your stay is completely your responsibility we won't be responsible for anyother things except providing the accomodation facilities. You have to follow all code of conducts provided by the hostel authority & you can't misbehave any one inside he campus in case of any problem without informing us.<br>
</p> <br>
 <center> <a style="background-color: #F35F0B;  color: white; padding: 8px;border-radius: 12px; font-size: 18px;" target="_blank" href="https://docs.google.com/a/gcekjr.ac.in/forms/d/1sG5toCpS6L1w_h2RCQAuRU9Po_YABdTVXaRDsPvF-08/edit?usp=drivesdk" >REGISTER HERE</a></center>

     </div>
     
     

           

        </div>

      </div>

    </section>

   
   

  

           <!-- Modal For Contact US -->
  <div  class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="margin-top: 50px;" >
      <div class="modal-content" >

         <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
        
        <div class="modal-body" >
           <section id="speakers" class="wow fadeInUp" style="background-color: #fff; padding-top: 2px">
      <div class="container" >

         <center><b> <u>Convenor</u></b><br>
            <img src="img/cov-c.png" style="width: 85px; height: 85px;"><br>
        Dr. Ramesh Chandra Mohapatra <br>
        <a href = "mailto: rameshmohapatra75@gmail.com">rameshmohapatra75@gmail.com</a><br><br>
        <u><b>Co-Convenor</u></b><br>
          <img src="img/cov.png" style="width: 85px; height: 85px;"><br>
        Mr. Dayanidhi Jena <br>
    <a href = "mailto: dayanidhijena_fme@gcekjr.ac.in">dayanidhijena_fme@gcekjr.ac.in</a><br><br>


        <u><b>Faculty Co-Ordinator</u></b><br>
         Mr. Suchit Kumar Gupta :
        <a href = "mailto: suchitgupta23@gmail.com">suchitgupta23@gmail.com</a><br>
        Ms. Partha Sarathi Mishra:
        <a href = "mailto: mpartha09002@gmail.com">mpartha09002@gmail.com</a>
         <br><br>


         <b><u>Student Co-ordinators</u></b><br>
            Chinmaychiranjeeb Nayak : <a href="tel:8895384889">8895384889</a><br>
            Jyoti Prakash Pattaink : <a href="tel:8249115158">8249115158</a><br>
            Vishal Jaiswal : <a href="tel:6370509764">6370509764</a><br>
            K Raghuram Naidu : <a href="tel:7978523335">7978523335</a><br>
   
      Mail Us:
      <a href = "mailto: mxplore@gcekjr.ac.in">mxplore@gcekjr.ac.in</a>
       </center> 
       
         </div>

    </section>
        </div>
      
      </div>
    </div>
  </div>
</div>
</div>

</div>

  



  
<?php include "footer.php"; ?>
    

