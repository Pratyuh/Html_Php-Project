<?php
      include "DbConnect.php";
      session_start();

    $u_id = $_SESSION['id'];

    echo $id = $_GET['event_id'];



    $s_sql = "DELETE FROM registered_events WHERE event_id = '$id' AND user_id='$u_id'";
    $result = mysqli_query($con, $s_sql);

    if($result){
        header('Location:event.php');
    }else{
        echo mysqli_error($con);
    }
?>