  

  <section id="speakers" class="wow fadeInUp" >
      <div class="container">
        <div class="section-header">
          <h2>Expert Talk</h2>
           <p style="color: #938F8B;">Our Experts</p>
        </div>



        <div class="row">

       
          <div class="col-lg-6 col-md-6">
            <div class="speaker">
              <img src="img/speakers/1.jpg" alt="Speaker 2" class="img-fluid">
              <div class="details">
                <h3><a href="http://www.iitbbs.ac.in/profile-print.php?furl=sramanujam" target="_blank"> Dr. Srinivasa Ramanujam Kannan</a></h3>
                <p>Assistant Professor,School of Mechanical Sciences,<br> IIT BHUBANESWAR</p>
                
              </div>
            </div>
          </div>
       
          <div class="col-lg-6 col-md-6">
            <div class="speaker">
              <img src="img/speakers/2.jpg" alt="Speaker 4" class="img-fluid">
              <div class="details">
                <h3><a href="http://nitrkl.irins.org/profile/61983" target="_blank">Dr Manoj Kumar Moharana</a></h3>
                <p>Assistant Professor, Department Of Mechanical Engineering<br>  National Institute of Technology, Rourkela,</p>
                
              </div>
            </div>
          </div>

            
        
        </div>
      </div>

    </section>
