<!DOCTYPE HTML>
<html lang="en">
<head>
	<title>mXplore Vol.1</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8">
	 <meta name="keywords" content="mxplore,mxplore'19, mechnical events, mxplore 2k19,mxplore 19 mxplore, mechanical gce kjr, mxplore gce kjr,mechnicalgce kjr,mxplore,Mxplore,mxplore index page,main page of mxplore,landing page of mxplore,mxplore mechanical engineering,mxplore,mxplore">
    <meta name="description" content="mXplore Vol.1 is the big event which organised by Mechanical engineering department student in Gce kjr on 18-20 January 2020.">
	
	<!-- Font -->
	
	 <link href="img/favicon.ico" rel="icon">
  <link href="img/favicon.jpg" rel="favicon">
	
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CPoppins:400,500" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/stylespace.css">
	
	<link href="land-css/ionicons.css" rel="stylesheet">
	
	
	<link rel="stylesheet" href="jquery.classycountdown.css" />
			<link href="https://fonts.googleapis.com/css?family=ZCOOL+XiaoWei&display=swap" rel="stylesheet">
	<link href="land-css/styles.css" rel="stylesheet">
	<link href="land-css/stylespace.css" rel="stylesheet">

	
	<link href="land-css/responsive.css" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style type="text/css">
		#myVideo {
  position: fixed;
  right: 0;
  bottom: 0;
  min-width: 100%; 
  min-height: 100%;
}

.icon-bar {
  position: fixed;
  top: 45px;
  left: 10px;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

.icon-bar3 {
  position: fixed;
  top: 200px;
  left: 150px;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);

  width: 80px;
  height: 80px; 


}

.icon-bar1 {
  position: fixed;
  top: 45px;
  right: 5px;
  -webkit-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

	@keyframes fadeIn {
  from{
  	opacity: 0;
  }
  to{
  	opacity: 1;
  }
}

		@keyframes fadeOUTIn {
  from{
  	opacity: 0;
  }
  to{
  	opacity: 1;
  }
}





	</style>
	
	
	
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-152055986-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-152055986-1');
</script>

	
</head>
<body class="bg-purple">

	

<div class="icon-bar">
	<img src="images/ff.png" style="width: 120px; height: 75px; float: left;">


</div>

<div class="icon-bar3">
	<img class="object_earth" src="http://salehriaz.com/404Page/img/earth.svg" >
</div>




<div class="icon-bar1">
	<img src="images/d.png" style="width: 135px; height: 75px; float: right;">
</div>
	
	<div class="main-area center-text star"  style="background: none;" >



		
		  <div class="objects">
 	
		<div class="display-table">

			<div class="display-table-cell">
			  
			 <div id="normal-countdown"  style="margin-top: 90px; font-size: 80px;">WelCome</div> 
			 	
              <div style="margin-top: 25px; margin-bottom: 0px; padding: 0px;">
		   <img src="images/kk.png" style="width: 320px; height: 100px;" style="margin-top: 100px; ">
		   </div>
		   

				<p class="desc font-white" style="animation: fadeIn 6s; font-size: 13px; font-weight: bold;font-family: 'ZCOOL XiaoWei', serif; color: #FC8608; margin-top: 20px;"><b style="color:red; font-size:15px;">Sponsored By TEQIP III</b> <br> 18-20 January 2020<br> DEPT. OF MECHANICAL ENGINEERING<br>
                                GOVERNMENT COLLEGE OF ENGINEERING, KEONJHAR <br></p>
				
				<div class="email-int-area" style="margin-bottom: 40px;">
					

						
						<a class="notify-btn " href="main.php"  title="main" style="  background: red;"><b>Let's Start</b></a>
						
						
						

						<!--<a class="notify-btn" style="pointer-events: none;background-color=red;" href="main.php" ><b>Register Now</b></a>	-->

				</div><!-- email-input-area -->
				
						
				


                <img class="object_rocket" src="http://salehriaz.com/404Page/img/rocket.svg" width="40px">
               
                <div class="box_astronaut">
                    <img class="object_astronaut" src="http://salehriaz.com/404Page/img/astronaut.svg" width="140px">
                </div>

            </div>
				
							
				
		

				
			</div><!-- display-table -->
		</div><!-- display-table-cell -->

		

		  <div class="glowing_stars">
                <div class="star"></div>
                <div class="star"></div>
                <div class="star"></div>
                <div class="star"></div>
                <div class="star"></div>

            </div>

            
	</div><!-- main-area -->


            
	
	
	<!-- SCIPTS -->
	
	<script src="land-js/jquery-3.1.1.min.js"></script>
	
	<script src="land-js/jquery.countdown.min.js"></script>
	
	<script src="land-js/scripts.js"></script>


	
</body>
</html>