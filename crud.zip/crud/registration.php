<?php

include('db/connection.php');

if (isset($_POST['submit'])) {

  $name=$_POST['name'];
  $pwd=$_POST['pswd'];
if($name !="" || $pwd !=""){
  $query=mysqli_query($conn,"insert into user (name,password) VALUES ('$name','$pwd') ");

  if ($query) {
  	 echo "<script> alert('sucess'); </script>";
  }else{
  	echo "failed";
  }
}else{
	echo "<script> alert('filed all '); </script>";
}
}


?>
