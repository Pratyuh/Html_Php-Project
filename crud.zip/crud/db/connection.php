<?php
         $username = "root";
         $host = "localhost";
         $password = "";
         $database_name = "crud";
           $conn =mysqli_connect($host, $username, $password, $database_name);
        


?>