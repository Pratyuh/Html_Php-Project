<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Expert Talk</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: TheEvent
    Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6); height: 70px;" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li ><a href="event.php" class="text-white">Events</a></li>
                    <li><a href="registered_event.php" class="text-white">My Registered Events</a></li>
                     <li><a href="contactus.php">Contact Us</a></li>
                    <li class="menu-active"><a href="schedule.php" class="text-white">Schedule</a></li>
                    <li><a href="logout.php" class="text-white"><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }else{ ?>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li class=""><a href="event.php" class="text-white">Events</a></li>
                     <li><a href="contactus.php">Contact Us</a></li>
                     <li class=""><a href="schedule.php" class="text-white">Schedule</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">

   
   

   <!--==========================
      Speakers Section
    ============================-->
    <section id="speakers" class="wow fadeInUp" style="background-color: #BA6BFB; padding-top:120px;">
      <div class="container">
        <div class="section-header">
          <h2>Expert Talk</h2>
          <p style="color: #fff">Here are some of our Expert</p>
        </div>

        <div class="row">
          <div class="col-lg-3 col-md-6">
            <div class="speaker">
              <img src="img/speakers/1.jpg" alt="Speaker 1" class="img-fluid">
              <div class="details">
                <h3><a href="#">Dr. Rajesh Roshan Dash</a></h3>
                <p>Associate Professor,school of Infrastructure,<br> IIT BHUBANESWAR</p>
               
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="speaker">
              <img src="img/speakers/2.jpg" alt="Speaker 2" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Dr. Partha Pratim Dey</a></h3>
                <p>Assistant Professor,school of Infrastructure,<br> IIT BHUBANESWAR</p>
                
              </div>
            </div>
          </div>
       
          <div class="col-lg-3 col-md-6">
            <div class="speaker">
              <img src="img/speakers/3.jpg" alt="Speaker 4" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Dr. Arindam Sarkar</a></h3>
                <p>Assistant Professor, school of Infrastructure,<br> IIT BHUBANESWAR </p>
                
              </div>
            </div>
          </div>

            <div class="col-lg-3 col-md-6">
            <div class="speaker">
              <img src="img/speakers/4.jpg" alt="Speaker 4" class="img-fluid">
              <div class="details">
                <h3><a href="speaker-details.html">Dr. B. Hanumantha Rao</a></h3>
                <p>Assistant Professor, school of Infrastructure,<br> IIT BHUBANESWAR</p>
               
              </div>
            </div>
          </div>
        
        </div>
      </div>

    </section>

    
   <!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:70px;">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-- Bootstrapmdb>
      <div class="modal-c-tabs"-->

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel8" role="tab">
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content p-3">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
              <div class="md-form form-sm mb-5">
                <input type="email" id="login-email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput10">Your email</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="login-password" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label>
              </div>
              <div class="text-center mt-2">
                <button class="btn btn-success btn-block p-3" id="user_login-btn">Log in </button>
              </div>
            </div>

          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">

            <!--Body-->
            <div class="modal-body">
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Name</label>
              </div>

              <div class="md-form form-sm mb-5">
                <input type="email" id="signup_email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_college_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">College Name</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_phone_no" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_user_branch" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput12">Branch</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="signup_password" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput14">Password</label>
              </div>


              <div class="text-center form-sm mt-2">
                <button class="btn btn-success btn-block  p-3" id="signup-btn">Sign up </button>
              </div>

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->

<script>

    $(document).ready(function() {

         $("#user_login-btn").on("click", function() {

            var login_email = $("#login-email").val();
            var login_password = $("#login-password").val();
            if(login_email.length == 0 && login_password.length == 0){
              alert("Please enter all the field");
        }else{
            $.ajax({
                url: "login.php",
                type: "post",
                data: {
                    email: login_email,
                    password: login_password
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
          
          
          
          
            $("#signup-btn").on("click", function() {
            var name = $("#signup_name").val();
            var email = $("#signup_email").val();
            var college_name = $("#signup_college_name").val();
            var branch = $("#signup_user_branch").val();
            var password = $("#signup_password").val();
            var phone_no = $("#signup_phone_no").val();

            if(name.length == 0 && college_name.length == 0){
                alert("Please enter all fields");
            } else {
            $.ajax({
                url: "registration.php",
                type: "post",
                data: {
                    registration: "success",
                    name: name,
                    email: email,
                    password: password,
                    college_name: college_name,
                    branch: branch,
                    phone_no: phone_no
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
        });
            
</script>

  
<?php include "footer.php"; ?>
    

