<?php
    session_start();
    include "DbConnect.php";
    $u_id = $_SESSION['id'];
   

     $s_sql = "SELECT * FROM registered_events WHERE user_id = '$u_id'";
     $result = mysqli_query($con, $s_sql);


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Welcome to nirmana</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/event.css">

    <link rel="stylesheet" href="css/style2.css">
</head>
<body>
    <header id="header" style="background: rgba(0,0,0,0.6);">
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                 <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                    <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="event.php">Events</a></li>
                    <li class="menu-active"><a href="registered_event.php">My Registered Events</a></li>

                    <li><a href="schedule.php">Schedule</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"> </i> Logout </a></li>

                    <?php }else{ ?>
                    <li><a href="index.php">Home</a></li>
                    <li class="menu-active"><a href="event.php">Events</a></li>
                    <li><a href="schedule.php">Schedule</a></li>
                    <li><a href='' data-toggle="modal" data-target="#modalLRForm">Create a account</a></li>
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->




    <div class="container" style = "padding-top:120px; margin-top:50px;padding-bottom:80px;margin-bottom:80px; ">

        <div class="row">
            <div class="col-sm-12 col-md-2 col-lg-2">


            </div>

            <div class="col-sm-12 col-md-8 col-lg-8">

                <h1 class="text-center ">
                    Registered Events by <?php echo $_SESSION['name']; ?>
                </h1>
                    <table class="table">
                        <thead>
                            <th>No.</th>
                            <th>Event Name </th>
                          <!--   <th>Event Price</th> -->
                            <th>Registered time</th>
                        </thead>    
                        <tbody>
                            <?php
                                $i =0;
                             while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) { 

                                ?>
                            <tr>
                                <td> <?php echo $i =$i+1; ?> </td>
                                <td><?php echo $row['event_name']; ?></td><!-- 
                                <td><?php echo $row['event_price']; ?></td> -->
                                <td><?php echo $row['regd_time']; ?></td>


                            </tr>   

                            <?php } ?>
                        </tbody>
                    </table>    
                </h1>   
            </div>

            <div class="col-sm-12 col-md-2 col-lg-2">


            </div>
        </div>  

    </div>
<?php include "footer.php"; ?>



