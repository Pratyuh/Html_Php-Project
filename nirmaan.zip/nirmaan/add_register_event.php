<?php

    include "DbConnect.php";
    if(!empty($_POST['event_name'])){
        
        $event_name = $_POST['event_name'];
        
        $event_price = $_POST['event_price'];
        
         $event_id = $_POST['event_id'];
        
         $user_name = $_POST['user_name'];
        
         $user_id = $_POST['user_id'];
        
         $user_mobile = $_POST['user_mobile'];
        
         $branch_name = $_POST['branch_name'];
        
         $college_name = $_POST['college_name'];
        
        
        
        
        $query = "INSERT INTO registered_events(event_id, event_name, event_price, user_id,user_name, user_mobile, branch_name, college_name) VALUES('$event_id','$event_name','$event_price','$user_id','$user_name','$user_mobile','$branch_name','$college_name')";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            echo "success";
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>