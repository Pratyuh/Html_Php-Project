-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2019 at 06:31 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nirmana`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`, `time_stamp`) VALUES
(15454, 'nirmana', 'ajit', '2019-09-10 10:45:28');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) NOT NULL,
  `event_name` varchar(500) NOT NULL,
  `event_desc` varchar(700) NOT NULL,
  `event_image` varchar(255) NOT NULL DEFAULT 'event.jpg',
  `event_pdf` varchar(500) NOT NULL,
  `event_date` date NOT NULL,
  `event_rules` varchar(255) NOT NULL,
  `event_price` varchar(255) NOT NULL,
  `added_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_desc`, `event_image`, `event_pdf`, `event_date`, `event_rules`, `event_price`, `added_time`) VALUES
(1, 'Dance', 'within a group', 'eftgew1.jpg', '', '2019-09-04', 'ada', '29', '2019-09-18 04:01:41'),
(2, 'sfcd', 'dcvd', 'sign.jpg', 'AJIT.pdf', '2019-09-14', 'dfdf', '30', '2019-09-25 15:48:52'),
(3, 'df', 'fedf', 'sign.jpg', 'AJIT.pdf', '2019-09-14', 'df', 'event_price', '2019-09-25 16:14:50'),
(4, 'sdsf', 'scsf', 'sign.jpg', 'AJIT.pdf', '2019-09-18', 'sdew', 'fsf', '2019-09-25 16:15:40'),
(5, 'sdsd', 'fdwsf', 'sign.jpg', 'AJIT.pdf', '2019-09-21', 'sfwsf', '32', '2019-09-25 16:16:02');

-- --------------------------------------------------------

--
-- Table structure for table `registered_events`
--

CREATE TABLE `registered_events` (
  `regd_id` int(11) NOT NULL,
  `event_id` int(20) NOT NULL,
  `event_name` varchar(255) NOT NULL,
  `event_price` varchar(100) NOT NULL,
  `user_id` int(10) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_mobile` varchar(10) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `college_name` varchar(300) NOT NULL,
  `regd_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registered_events`
--

INSERT INTO `registered_events` (`regd_id`, `event_id`, `event_name`, `event_price`, `user_id`, `user_name`, `user_mobile`, `branch_name`, `college_name`, `regd_time`) VALUES
(19, 1, 'Dance', 'Rs: 29', 20, 'Ajit', '9668854799', 'Cse', 'Gce, kjr', '2019-09-22 17:57:30'),
(20, 4, 'Pepper Dance', 'Rs: ', 20, 'Ajit', '9668854799', 'Cse', 'Gce, kjr', '2019-09-22 17:57:30'),
(21, 3, 'Quiz', 'Rs: 20', 21, 'pratyusa', '8954654444', 'CSE', 'Gce', '2019-09-22 17:57:30'),
(22, 4, 'Pepper Dance', 'Rs: ', 21, 'pratyusa', '8954654444', 'CSE', 'Gce', '2019-09-22 17:57:30'),
(23, 2, 'sfcd', 'Rs: ', 20, 'Ajit', '9668854799', 'Cse', 'Gce, kjr', '2019-09-25 15:51:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(255) NOT NULL,
  `branch` varchar(255) NOT NULL,
  `mobile_no` varchar(10) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `image` varchar(500) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `branch`, `mobile_no`, `college_name`, `image`, `login_time`) VALUES
(1, 'ajit', 'ajitpradhan925@gmail.com', '123', 'cse', '9668854799', '', 'avatar.jpg', '2019-09-09 16:42:11'),
(2, 'ANANT CHARAN PRADHAN', 'ajitpradhan9215@gmail.com', '74b87337454200d4d33f80c4663dc5e5', '', '', '', '', '2019-09-09 17:04:21'),
(3, 'AJIT PRADHAN', 'ajitpradhan9325@gmail.com', '74b87337454200d4d33f80c4663dc5e5', '', '', '', '', '2019-09-09 17:05:18'),
(4, 'ANANT CHARAN PRADHAN', 'ajitpradhan9255@gmail.com', '74b87337454200d4d33f80c4663dc5e5', '', '', '', '', '2019-09-09 17:06:17'),
(5, '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '', '', '2019-09-10 08:26:38'),
(6, 'ANANT CHARAN PRADHAN', 'sagarkumargiri123@gmail.com', '594f803b380a41396ed63dca39503542', '', '', '', '', '2019-09-10 08:28:55'),
(7, 'ANANT CHARAN PRADHAN', 'ajitpradhan92125@gmail.com', '48b36f5f40dacd99436be897204943b8', '', '', '', '', '2019-09-10 08:35:40'),
(8, 'ANANT CHARAN PRADHAN', 'ajitpradhavn925@gmail.com', '098890dde069e9abad63f19a0d9e1f32', '', '', '', '', '2019-09-10 08:43:56'),
(9, 'ANANT CHARAN PRADHAN', 'ajitpradhan93225@gmail.com', '48b36f5f40dacd99436be897204943b8', '', '', '', '', '2019-09-10 08:50:37'),
(10, 'ANANT CHARAN PRADHAN', 'ajitpradhan9243435@gmail.com', '098890dde069e9abad63f19a0d9e1f32', '', '', '', '', '2019-09-10 09:10:57'),
(11, 'ANANT CHARAN PRADHAN', 'ajitpradhan92333435@gmail.com', '098890dde069e9abad63f19a0d9e1f32', '', '', '', '', '2019-09-10 09:11:26'),
(12, 'asa', 'asa@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '', '', '', '', '2019-09-10 09:13:10'),
(13, 'ds', 'dsd@gmail.com', '05305fafd513c43278a70d3dcbb2bcb7', '', '', '', '', '2019-09-10 09:14:02'),
(14, 'dvd', 'dfdf@gmail.com', '74b87337454200d4d33f80c4663dc5e5', '', '', '', '', '2019-09-10 09:15:04'),
(15, 'dsd', 'sd@gmail.com', '5c7d0c90cf9e0ce560956179e8e82e7d', '', '', '', '', '2019-09-10 09:15:55'),
(16, 'fdf', 'ffd@gmail.com', '82d5984c2a2ad4c62caf1dd073b1c91c', '', '', '', '', '2019-09-10 09:17:19'),
(17, 'df', 'dfv@gmail.com', 'cc2bd8f09bb88b5dd20f9b432631b8ca', '', '', '', '', '2019-09-10 09:18:03'),
(18, 'dsd', 'sdsd@gmail.com', '5c7d0c90cf9e0ce560956179e8e82e7d', '', '', '', '', '2019-09-10 09:19:28'),
(19, 'Pratyusa', 'abc@abc.com', '202cb962ac59075b964b07152d234b70', '', '', '', '', '2019-09-10 13:34:29'),
(20, 'Ajit', 'pradhanajit@gmail.com', 'ajit', 'Cse', '9668854799', 'Gce, kjr', '', '2019-09-19 16:39:26'),
(21, 'pratyusa', 'pratyusacool@gmail.com', '1d18c9c90fd3a3e72b8d8ec0d76520bb', 'CSE', '8954654444', 'Gce', '', '2019-09-20 04:59:19'),
(22, 'admin', 'zcs@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'dvd', 'dvd', 'sds', '', '2019-09-20 05:27:11'),
(23, 'aj', 'aj@gmail.com', '96e7db63cb94a44aabfec7d755eb8f68', 'sfdsf', 'sfs', 'sfsf', '', '2019-09-21 16:40:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registered_events`
--
ALTER TABLE `registered_events`
  ADD PRIMARY KEY (`regd_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15455;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `registered_events`
--
ALTER TABLE `registered_events`
  MODIFY `regd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
