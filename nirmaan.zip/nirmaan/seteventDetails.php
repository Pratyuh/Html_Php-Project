<?php
    session_start();
    include "DbConnect.php";
     $id = $_POST['id'];
     $s_sql = "SELECT * FROM events WHERE id = '$id'";
     $result = mysqli_query($con, $s_sql);
    if($result){
        
    }else{
        echo mysqli_error($con);
    }
        while($row = mysqli_fetch_array($result)){;
            $user_name = $_SESSION['name'];
            $college_name = $_SESSION['college_name'];
            $phone_no = $_SESSION['phone_no'];
            $branch = $_SESSION['branch'];
            $user_id= $_SESSION['id'];
                                                  
           $event_name = $row['event_name'];
           $event_id = $row['id'];
            $event_desc = $row['event_desc'];
            $event_rules = $row['event_rules'];
            $event_price = $row['event_price'];
            $event_image = $row['event_image'];

                $return_arr[] = array(
                    "event_name" => $event_name,
                    "event_desc" => $event_desc,
                    "event_image" => $event_image,
                    "event_id" => $event_id,
                    
                    "event_rules" => $event_rules,
                    "event_price" => $event_price,
                    "user_name" => $user_name,
                    "user_id" => $user_id,
                    "user_phone" => $phone_no,
                    "user_branch" => $branch,
                    "user_college" => $college_name
    
                    );

       }
// Encoding array in JSON format
echo json_encode($return_arr);
        
?>