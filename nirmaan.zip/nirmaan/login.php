
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<style type="text/css">
  body{
    background: linear-gradient(217deg, rgba(255,0,0,.8), rgba(255,0,0,0) 70.71%),
            linear-gradient(127deg, rgba(0,255,0,.8), rgba(0,255,0,0) 70.71%),
            linear-gradient(336deg, rgba(0,0,255,.8), rgba(0,0,255,0) 70.71%);
  }
</style>

</head>
<body>

</body>
</html>


<?php 
    session_start();

    include "DbConnect.php";

     $email = $_POST['email'];
     $password = $_POST['password'];

      $select_query = "SELECT * FROM users WHERE email='$email'";
 
      $select_query_result = mysqli_query($con,$select_query);

      $row = mysqli_fetch_array($select_query_result,MYSQLI_ASSOC);
      $id = $row['id'];
      $name = $row['name'];
      $email = $row['email'];
      $branch = $row['branch'];
      $college_name = $row['college_name'];
      $mobile_no = $row['mobile_no'];
      
      $count = mysqli_num_rows($select_query_result );
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
          $_SESSION['id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['college_name'] = $college_name;
            $_SESSION['phone_no'] = $mobile_no;
            $_SESSION['branch'] = $branch;
            header("Location: event.php");
      }else {
       
         echo '<script language="javascript">';
        echo 'swal({
  title: "Oops! Email And Password Incorrcet",
  text: "Redirecting in few seconds.",
  type: "error",
  timer: 1000,
  showConfirmButton: false
}, function(){
      window.location.href = "index.php";
});';
        echo '</script>';
      }
?>



