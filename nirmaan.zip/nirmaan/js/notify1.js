$(document).ready(function(){
	$('.notify-popup').hide();
	$('.notify-tip').hide();
	if ($(window).height() > 736) {
	$('.bell-box').click(function(){
	
	$('.notify-popup').toggle();
	$('.notify-tip').toggle();
  })
  }else{
  $('.bell-box').click(function(){
	$('body').toggleClass('stopscroll','startscroll');
	$('.notify-popup').toggle();
	$('.notify-tip').toggle();
  }) 
  }                    
                       
	})




