<?php include "connection.php"; ?>
<?php include "includes/header.php"; ?>

<style type="text/css">
    .custom-container {
    max-width: 1200px;
    margin: 0 auto;
}

</style>
 <?php  

    $s_sql = "SELECT * FROM notice";
    $result = mysqli_query($con, $s_sql);
 ?>
<!-- Section: Posts -->
<section class="section section-posts grey lighten-4">
    <div class="custom-container">
        <div class="row">
            <div class="col s12 m12 l12">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Total Events Notice Added

                            <bold style="font-weight:600;"><?php
                                $rows_total = mysqli_num_rows($result);
                                echo $rows_total;
                            ?></bold>
                        </span>
                        <table class="striped responsive-table">
                            <thead>
                                <tr>
                                   
                                   
                                    <th>Event Notice</th>
                                   
                                  
                                
                                  
                                     <th>Delete</th>
                                    

                                </tr>
                            </thead>
                            <tbody>

                               <?php if ((mysqli_num_rows($result)) > 0) {
                                        while($row = mysqli_fetch_array($result)) {
                                ?>

                                <tr>
                                   
                                  
                                    <td><?php echo $row['event_desc']; ?></td>
                                    <td>
                                        <a href="delete_notice.php?id=<?php echo $row['id']; ?>" class="btn red lighten-2 ">Remove</a>
                                    </td>
                                   
                                </tr>
                                <?php

                                    }
                                    } else {
                                        echo "no results";
                                    }

                                    ?>
                                <tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Fixed Action Button -->
<div class="fixed-action-btn">
    <a href="#add-event-modal" class="modal-trigger btn-floating btn-large red">
        <i class="material-icons">add</i>
    </a>
</div>

<!-- Footer -->
<footer class="section blue darken-2 white-text center fixed">
    <p>Madmin Panel Copyright &copy; 2018</p>
</footer>


<!--Notice -->
<div id="add-event-modal" class="modal" >
    <div class="modal-content">
        <h4>Add New Event Notice</h4>
        <form action="notice_add.php" method="post" enctype="multipart/form-data">
            
           
            
            <div class="input-field">
                <textarea name="event_desc" id="body" class="" rows="30"></textarea>
                <label for="body">Event Description</label>
            </div>

            

            <div class="modal-footer">
                <input type="submit" class=" btn blue white-text" value="Add Event" name="submit">
            </div>
        </form>
    </div>
</div>






        <!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>

        <script>
            // Hide Sections
            $('.section').hide();

            $(document).ready(function() {
            // Show sections
            $('.section').fadeIn();

            // Hide preloader
//            $('.loader').fadeOut();

            //Init Side nav
            $('.button-collapse').sideNav();

            // Init Modal
            $('.modal').modal();

             

            });
        </script>
        </body>

        </html>