<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_desc'])){
        
        echo $event_id = $_POST['event_id'];
        echo $event_desc = $_POST['event_desc'];
      
        
      
        
        
        
        $query = "UPDATE `notice` SET `event_desc` = '$event_desc'";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            header('Location: notice.php');
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>