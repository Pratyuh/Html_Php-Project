<?php
    
    session_start();
    include "connection.php";
    
    if(isset($_REQUEST['username'])){
        $username = $_REQUEST['username'];
        $password = $_REQUEST['password'];
        
        $username = mysqli_real_escape_string($con, $username);
        $password = mysqli_real_escape_string($con, $password);
        
        $login_query = "SELECT * FROM admin WHERE username = '$username' and password = '$password'";

        $query_result = mysqli_query($con, $login_query);
        if($query_result){
            $data = mysqli_fetch_array($query_result, MYSQLI_ASSOC);
            $id =  $data['admin_id'];
            $username =  $data['username'];
            
            $_SESSION['id'] = $id;
            $_SESSION['username'] = $username;
            
            $num_rows = mysqli_num_rows($query_result);
            
            if($num_rows == 1){
                echo "success";
            }else{
                echo "Sorry invalid id and password or Account doesn't exists!!";
            }
        } else {
            echo mysqli_error($con);
        }
    } 
?>