<?php include "includes/header.php";

       include "connection.php";

        $event  = $_GET['event'];
?>


<?php

    

    $s_sql = "SELECT * FROM registered_events WHERE event_name = '$event'";
    $result = mysqli_query($con, $s_sql);
            ?>
            
            
<section class="section section-users grey lighten-4">
    <div class="custom-container">
       <h4 class="center">Total Registered User on <strong><?php echo $event; ?></strong></h4>
        <div class="row">
            <div class="col s12 m12 l1">
            </div>
            <div class="col s12 m12 l10">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Total Registered users

                            <bold style="font-weight:600;"><?php
                                $rows_total = mysqli_num_rows($result);
                                echo $rows_total;
                            ?></bold>
                        </span>
                     <table id="tblexportData" class="striped responsive-table table-hover">
                            <thead>
                                <tr>
                                   
                                    <th>User name</th>
                                    <th>Mobile no</th>
                                    <th>College name</th>
                                    <th>Branch</th>
                                    
                                    

                                </tr>
                            </thead>
                            <tbody>
                                <?php if ((mysqli_num_rows($result)) > 0) {
                                        while($row = mysqli_fetch_array($result)) {
                                         ?>

                                <tr>
                                    <td><?php echo  $row["user_name"]; ?></td>
                                    <td><?php echo $row["user_mobile"]; ?></td>
                                    <td><?php echo $name = $row["college_name"]; ?></td>
                                    <td><?php echo $name = $row["branch_name"]; ?>
                                    </td>
                                </tr>
                                <?php
            
                                    }
                                    } else {
                                        echo "no results";
                                    }
    
                                    ?>
                            </tbody>
                        </table>
                    </div>



                </div>
                <button onclick="exportToExcel('tblexportData', 'user-data')" class="btn btn-success">Export Table Data To Excel File</button>
            </div>
        </div>
    </div>
</section>



<!-- Footer -->
<footer class="section blue darken-2 white-text center " >
    <p>Madmin Panel Copyright &copy; 2018</p>
</footer>

<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>
<script src="js/chart.js"></script>

<!-- export -->

<script type="text/javascript">
function exportToExcel(tableID, filename = ''){
    var downloadurl;
    var dataFileType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTMLData = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'export_excel_data.xls';
    
    // Create download link element
    downloadurl = document.createElement("a");
    
    document.body.appendChild(downloadurl);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTMLData], {
            type: dataFileType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadurl.href = 'data:' + dataFileType + ', ' + tableHTMLData;
    
        // Setting the file name
        downloadurl.download = filename;
        
        //triggering the function
        downloadurl.click();
    }
}
 
</script>



</body>

</html>