<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_name'])){
         $event_name = $_POST['event_name'];
         $event_desc = $_POST['event_desc'];
         $event_rule = $_POST['event_rule'];
         $event_date = $_POST['event_date'];
         $event_price = $_POST['event_price'];
        
       $file_name=$_FILES["event_image"]["name"];
      $file_type=$_FILES['event_image']['type'];
      $file_size=$_FILES['event_image']['size'];
      $file_temp_loc=$_FILES['event_image']['tmp_name'];
        
        $file_store = "upload/".$file_name;
	    move_uploaded_file($file_temp_loc,$file_store);

        $file_name_pdf=$_FILES["event_pdf"]["name"];
        $file_type=$_FILES['event_pdf']['type'];
        $file_size=$_FILES['event_pdf']['size'];
        $file_temp_loc=$_FILES['event_pdf']['tmp_name'];
        
        $file_store = "upload/pdf/".$file_name_pdf;
        move_uploaded_file($file_temp_loc,$file_store);
        
        
        
        $query = "INSERT INTO events(event_name, event_desc, event_image,event_pdf,event_date,event_rules,event_price) VALUES('$event_name','$event_desc','$file_name','$file_name_pdf','$event_date','$event_rule','$event_price')";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            echo "<script>alert('Added event '$event_name' successfully);</script>";
            echo "<script>window.location.href = 'manage_events.php';</script>";
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>

