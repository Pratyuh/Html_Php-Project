<?php

    include "connection.php";
    if(isset($_POST['submit']) && !empty($_POST['event_name'])){
        echo $event_name = $_POST['event_name'];
        echo $event_id = $_POST['event_id'];
        echo $event_desc = $_POST['event_desc'];
        echo $event_rule = $_POST['event_rule'];
        echo $event_date = $_POST['event_date'];
        $event_price = $_POST['event_price'];
        $event_pdf = $_POST['event_pdf'];
        
        $file_name=$_FILES["event_image"]["name"];
	    $file_type=$_FILES['event_image']['type'];
	    $file_size=$_FILES['event_image']['size'];
	    $file_temp_loc=$_FILES['event_image']['tmp_name'];
        
        $file_store = "upload/".$file_name;
	    move_uploaded_file($file_temp_loc,$file_store);

         $file_name_change=$_FILES["event_pdf"]["name"];
        $file_type=$_FILES['event_pdf']['type'];
        $file_size=$_FILES['event_pdf']['size'];
        $file_temp_loc=$_FILES['event_pdf']['tmp_name'];
        
        $file_store = "upload/".$file_name_change;
        move_uploaded_file($file_temp_loc,$file_store);
        
        
        
        $query = "UPDATE `events` SET `event_name` = '$event_name',`event_desc` = '$event_desc', `event_image` = '$file_name', `event_pdf` = '$event_pdf', `event_date` = '$event_date', `event_rules` = '$event_rule', `event_price` = '$event_price' WHERE id = '$event_id'";
        
        $result = mysqli_query($con, $query);
        
        if($result){
            header('Location: manage_events.php');
            
        }else{
            echo "Failed". mysqli_error($con);
        
        }
        
    }else {
        echo "<script>alert('Please Enter all fields.');</script>";
    }

?>