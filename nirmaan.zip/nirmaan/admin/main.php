<?php include "includes/header.php";
       include "connection.php";
?>

<style>
    .card {
        margin: 10px;
    }

    #main-container {
        margin-left:10% ;
       
    }
    .modal {
        overflow-y: auto;
        height: 100% !important;
         padding-bottom: 20px;
         padding-top: 0;
         margin-top: -30px;
       
    }
    .modal-content {
         margin-bottom: 80px !important;
    }

    @media only screen and (max-width: 600px) {
        .card {
            margin: 30px;
            margin-left: 30px;
            margin-left: 30px;
        }

        #main-container {
            margin-left: 0%;
            padding: 20px;
        }
    }
</style>

<section id="other_admin_section" style="margin-top:10%;">
   
    <div  id="main-container">
        <div class="row center">
            <div class="card green darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Criar</span>
                    
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=Criar" class="btn text-white">Click</a>
                </div>
            </div>
            <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Rotolare</span>
                    
                </div>
                 <div class="card-action" class="text-white">
                    <a href="show_event.php?event=Rotolare" class="btn text-white">Click</a>
                </div>
            </div>
            
            <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Archade</span>
                   
                </div>
                <div class="card-action" class="text-white">
                    <a href="show_event.php?event=Archade" class="btn text-white">Click</a>
                </div>
            </div>

            <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Creatorixx</span>
                </div>
                <div class="card-action">
           <a href="show_event.php?event=Creatorixx" class="btn text-white">Click</a>
                    
                </div>
            </div>
       <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Cityfied</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=Cityfied" class="btn text-white">Click</a>
                </div>
            </div>

             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Right Way</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=Right Way" class="btn text-white">Click</a>
                </div>
            </div>
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Survekshan</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=Survekshan" class="btn text-white">Click</a>
                </div>
            </div>
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Civiomind</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=Civiomind" class="btn text-white">Click</a>
                </div>
            </div>
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">EarthMatters</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=EarthMatters" class="btn text-white">Click</a>
                </div>
            </div>

              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Paper Pr..</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=Paper Presentation" class="btn text-white">Click</a>
                </div>
            </div>

                 <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">PUBG</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=PUBG" class="btn text-white">Click</a>
                </div>
            </div>
                 <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">FINDER</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=FINDER" class="btn text-white">Click</a>
                </div>
            </div>
                 <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">TIK-TOK</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=TIK-TOK" class="btn text-white">Click</a>
                </div>
            </div>

                 <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">ROADIES</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=ROADIES" class="btn text-white">Click</a>
                </div>
            </div>
               
                <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Cre Write</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=CREATIVE WRITING" class="btn text-white">Click</a>
                </div>
            </div>
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Pic Perf.</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=PICTURE PERFECT" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">JALLEBI</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=JALLEBI CHALLENGE" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Movie</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=MOVIE MANIA" class="btn text-white">Click</a>
                </div>
            </div>
           
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">SPELL B</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=SPELL-BEE" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">P. dance</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=PAPER DANCE" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">MEHENDI</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=MEHENDI" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">FACE IT</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=FACE IT" class="btn text-white">Click</a>
                </div>
            </div>
              <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">T. Hunt</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=TREASURE HUNT" class="btn text-white">Click</a>
                </div>
            </div>

               <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">Handicraft</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=PANACHE(handcraft)" class="btn text-white">Click</a>
                </div>
            </div>
            
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">FIERYFEET</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=FIERYFEET" class="btn text-white">Click</a>
                </div>
            </div>
             <div class="card blue-grey darken-1 col l2 s12 m6">
                <div class="card-content white-text">
                    <span class="card-title">KARA-O-KE</span>
                </div>
                <div class="card-action">
                   <a href="show_event.php?event=KARA-O-KE" class="btn text-white">Click</a>
                </div>
            </div>








        </div>
    </div>
</section>
<!-- Footer -->
<footer class="section blue darken-2 white-text center" style="margin-top: 20%;">
    <p>Nirmaan Admin Panel &copy; 2018</p>
</footer>

<!-- Fixed Action Button -->
<div class="fixed-action-btn">
    <a href="#add-event-modal" class="modal-trigger btn-floating btn-large red">
        <i class="material-icons">add</i>
    </a>
</div>




<div id="add-event-modal" class="modal" >
    <div class="modal-content">
        <h4>Add New Event</h4>
        <form action="event_add.php" method="post" enctype="multipart/form-data">
            <label>Select an image of event</label>
            <div class="file-field input-field">
                <div class="btn">
                    <span>Browse</span>
                    <input type="file" multiple name="event_image" />
                </div>

                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload multiple files" />
                </div>
            </div>
            <div class="input-field">
                <input type="text" id="title" name="event_name">
                <label for="title">Event Name</label>
            </div>
            <div class="input-field">
                <textarea name="event_desc" id="body" class="" rows="30"></textarea>
                <label for="body">Event Description</label>
            </div>

             <label>Select an pdf of event</label>
            <div class="file-field input-field">
                <div class="btn">
                    <span>Browse</span>
                    <input type="file" multiple name="event_pdf" />
                </div>

                <div class="file-path-wrapper">
                    <input class="file-path validate" type="text" placeholder="Upload multiple files" />
                </div>
            </div>
            <div class="input-field">
                <textarea name="event_rule" class="" rows="30"></textarea>
                <label for="body">Event Rules</label>
            </div>
            <div class="input-field">

                <input type="text" id="title" name="event_price">
                <label for="title">Event Price</label>
            </div>

            <label for="title">Event Date</label>
            <div class="input-field">

                <input type="date" id="title" name="event_date">

            </div>
            <div class="modal-footer">
                <input type="submit" class=" btn blue white-text" value="Add Event" name="submit">
            </div>
        </form>
    </div>
</div>
<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>
<script src="js/chart.js"></script>

<script>
    // Hide Sections
    $('.section').hide();
    $(document).ready(function() {

        // Show sections
        $('.section').fadeIn();

        //Init Side nav
        $('.button-collapse').sideNav();

        // Init Modal
        $('.modal').modal();

        // Init Select
        $('select').material_select();
    });
</script>
</body>

</html>