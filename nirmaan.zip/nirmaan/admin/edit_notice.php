
<?php include "connection.php"; ?>
<?php include "includes/header.php";

if(isset($_GET['id'])){
        $event_edit_id = $_GET['id'];
    }
?>


 <?php  

    $s_sql = "SELECT * FROM notice WHERE id = '$event_edit_id'";
    $result = mysqli_query($con, $s_sql);
    $row = mysqli_fetch_array($result);
 ?>
<!-- Section: Posts -->
<div class="container">
   <div class="col s12 m12 l12 card" style="padding:30px;">

       <h4>Edit Notice </h4>
        <form action="edit_notice_function.php" method="post" enctype="multipart/form-data">
           
           
               
                <div class="input-field">
                    <input name="event_desc" type="text" id="body" class="" rows="30" value="<?php echo $row['event_desc']; ?>">
                    <label for="body">Event Description</label>
                </div>

              
               
              


             
           


                <div class="modal-footer">
                    <input type="submit" class=" btn blue white-text" value="Edit Notice" name="submit">
                </div>
        </form>

   </div>
    
</div>






        <!--Import jQuery before materialize.js-->
        <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="js/materialize.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.8.0/standard/ckeditor.js"></script>

        <script>
            // Hide Sections
            $('.section').hide();

            $(document).ready(function() {
            // Show sections
            $('.section').fadeIn();

            // Hide preloader
//            $('.loader').fadeOut();

            //Init Side nav
            $('.button-collapse').sideNav();

            // Init Modal
            $('.modal').modal();
            
            });
        </script>
        </body>

        </html>