<?php
         $username = "root";
         $host = "localhost";
         $password = "";
         $database_name = "nirmana";
           $con =mysqli_connect($host, $username, $password, $database_name);
        


?>


<?php

        // $con=mysqli_connect("localhost","nirmaan","Sikukalimela@123","nirmana");
        // if (mysqli_connect_errno()) {
        //   echo "Failed to connect to MySQL: " . mysqli_connect_error();
        // }

?>

