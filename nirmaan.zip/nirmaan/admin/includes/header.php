<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
  <!--Import Google Icon Font-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="css/materialize.min.css" media="screen,projection" />
  <link rel="stylesheet" href="css/main.css">

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Nirmana</title>
  <style>
      #add-event-modal{
          max-height:  1000px !important;
      }  
    
  </style>
</head>

<body class="grey lighten-4">
  <nav class="blue darken-2">
    <div style = "
        max-width: 1200px;
        margin: 0 auto;
     
     " >
      <div class="nav-wrapper">
        <a href="main.php" class="brand-logo">Nirmaan</a>
        <a href="#" data-activates="side-nav" class="button-collapse show-on-small right">
          <i class="material-icons">menu</i>
        </a>
        <ul class="right hide-on-med-and-down">
         <?php if(isset($_SESSION['uname'])){
    
         ?>
          <li>
            <a href="main.php">Dashboard</a>
          </li>
          <li>
            <a href="manage_events.php">All Events</a>
   
          </li>
          <li>
            <a href="notice.php">Notice</a>
   
          </li>
           <li>
              <a href="users.php" class="modal-trigger ">Users</a>
          </li>
          <li>
            <a href="main.php"><?php echo $_SESSION['uname']; ?></a>
          </li>
          <li>
            <a href="logout.php">Logout</a>
          </li>
          <?php } else { ?>
              
          <?php } ?>
        </ul>
        <!-- Side nav -->
        <ul id="side-nav" class="side-nav">
        <?php if(isset($_SESSION['uname'])){
    
         ?>
          <li>
            <a href="main.php">Dashboard</a>
          </li>
          <li>
            <a href="manage_events.php">All Events</a>
   
          </li>
          <li>
            <a href="notice.php">Notice</a>
   
          </li>
           <li>
              <a href="users.php" class="modal-trigger ">Users</a>
          </li>
          <li>
            <a href="main.php"><?php echo $_SESSION['uname']; ?></a>
          </li>
          <li>
            <a href="logout.php">Logout</a>
          </li>
          <?php } else { ?>
              
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>