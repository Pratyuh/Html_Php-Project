<?php
    include "connection.php";
    echo $id = $_GET['id'];


    $s_sql = "DELETE FROM users WHERE id = '$id'";
    $result = mysqli_query($con, $s_sql);

    if($result){
        header('Location:users.php');
    }else{
        echo mysqli_error($con);
    }
?>