<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Schedule</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: TheEvent
    Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6);" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li ><a href="event.php" class="text-white">Events</a></li>
                    <li><a href="registered_event.php" class="text-white">My Registered Events</a></li>

                    <li class="menu-active"><a href="schedule.php" class="text-white">Schedule</a></li>
                    <li><a href="logout.php" class="text-white"><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }else{ ?>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li class="menu-active"><a href="schedule.php" class="text-white">Schedule</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                    <li><a href="contactus.php">Contact Us</a></li>
                     <li><a href="#">Create a account</a></li>
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">

   
   

    <!--==========================
      Schedule Section
    ============================-->
     <section id="schedule" class="section-with-bg">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2 >Event Schedule</h2>
          <p style="color:#fff !important;">Here is our event schedule</p>
        </div>

  <!--  <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3</a>
          </li>
        </ul>

        <h3 class="sub-heading" style="color: red;">LUNCH BREAK <time>01.40 PM - 02.50 PM</time> </h3>

        <div class="tab-content row justify-content-center"> -->
        <!-- Schdule Day 1 --> 
      <!--    <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09.00 Am</time></div>
              <div class="col-md-10">
                <h4>Opening Ceremony</h4>
                <p>Fugit voluptas iusto maiores temporibus autem numquam magnam.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>Drawing And Painting</h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:15 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>QUIZ</h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02.50 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>ROTOLLARE</h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>05.50 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>PAPER DANCE</h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>06.30 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>PUBG (SOLO)</h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

           

          </div> -->
          <!-- End Schdule Day 1 -->

          <!-- Schdule Day 2 -->
        <!--  <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-2">

            <div class="row schedule-item">
              <div class="col-md-2"><time>08:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>WORD BUSTER</h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>MINO-CIVIL SURVEKSAM</h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:30 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>FEET OF FIRE</h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>12:45 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>PUBG (SQUAD)</h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:50PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>CRIAR</h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

            

          </div>-->
          <!-- End Schdule Day 2 -->

          <!-- Schdule Day 3 -->
        <!--  <div role="tabpanel" class="col-lg-9  tab-pane fade" id="day-3">

            <div class="row schedule-item">
              <div class="col-md-2"><time>08:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>BATTLE OF VOICE</h4>
                <p>Maiores dignissimos neque qui cum accusantium ut sit sint inventore.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:30 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>ARCADE</h4>
                <p>Veniam accusantium laborum nihil eos eaque accusantium aspernatur.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>TECHNO HUNT</h4>
                <p>Facere provident incidunt quos voluptas.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:50 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>CITIFIED</h4>
                <p>Nam ex distinctio voluptatem doloremque suscipit iusto.</p>
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>05:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>CLOSING CEREMONY AND CARNIVAL NIGHT</h4>
                <p>Eligendi quo eveniet est nobis et ad temporibus odio quo.</p>
              </div>
            </div>

            

          </div> -->
          <!-- End Schdule Day 2 -->  

          <h1 style="text-align: center;">COMING SOON</h1>

        </div>

      </div>

    </section>

    
   <!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:70px;">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-- Bootstrapmdb>
      <div class="modal-c-tabs"-->

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel8" role="tab">
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content p-3">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
              <div class="md-form form-sm mb-5">
                <input type="email" id="login-email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput10">Your email</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="login-password" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label>
              </div>
              <div class="text-center mt-2">
                <button class="btn btn-success btn-block p-3" id="user_login-btn">Log in </button>
              </div>
            </div>

          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">

            <!--Body-->
            <div class="modal-body">
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Name</label>
              </div>

              <div class="md-form form-sm mb-5">
                <input type="email" id="signup_email" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_college_name" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">College Name</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_phone_no" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="signup_user_branch" class="form-control form-control-sm validate p-3" >
                <label data-error="wrong" data-success="right" for="modalLRInput12">Branch</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="signup_password" class="form-control form-control-sm validate p-3">
                <label data-error="wrong" data-success="right" for="modalLRInput14">Password</label>
              </div>


              <div class="text-center form-sm mt-2">
                <button class="btn btn-success btn-block  p-3" id="signup-btn">Sign up </button>
              </div>

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->

<script>

    $(document).ready(function() {

         $("#user_login-btn").on("click", function() {

            var login_email = $("#login-email").val();
            var login_password = $("#login-password").val();
            if(login_email.length == 0 && login_password.length == 0){
              alert("Please enter all the field");
        }else{
            $.ajax({
                url: "login.php",
                type: "post",
                data: {
                    email: login_email,
                    password: login_password
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
          
          
          
          
            $("#signup-btn").on("click", function() {
            var name = $("#signup_name").val();
            var email = $("#signup_email").val();
            var college_name = $("#signup_college_name").val();
            var branch = $("#signup_user_branch").val();
            var password = $("#signup_password").val();
            var phone_no = $("#signup_phone_no").val();

            if(name.length == 0 && college_name.length == 0){
                alert("Please enter all fields");
            } else {
            $.ajax({
                url: "registration.php",
                type: "post",
                data: {
                    registration: "success",
                    name: name,
                    email: email,
                    password: password,
                    college_name: college_name,
                    branch: branch,
                    phone_no: phone_no
                },
                success: function(result) {
                    if (result == "success") {
                        window.location.href = "event.php";

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });
            }
        });
        });
            
</script>

  
<?php include "footer.php"; ?>
    

