<?php
    session_start();
    include "DbConnect.php";

   

     $s_sql = "SELECT * FROM events";
     $result = mysqli_query($con, $s_sql);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EVENTS</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta name="keywords" content="Nirmaan'19 event, events civil engineering, gce kjr event, Nirmaan'19, criar events nirmaan'19, all events nirmaan'19,Nirmaan'19 ,Nirmaan'19 ,Nirmaan'19 ,Nirmaan'19 Nirmaan'19 Nirmaan'19 ,Nirmaan '19, Nirmaan '19 ,Nirmaan '19,Nirmaan '19,Nirmaan '19,Nirmaan '19,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan  ">
   <meta name="description" content="In Nirmaan'19 various events are oraganised at GCE,kjr so participated">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/event.css">

    <link rel="stylesheet" href="css/style2.css">

    <style>

   
        .btn-info {
           width: 200px; 
             height: 40px;
        }
        .participated-btn{
             width: 200px; 
             height: 40px;
        }
        .regi-btn{
             background-color: #808080;
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  border-radius: 8px;
        }

        @media only screen and (max-width: 600px) {
            .btn-info {
                 width: 200px; 
             height: 40px;
            }
            .participated-btn{
                width: 200px; 
             height: 40px;
            }



            .modal {
                margin-top: 10px;

            }
             #modalLRForm{
      margin: 50px; 
  }
        }
        
        .panel {

            border-radius: 4px;
            padding: 1rem;
            margin-top: 0.2rem;
            background-color: #F5F5F5;
            color: #323B40;
        }
        input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}
    </style>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149346447-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149346447-2');
</script>

</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6);">
        <div class="container" >

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                    <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php">Home</a></li>
                    <li class="menu-active"><a href="event.php">Events</a></li>
                    <li><a href="registered_event.php">My Registered Events</a></li>

                    <li><a href="schedule.php">Schedule</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"> </i> Logout </a></li>

                    <?php }else{ ?>
                    <li><a href="index.php">Home</a></li>
                    <li class="menu-active"><a href="event.php">Events</a></li>
                    <li><a href="schedule.php">Schedule</a></li>
                   <li><a href="speaker.php">Expert Talk</a></li>
      <li><a href='' data-toggle="modal" data-target="#modalLRForm">Create a account</a></li> 
        
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->




    <section id="events" class="wow fadeInUp" >



        <section class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="container">
                        <h2 class="text-center" style="color: #112363;font-size: 28px; font-weight: 700; ">Events</h2>
                        <p class="text-center text-danger">Event Schedules check on <a href="schedule.php">Schedule</a> page</p>
                    </div>
                </div>

                <div class="row">
                    <?php if ((mysqli_num_rows($result)) > 0) {
                         while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <div class="col-sm-12 col-md-6 col-lg-3">
                        <div class="card" >
                           <div class="embed-responsive embed-responsive-16by9">
                                <a ><img alt="Card image cap" class="card-img-top embed-responsive-item" src="admin/upload/<?php echo $row['event_image']; ?>" /></a>
                            </div>

                            <div class="card-content card-block">

                                 <h2 style="font-weight: bold;"><a href="#" style="color:#000000; cursor: default; "><?php echo $row['event_name']; ?></a></h2>

                                <input type="hidden" value="<?php echo $row['id']; ?>" id="hidden_data">

                                <p class="card-text text event_id_for_data " 
                                style=" overflow: hidden; 
                               height: 60px;
                                display: -webkit-box;
                                color: red;
                                -webkit-line-clamp: 3;
                                -webkit-box-orient: vertical;"><?php 

                                echo $row['event_desc']; ?></p>



                                 

                                <center>    <p><button style="width: 200px; height: 40px;" type="button" class="button btn btn-secondary btn-lg" data-toggle="modal" data-target="#myModal" val="<?php echo $row['id']; ?>">Detail</button></p></center>
                                <?php if(isset($_SESSION['id'])){
                                    
                                ?>
                                
                                
                                <?php 
                        
                                $user_id = $_SESSION['id'];
                               $event_id = $row['id'];
                              $select_query = "SELECT * FROM registered_events WHERE user_id='$user_id' AND event_id = '$event_id'";

                              $select_query_result = mysqli_query($con,$select_query);

                                if(mysqli_num_rows($select_query_result ) == 1) {
                                    ?>
                                   <center> <button class="btn participated-btn btn-success btn-lg disabled">
                                        Participated
                                    </button></center> 
                                    
                                    <?php
                                  }else {
                                     
                                    
                                    
                                    
                                    ?>
                                     <center>   <p><button class="btn-reg-original btn btn-info btn-lg  js-signin-modal-trigger" href="" data-toggle="modal" data-target="#registerEvent" reg="<?php echo $row['id']; ?>">Participate</button></p></center>
                                <?php
                                  }

                                ?>
                                
                                
                               
                                <?php }else{ ?>
                       <center><p><button style="width: 200px; height: 40px;" type="button" class="button btn btn-danger btn-lg" data-toggle="modal" data-target="#modalLRForm">Register this   event</button></p></center>
                            
                                <?php } ?>
                            </div>

                        </div>
                    </div>
                    <?php

                    }
                    } else {
                        echo "no results";
                    }

                ?>

                </div>
            </div>
        </section>


    </section>


  

    <div class="modal fade" id="modalEventForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header text-center bg-secondary">
                    <h4 class="modal-title w-100 font-weight-bold  text-white">Register On Event</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body mx-5">
                    <div class="md-form mb-5 form-group">
                        <input type="text" id="defaultForm-email" class="form-control p-3 validate" value="<?php echo $_SESSION['name']; ?>">
                        <label data-error="wrong" data-success="right" for="defaultForm-email">Name</label>
                    </div>

                    <div class="md-form mb-4 form-group">
                        <input type="text" id="branch" class="form-control p-3 ">
                        <label data-error="wrong" data-success="right" for="defaultForm-pass">Branch</label>
                    </div>
                    <div class="md-form mb-4 form-group">
                        <input type="text" id="clg-name" class="form-control validate p-3 ">
                        <label data-error="wrong" data-success="right" for="defaultForm-pass">College Name</label>
                    </div>
                    <input type="hidden" value="<?php echo $_SESSION['name']; ?>" id="u_name">
                    <input type="hidden" value="<?php echo $_SESSION['id']; ?>" id="u_id">
                </div>
                <div class="modal-footer d-flex justify-content-center">
                    <button class="btn-event-register btn btn-success btn-block p-3" id="register-btn">Register Event</button>
                </div>
            </div>
        </div>
    </div>




</body>





<!-- Modal For Details -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog" style="max-width:800px !important; margin-top:40px;
    max-height: 500px !important;">

        <!-- Modal content-->
        <div class="modal-content" style="height: 450px;">
            <div class="modal-header" >
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" style="overflow-y: scroll;">
                <div id="login_for_review">
                      <div>
                        <h1 class="event_name">

                        </h1>
                        <img alt="" class="event_image" width="100%" height="250px">
                        <h1 class="">
                            Description
                        </h1>
                        <p class="lead"></p>
                    </div>

                    <div>

                        <h1 class="">
                            Rules
                        </h1>
                        <p class="lead rules"></p>
                    </div>
                     <div class="pb-2" style="margin-bottom: 10px;">

                        <h1 >
                            Problems and Statements
                        </h1>
                        <a class="event_doc" download >
                        for any query download this problem Statements </a>
                    </div>

                    <div>

                        <h1 class="">
                            Prize Money
                        </h1>
                        <p class="lead price"></p>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>


<!-- Modal For Details -->
<div class="modal fade" id="registerEvent" role="dialog">
    <div class="modal-dialog" style="max-width:600px !important;padding:50px;margin-top:0;">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
               <div class="modal-body ">
                <div class="form-group">
                   <input type="hidden" id="event_id_reg">
                   <input type="hidden" id="user_id_reg">
                    <label for="email1">Event name</label>
                    <input type="text" class="form-control p-3 " id="event_name_reg" disabled>
                    <!--            <small id="emailHelp" class="form-text text-muted">Your information is safe with us.</small>-->
                </div>
                <div class="form-group">
                   <!--  <label for="email1">Event Price</label> -->
                    <input type="hidden" class="form-control p-3" id="event_price_reg" disabled>
                </div>
                <div class="form-group">
                    <label for="email1">User name</label>
                    <input type="text" class="form-control p-3" id="user_name_reg" disabled>
                </div>
                <div class="form-group">
                    <label for="email1">Phone no</label>
                    <input type="text" class="form-control p-3" id="phone_no_reg" disabled>
                </div>
                <div class="form-group">
                    <label for="email1">Branch</label>
                    <input type="text" class="form-control p-3" id="user_branch_reg" disabled>
                </div>
                <div class="form-group">
                    <label for="email1">College name</label>
                    <input type="text" class="form-control p-3" id="college_name_reg" disabled>
                </div>
            </div>
            <div class="modal-footer border-top-0 d-flex justify-content-center">
                <button type="submit" class="btn-register-event btn btn-primary
           btn-lg p-3 btn-block
          ">Submit</button>
            </div>
        </div>
    </div>

</div>

  <!-- MODAL SIGNIN SIGNUP FORM -->


    <!-- MODAL SIGNIN SIGNUP FORM -->
    
   <!--Modal: Login / Register Form-->
<div class="modal fade" id="modalLRForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="margin-top:70px;">
  <div class="modal-dialog cascading-modal" role="document">
    <!--Content-->
    <div class="modal-content">

      <!--Modal cascading tabs-- Bootstrapmdb>
      <div class="modal-c-tabs"-->

        <!-- Nav tabs -->
        <ul class="nav nav-tabs md-tabs tabs-2 light-blue darken-3" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" data-toggle="tab" href="#panel7" role="tab"></i>
              Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="tab" href="#panel8" role="tab">
              Register</a>
          </li>
        </ul>

        <!-- Tab panels -->
        <div class="tab-content p-3">
          <!--Panel 7-->
          <div class="tab-pane fade in show active" id="panel7" role="tabpanel">

            <!--Body-->
            <div class="modal-body mb-1">
             <form method="post" action="login.php">
                 <div class="md-form form-sm mb-5">
                <input type="email" id="login-email" class="form-control form-control-sm validate p-3" name="email">
                <label data-error="wrong" data-success="right" for="modalLRInput10">Your email</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="login-password" class="form-control form-control-sm validate p-3" name="password">
                <label data-error="wrong" data-success="right" for="modalLRInput11">Your password</label>
              </div>
              <div class="text-center mt-2">
                <input type="submit" class="btn btn-success btn-block p-3" id="user_login-btn" value="Log in">
              </div>
             </form>
            </div>

          </div>
          <!--/.Panel 7-->

          <!--Panel 8-->
          <div class="tab-pane fade" id="panel8" role="tabpanel">

            <!--Body-->
            <div class="modal-body">
              <form method="post" action="registration.php">
                <div class="md-form form-sm mb-5">
                <input type="text" id="name" class="form-control form-control-sm validate p-3" required name="name">
                <label data-error="wrong" data-success="right" for="modalLRInput12" >Name</label>
              </div>

              <div class="md-form form-sm mb-5">
                <input type="email" id="email" class="form-control form-control-sm validate p-3" required name="email">
                <label data-error="wrong" data-success="right" for="modalLRInput13">E-mail</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="college_name" class="form-control form-control-sm validate p-3" name="college_name">
                <label data-error="wrong" data-success="right" for="modalLRInput12">College Name</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="phone_no" class="form-control form-control-sm validate p-3" name="phone_no">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Phone no</label>
              </div>
              <div class="md-form form-sm mb-5">
                <input type="text" id="branch" class="form-control form-control-sm validate p-3" name="branch">
                <label data-error="wrong" data-success="right" for="modalLRInput12">Branch</label>
              </div>

              <div class="md-form form-sm mb-4">
                <input type="password" id="password" class="form-control form-control-sm validate p-3" name="password">
                <label data-error="wrong" data-success="right" for="modalLRInput14" required>Password</label>
              </div>


              <div class="text-center form-sm mt-2">
                <input type="submit" name="submit" class="btn btn-info btn-block  p-3" id="signup" value="Sign up">
              </div>
              </form>

            </div>
            <!--Footer-->
            <div class="modal-footer">
              <button type="button" class="btn btn-outline-info waves-effect ml-auto" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!--/.Panel 8-->
        </div>

      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: Login / Register Form-->


 <script src="js/placeholders.min.js"></script>

 <script src="js/jquery-3.4.1.min.js"></script>
 <!-- polyfill for the HTML5 placeholder attribute -->

<script>
    $(".btn-register-event").on('click',function() {
        var event_name = $("#event_name_reg").val();
        var event_price = $("#event_price_reg").val();
        var event_id = $("#event_id_reg").val();
        //alert(event_id);
            var user_name = $("#user_name_reg").val();
            var user_mobile = $("#phone_no_reg").val();
            var college_name = $("#college_name_reg").val();
            var branch_name = $("#user_branch_reg").val();
            var user_id = $("#user_id_reg").val();
        
        $.ajax({
                url: "add_register_event.php",
                type: "post",
                data: {
                    event_name: event_name,
                    event_price: event_price,
                    event_id: event_id,
                    user_name: user_name,
                    user_id: user_id,
                    user_mobile: user_mobile,
                    branch_name: branch_name,
                    college_name: college_name
                },
                success: function(result) {
                    if (result == "success") {
                        
                        alert("Successfully Registered");
                        window.location.href = "event.php";
                        

                    } else {
                        alert(result);
                    }

                },
                error: function(error) {
                    alert(error);
                }
            });

    });
    $(".btn-reg-original").click(function() {
        var id = $(this).attr('reg');
        $.ajax({
            url: "seteventDetails.php",
            type: "post",
            data: {
                id: id
            },
            success: function(response) {
                var jsonData = JSON.parse(response);
                for (var i = 0; i < jsonData.length; i++) {
                    var counter = jsonData[i];
                    var event_name = counter.event_name;
                    var event_price = counter.event_price;
                    var event_image = counter.event_image;
                    var event_id = counter.event_id;

                    var user_name = counter.user_name;
                    var user_id = counter.user_id;

                    var user_mobile = counter.user_phone;

                    var user_branch = counter.user_branch;

                    var user_college = counter.user_college;

                    $("#event_name_reg").attr("value",event_name);
                    $("#event_id_reg").attr("value", event_id);
                    $("#event_price_reg").attr("value", "Rs: " + event_price);
                    $("#user_name_reg").attr("value", user_name);
                    $("#user_id_reg").attr("value", user_id);
                    $("#phone_no_reg").attr("value", user_mobile);
                    $("#college_name_reg").attr("value", user_college);
                    $("#user_branch_reg").attr("value", user_branch);



                }
            }
        });
    });
    $(".button").on('click', function() {
        var id = $(this).attr("val");

        $.ajax({
            url: "get_event_details.php",
            type: "post",
            data: {
                id: id
            },
            success: function(response) {
                var jsonData = JSON.parse(response);
                for (var i = 0; i < jsonData.length; i++) {
                    var counter = jsonData[i];
                    var event_name = counter.event_name;
                    var event_desc = counter.event_desc;
                    var event_rules = counter.event_rules;
                    var event_price = counter.event_price;
                    var event_image = counter.event_image;
                    var event_pdf = counter.event_pdf;

                    $(".event_name").html(event_name);
                    $(".lead").html(event_desc);
                    $(".price").html("Rs: " + event_price);
                    $(".rules").html(event_rules);
                    $(".event_image").attr("src", "admin/upload/" + event_image);
                    $(".event_doc").attr("href", "/admin/upload/pdf/"+event_pdf);


                }
            }
        });
    });

   

        
          
          
            
</script>

<section id="coordinator">
      <div class="container ">
        <div class="coordinator-header">
          <h3>Technical Event Co-Ordinator</h3>
         <center> <i style="color:#ffffff !important;">for any query contact our Co-ordinator Member's Number Given Below</i></center>
        </div><br>
       
       <center><i style="color: #fff ;">Bibhu Prakash:- <a href="tel:7978215280" style="color: #fff; text-decoration: none; ">7978215280</a></i><br>
       <i style="color: #fff ;">Pritam Kumar:- <a href="tel:7008412046 " style="color: #fff; text-decoration: none; ">7008412046 </a></i><br>

        <i style="color: #fff ;">Rohit Kumar:- <a href="tel:9114198640" style="color: #fff; text-decoration: none; ">9114198640</a></i></center><br>
       
      

      </div>
    </section>


<?php include "footer.php"; ?>