<?php

session_start();
include "DbCOnnect.php";

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Welcome to Nirmaan'19</title>
       
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <meta name="keywords" content="nirmaan,Nirmaan'19, nirmaan,civil events, gce kjr, nirmaan gcekjr,nirmaan'19 gcekjr,big event nirmaan'19 gcekjr, jamunalia gce kjr, nirmaan'19,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,Nirmaan'19,Nirmaan'19,Nirmaan'19,Nirmaan'19,Nirmaan'19">
   <meta name="description" content="Nirmaan'19 is the big event which organised by Civil engineering department student in Gce kjr on 24-26 October.">


      
      
    <!-- Favicons -->
    <link href="img/l.png" rel="icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/event.css">
    <link rel="stylesheet" href="css/style2.css">
 <link rel="stylesheet" media="screen" href="https://fontlibrary.org/face/archicoco" type="text/css"/>
     <link rel="stylesheet" href="./css/bell1.css">
    <link rel="stylesheet" href="./css/bellbox.css">
    <link rel="stylesheet" href="./css/notifiy.css">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- Notice -->
     <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 
   
    <script type="text/javascript" src="./js/scrolltop1.js"></script>
    <script type="text/javascript" src="./js/notify1.js"></script>
   
  
   <link rel="stylesheet" href="./css/bell1.css">
    <link rel="stylesheet" href="./css/bellbox.css">
    <link rel="stylesheet" href="./css/notifiy.css">

  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149346447-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149346447-2');
</script>

</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title="" style="height: 140px;"></a>
                
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">
                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                    <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li class="menu-active"><a href="#intro">Home</a></li>

                    <li><a href="event.php">Events</a></li>
                    <li><a href="hospitality.php">Hospitality</a></li>
                    <li><a href="speaker.php">Expert Talk</a></li>
                    <li><a href="contactus.php">Contact Us</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"> </i> Logout </a></li>
                    <?php }else{ ?>
                    <li class="menu-active"><a href="index.php">Home</a></li>
                    <li ><a href="event.php">Events</a></li>
                     <li><a href="speaker.php">Expert Talk</a></li>
                     <li><a href="hospitality.php">Hospitality</a></li>
                      <li><a href="contactus.php">Contact Us</a></li>
            <li><a href=""  data-toggle="modal" data-target="#modalLRForm">LogIn</a></li>
                    
                    
                    <?php } ?>


                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->
