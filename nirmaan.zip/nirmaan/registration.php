<?php 
    session_start();

    include "DbConnect.php";
if(isset($_POST['submit'])){
     $registration = $_POST['registration'];
     $name = $_POST['name'];
     $email = $_POST['email'];
     $password = $_POST['password'];
     $collge_name = $_POST['college_name'];
     $branch = $_POST['branch'];
     $phone_no = $_POST['phone_no'];

    $select_query = "SELECT * FROM users WHERE email='$email'";

    $select_query_result = mysqli_query($con,$select_query);
   
    if(mysqli_num_rows($select_query_result) > 0 ){
        echo "User alredy exits please go back and try to login ! <a href='index.php'>Home</a>";
    }else{
         $query = "INSERT INTO users (name, email, password, branch, mobile_no, college_name) 
      	    	  VALUES ('$name', '$email', '".md5($password)."', '$branch', '$phone_no','$collge_name')";
        $result_insert = mysqli_query($con, $query);
        $id =  mysqli_insert_id($con);
        if($result_insert){
            $_SESSION['id'] = $id;
            $_SESSION['name'] = $name;
            $_SESSION['email'] = $email;
            $_SESSION['college_name'] = $collge_name;
            $_SESSION['phone_no'] = $phone_no;
            $_SESSION['branch'] = $branch;
            header('Location: event.php');
        }else{
            echo mysqli_connect_error($con);
        }
    }
    
}
    
?>