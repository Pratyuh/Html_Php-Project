<?php
    session_start();
    include "DbConnect.php";

     $id = $_POST['id'];
     $s_sql = "SELECT * FROM events WHERE id = '$id'";
     $result = mysqli_query($con, $s_sql);
    if($result){
        
    }else{
        echo mysqli_error($con);
    }
        while($row = mysqli_fetch_array($result)){;
        
           $event_name = $row['event_name'];
            $event_desc = $row['event_desc'];
            $event_rules = $row['event_rules'];
            $event_price = $row['event_price'];
            $event_image = $row['event_image'];
            $event_pdf = $row['event_pdf'];

    $return_arr[] = array(
                    "event_name" => $event_name,
                    "event_desc" => $event_desc,
                    "event_image" => $event_image,
                    
                    "event_rules" => $event_rules,
                    "event_price" => $event_price,
                    "event_pdf" => $event_pdf
                );

                                                 }
// Encoding array in JSON format
echo json_encode($return_arr);
        
?>