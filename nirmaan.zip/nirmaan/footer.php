
   


  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">
            <h2 style="color: #fff; size: 60px; font-weight: 50px;">Nirmaan</h2>
            <p>Nirmaan is a CIVIL Engineering Techno Symposium Organised by Civil Department of GOVERNMENT COLLEGE OF ENGINEERING, KEONJHAR</p>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="index.php">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="event.php">Events</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="schedule.php">Schedule</a></li>
               <li><i class="fa fa-angle-right"></i> <a href="speaker.php">Expert Talk</a></li>
            </ul>
          </div>

            <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Follow Us</h4>
            

            <div class="social-links">
             <a href="https://www.facebook.com/nirmaan19/" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="https://instagram.com/nirmaan_2k19?igshid=1dq6qij0laoqe" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="mailto: nirmaan.gcekjr@gmail.com" target="_top"><i class="fa fa-envelope" ></i></a>
            </div><br><br>
            
            
           <div class="social-links">

       <div class="mapouter"><div class="gmap_canvas"><iframe width="290" height="170" id="gmap_canvas" src="https://maps.google.com/maps?q=GOVERNMENT%20COLLEGE%20OF%20ENGINEERING%2C%20KEONJHAR&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Google Maps Generator by <a href="https://www.embedgooglemap.net">embedgooglemap.net</a></div><style>.mapouter{position:relative;text-align:right;height:170px;width:290px;margin-left: 10px;}.gmap_canvas {overflow:hidden;background:none!important;height:170px;width:300px;margin-left: 10px;}</style></div>

           
          </div>
     

          </div>


       


        
        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Designed By Pratyusa and Ajit 
      </div>
      <div class="credits">
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>

  <!-- JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/easing/easing.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/venobox/venobox.min.js"></script>
  <script src="lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="js/modal.js"></script>

  <!-- Contact Form JavaScript File -->
  <script src="contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="js/main.js"></script>
 
</body>

</html>