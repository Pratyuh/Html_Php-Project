
    
    <!--==========================
      Gallery Section
    ============================-->
    <section id="gallery" class="wow fadeInUp">

      <div class="container">
        <div class="section-header">
          <h2>Gallery</h2>
          
        </div>
      </div>

      <div class="owl-carousel gallery-carousel">
        <a href="img/gallery/1.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/1.png" alt=""></a>
        <a href="img/gallery/2.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/2.png" alt=""></a>
        <a href="img/gallery/3.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/3.png" alt=""></a>
        <a href="img/gallery/4.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/4.png" alt=""></a>
        <a href="img/gallery/5.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/5.png" alt=""></a>
        <a href="img/gallery/6.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/6.png" alt=""></a>
        <a href="img/gallery/7.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/7.png" alt=""></a>
        <a href="img/gallery/8.png" class="venobox" data-gall="gallery-carousel"><img src="img/gallery/8.png" alt=""></a>
      </div>

    </section>
