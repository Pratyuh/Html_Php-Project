<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Contact Us</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="keywords" content="Nirmaan'19 event, events civil engineering, gce kjr event, Nirmaan'19, criar events nirmaan'19, all events nirmaan'19,contact us page, nirmaan'19 contact us,Nirmaan'19 ,Nirmaan'19 ,Nirmaan'19 ,Nirmaan'19 ,Nirmaan'19, Nirmaan'19,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan,nirmaan ">
   <meta name="description" content="This is the Nirmaan'19 contact us page in this various contact are given to contact.">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-149346447-2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-149346447-2');
</script>

</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6); height: 70px;" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li><a href="registered_event.php" class="text-white">My Registered Events</a></li>
                    <li class=""><a href="hospitality.php" class="text-white">Hospitality</a></li>
                       <li class=""><a href="speaker.php" class="text-white">Expert Talk</a></li>
                    <li><a href="logout.php" class="text-white"><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }
                    else{ ?>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li class=""><a href="event.php" class="text-white">Events</a></li>
                     <li class=""><a href="hospitality.php" class="text-white">Hospitality</a></li>
                      <li class=""><a href="speaker.php" class="text-white">Expert Talk</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">

   
   

   <!--==========================
      Speakers Section
    ============================-->
    <section id="speakers" class="wow fadeInUp" style="background-color: #03FBFF; padding-top: 120px">
      <div class="container" >
        <div class="section-header">
          <h2 style="margin-top: 10px;">Contact Us</h2>
          
        </div>

        
         
       <center><b> <u>Convenor</u></b><br>
         Mrs. Suman Dash <br>
        <a href = "mailto: sumandash_fce@gcekjr.ac.in">sumandash_fce@gcekjr.ac.in</a><br><br>
        <u><b>Co-Convenor</u></b><br>
        Mr. Satish Chandra Bhuyan <br>
    <a href = "mailto: satishbhuyan_2015@gcekjr.ac.in">satishbhuyan_2015@gcekjr.ac.in</a><br><br>
        <u><b>Faculty Co-Ordinator</u></b><br>
         Mr. Kumar Aadars :
        <a href = "mailto: kumaraadars21@gcekjr.ac.in">kumaraadars21@gcekjr.ac.in</a><br>
        Ms. Sonali Upadhyaya :
        <a href = "mailto: cvrce15sonali@gcekjr.ac.in">cvrce15sonali@gcekjr.ac.in</a>
         <br><br><br>

         <b><u>Student Co-ordinators</u></b><br>
            Subrat Kumar Barik : <a href="tel:7008708209">7008708209</a><br>
            Amulya Nayak : <a href="tel:7008257235">7008257235</a><br>
            Debashish Jena : <a href="tel:8455826608">8455826608</a><br>
            Bhakta Charan Nayak: <a href="tel:7008769394">7008769394</a>
      </center> 
       
        

        
     
      </div>

    </section>

    
  


  
<?php include "footer.php"; ?>
    

