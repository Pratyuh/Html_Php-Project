<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Hospitality</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicons -->
    <link href="img/favicon.png" rel="icon">
    <link href="img/subscribe-bg.jpg" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/venobox/venobox.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="css/style.css" rel="stylesheet">

    <!-- =======================================================
    Theme Name: TheEvent
    Theme URL: https://bootstrapmade.com/theevent-conference-event-bootstrap-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= -->
  <style type="text/css">
input[type="text"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="email"]
{
    font-size:15px;
    border-radius: 10px;
}
input[type="password"]
{
    font-size:15px;
    border-radius: 10px;
}

  </style>
</head>

<body>

    <!--==========================
    Header
  ============================-->
    <header id="header" style="background: rgba(0,0,0,0.6);" >
        <div class="container">

            <div id="logo" class="pull-left">
                <!-- Uncomment below if you prefer to use a text logo -->
                <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
                <a href="index.php"><img src="img/m.png" alt="" title=""></a>
            </div>

            <nav id="nav-menu-container">
                <ul class="nav-menu">

                    <?php if(isset($_SESSION['id'])){
                          
                    ?>
                     <li><a href="#"><i class="fa fa-user"> </i> <?php if(isset($_SESSION['id'])){ echo $_SESSION['name'];} ?></a></li>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li ><a href="event.php" class="text-white">Events</a></li>
                    <li><a href="registered_event.php" class="text-white">My Registered Events</a></li>
                    <li><a href="speaker.php" class="text-white">Expert Talk</a></li>
                    <li ><a href="schedule.php" class="text-white">Schedule</a></li>
                    <li><a href="logout.php" class="text-white"><i class="fa fa-sign-out" > </i> Logout </a></li>
                    <?php }else{ ?>
                    <li><a href="index.php" class="text-white">Home</a></li>
                    <li ><a href="schedule.php" class="text-white">Schedule</a></li>
                   <!-- <li><a href='' data-toggle="modal" data-target="#modalLRForm" class="text-white">Create a account</a></li>-->
                    <li><a href="contactus.php" class="text-white">Contact Us</a></li>
                     <li><a href="speaker.php" class="text-white">Expert Talk</a></li>
                    <?php } ?>
                </ul>
            </nav><!-- #nav-menu-container -->
        </div>
    </header><!-- #header -->



  <main id="main">

   
   

    <!--==========================
     Hospitaliy Section
    ============================-->
     <section id="schedule" class="section-with-bg" style="background-color: #FAC369;">
      <div class="container wow fadeInUp">
       <div class="section-header">
          <h2 >Hospitality</h2>
          <p style="color:#fff !important;">Here is our hospitality</p>
        </div>
           <center><h4 style="margin-bottom: 10px;font-weight: bold;"><u>Accommodation</u></h4></b></center>
               <p style="text-align: justify;">The friendly atmosphere among students and the pleasant environment here offer more to its sojourners than just accommodation. As a participant of the Fest, your hospitality is our primary concern. We will make sure that your short stay with us will be pleasant and comfortable. The Fest will surely be a memorable experience for you. To assist you in the best possible manner, we require a few preliminary things to be checked from your side. For More Information regarding this please contact our coordinator.. <br><br><br>
               Mr. Subrat Kumar Barik <a href="tel:7008708209">7008708209</a> <br>
                    Mr. Bhakta Ch. Nayak <a href="tel:7008769394">7008769394</a> </p><br><br><br>

<h4><u>REGISTRATION FEE</u></h4>
<p style="text-align: justify;">
1.Tech. events is free to all. <br>
2. To be paid only in cash at the registration desk during NIRMAAN, GCE keonjhar.<br>
3. Accommodation= ₹ 200.<br>
4. Entry fee for each non-technical event collected at the event spot.<br>
5. T-shirt price=₹250. </p><br><br><br>

      <h4><u>INSTRUCTIONS</u></h4> 
   <p style="text-align: justify;">   1. Only participants from outside of keonjhar will be considered for accommodation.<br>
2. All the participants are required to carry their college identity cards which will be
verified at the Registration Desk with your registered names.<br>
3. The hospitality fee should be paid in cash at the Registration Desk after reaching
GCE keonjhar. There is no provision for online payment.</p> <br>


     </div>

           

        </div>

      </div>

    </section>

  



  
<?php include "footer.php"; ?>
    

