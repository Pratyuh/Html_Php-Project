<?php
    include "DbConnect.php";
    $s_sql = "SELECT * FROM notice";
     $result = mysqli_query($con, $s_sql);
?>



<!--==========================
    Intro Section
  ============================-->

<style type="text/css">
.btn {
  margin-left: 10px;
  margin-right: 10px;
}
/* Boostrap Buttons Styling */

.btn-default {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(108, 88, 179, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(108, 89, 179, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-default:hover {
  color: #FFF;
  background: rgba(108, 88, 179, 0.75);
  border: 2px solid rgba(108, 89, 179, 0.75);
}

.btn-primary {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(58, 133, 191, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(58, 133, 191, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-primary:hover {
  color: #FFF;
  background: rgba(58, 133, 191, 0.75);
  border: 2px solid rgba(58, 133, 191, 0.75);
}

.btn-success {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(103, 192, 103, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(103, 192, 103, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-success:hover {
  color: #FFF;
  background: rgb(103, 192, 103, 0.75);
  border: 2px solid rgb(103, 192, 103, 0.75);
}

.btn-info {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(91, 192, 222, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(91, 192, 222, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-info:hover {
  color: #FFF;
  background: rgba(91, 192, 222, 0.75);
  border: 2px solid rgba(91, 192, 222, 0.75);
}

.btn-warning {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(240, 173, 78, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(240, 173, 78, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-warning:hover {
  color: #FFF;
  background: rgb(240, 173, 78, 0.75);
  border: 2px solid rgba(240, 173, 78, 0.75);
}

.btn-danger {
  font-family: Raleway-SemiBold;
  font-size: 13px;
  color: rgba(217, 83, 78, 0.75);
  letter-spacing: 1px;
  line-height: 15px;
  border: 2px solid rgba(217, 83, 78, 0.75);
  border-radius: 40px;
  background: transparent;
  transition: all 0.3s ease 0s;
}

.btn-danger:hover {
  color: #FFF;
  background: rgba(217, 83, 78, 0.75);
  border: 2px solid rgba(217, 83, 78, 0.75);
}
blink {
        animation: blinker 2.3s linear infinite;
        font-size:15px;
        font-weight:bold;
        color: #fff;
       }
      @keyframes blinker {  
        50% { opacity: 0; }
       }
       .blink-one {
         animation: blinker-one 0.4s linear infinite;
       }
       @keyframes blinker-one {  
         0% { opacity: 0; }
       }
       .blink-two {
         animation: blinker-two 3.4s linear infinite;
       }
       @keyframes blinker-two {  
         100% { opacity: 0; }
       }
</style>
 
  <section id="intro">
<div class="intro-container wow fadeIn">

      <blink>Click on the Bell-Icon to know Updates!</blink>
        <img src="img/n.png" style="width: 300px; height: 70px;">

       <p class="text-danger">Sponsored By TEQIP-III</p>
      <h1 style="font-size:2.3rem;margin: 0; padding: 0;" class="mb-4 pb-0">The Annual<br>Civil <span>Techno</span> symposium</h1>


<p class="mb-4 pb-0">24 - 26 october, <br>CIVIL ENGINEERING DEPARTMENT,<br></p><p style="font-size: 12px; text-transform: uppercase; margin: 0; padding: 0;"> Government College of Engineering, Keonjhar</p>


<p id="demo" style="text-align: center;font-size: 25px; margin-top: 0px; color: red;"></p>

 

      <a href="#about" class="about-btn scrollto"><img src="img/scroll-me.gif" id="img-scroll" style="width:30px;margin: 0; padding: 0;"></a>
     
      
    </div>

   <!-- Bell Icon -->
<div class="container" id="content" style="background-color:;min-height:50vh;color:white;overflow:-webkit-paged-x;">
  <div class="bell-box">
      
    <span class="dot"> <a style="color: red;" href='#' data-toggle="modal" data-target="#myModal1" val="<?php echo $row['id']; ?>"> <span class="bell fa fa-bell" style="margin-left: 10px; margin-top: 10px;"></span></a></span>
    
  </div>
  
  
  <!-- Modal For Notice -->
  <div id="myModal1" class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" style="padding: 30px;">
      <div class="modal-content" style="height: 440px; background-color: #342A28; border: 2px solid red; border-radius: 20px 20px 4px;">
        <div class="modal-header" style="border-bottom: 2px solid red">
          <p style="margin: 0px;
          padding: 0px; color: #fff; margin-left: 10px;">Notification:-</p>
        </div>
        <div class="modal-body" style="overflow-y: scroll;">
          <table class="table" style="color: black">
            <thead>
              <tr>
                
                
              </tr>
            </thead>
            <tbody>
              <?php
              while($row = mysqli_fetch_assoc($result))
              {
              ?>
              <tr style="border-top: 2px solid #E1F879;border: none;">
                
                <td style="text-align: justify;border: none; padding: 0px 0px 8px 0px;"><i class="material-icons " style="font-size:15px;color: #fff;">forward</i> <i style="font-size: 15px; color: #fff;"><?php echo $row['event_desc']; ?></i></td>
                
              </tr>
              <?php
              }
              ?>
              
            </tbody>
          </table>
        </div>
      
      </div>
    </div>
  </div>
</div>
</div>
<div class="notify-tip" style="position:fixed"></div>
</div>

   


  </section>

  <main id="main">

    <!--==========================
      About Section
    ============================-->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <h2 class="mb-4">About The Event</h2>
            <p style="text-align: justify;">We at NIRMAAN'19 ,
               focus to create a platform for the students to showcase their talent in civil engineering 
               and help them over-reach in this field, we envision a fest which is uniquely different from any 
               other college fest of the kind, with a strong motive and purpose. Adding to the nine incredibly 
               successful and triumphant editions to its grandeur, we are all set with its new and exalted 
               levels of zeal, enthusiasm and passion to march ahead as a flag bearer continuing its glorious
                lineage and legacy.</p>

           <div class="text-center">
                  <a href='schedule.php' class="p-3 pl-5 pr-5"><img src="img/sch.png" style="width: 80px; height: 80px; margin-bottom: 10px; margin-left:-30px;"> </a>
                  <a href='event.php' class="p-3 pl-5 pr-5"><img src="img/eve.png" style="width: 80px; height: 80px; margin-bottom: 10px;"></a>
                  <a href='speaker.php' class="p-3 pl-5 pr-5"><img src="img/ex.png" style="width: 80px; height: 80px;  margin-left:7px; "></a>
                  <a href='contactus.php' class="p-3 pl-5 pr-5"><img src="img/co.png" style="width: 80px; height: 80px; "></a>
              </div>  

           
         
        </div>
      </div>
    </section>

    <script type="text/javascript">
      $(document).mouseup(function (e)
                    {
  var container = $("#YOUR_CONTAINER_SELECTOR"); // YOUR CONTAINER SELECTOR

  if (!container.is(e.target) // if the target of the click isn't the container...
      && container.has(e.target).length === 0) // ... nor a descendant of the container
  {
    container.hide();
  }
});
    </script>
    
    <!--CountDown Timee -->

    <script>
// Set the date we're counting down to
var countDownDate = new Date("Oct 23, 2019 12:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "D " + hours + "H "
  + minutes + "M " + seconds + "S ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Event Is Started";
  }
}, 1000);
</script>
