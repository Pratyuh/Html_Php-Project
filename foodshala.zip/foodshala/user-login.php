<!-- customer login page  -->
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
	<body>
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php" style="font-size: 18px;">FoodShala</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						
						
						
					</ul>
				</div>
			</div>
		</nav><br><br><br><br>
		<!-- Customer Signin form -->
		<center><h1><u>User Login Page</u></h1></center>
		<div class="container col-md-6 col-md-offset-3">
			<form action="user-login.php" method="post">
				<div class="form-group">
					<label for="email">Email<b>*</b></label>
					<input type="email" class="form-control" id="email" name="email" required/>
				</div>
				<div class="form-group">
					<label for="password">Password<b>*</b></label>
					<input type="password" class="form-control" id="password" name="password" required/>
				</div>
				<button type="submit" name="userSigninBtn" class="btn btn-success">Sign in</button>
				<span>Don't have account? <a class="text-danger" href="user-signup.php">Sign up</a></span>
			</form>
		</div>
	</body>
</html>

<!-- php functionallity for user login and resturant login-->
<!-- here i provide that if a customer login and as usual it login and order food but if a resturant login here then thr resturant cant be orderd food only see the page. -->

<?php

require 'files/connection.php';
error_reporting(E_ERROR | E_PARSE);
session_start();
if (isset($_POST['userSigninBtn'])) {
$email = $_POST['email'];
$password = $_POST['password'];
$hashpassword = md5($password);


$select_query = "SELECT * FROM restaurants WHERE res_email='$email' and res_password='$hashpassword'";

// this is for resturant if resturant login in user panel than they cant add item in cart only see in the cart

$result1=$conn->query($select_query);
$row1 = $result1->fetch_assoc();

	$id1 = $row1['id'];
	$res_name = $row1['res_name'];

$count1 = mysqli_num_rows($result1);
		

if($count1 == 1) {
	$_SESSION['restid'] = $id1;
	$_SESSION['res_name'] = $res_name;

header("location: restaurant-view.php");
}

else{
	//this is for customer login functonality
	$sql="select * from customers where email='$email' and password='$hashpassword'";
	$result=$conn->query($sql);
	$row = $result->fetch_assoc();
			$id = $row['id'];
			$first_name = $row['first_name'];
	$count = mysqli_num_rows($result);
	if($count == 1) {
		$_SESSION['custid'] = $id;
		$_SESSION['first_name'] = $first_name;
		header("location: welcome-user.php");
		}
	

}
}
?>