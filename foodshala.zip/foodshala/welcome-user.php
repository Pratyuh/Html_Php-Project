<!-- This page After User Login -->
<?php
	require 'files/connection.php';
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	if(strlen($_SESSION['custid'])==0)
	{
	header('location:user-login.php');
	}
	else {
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<style type="text/css">
			div.col-sm-4{
				margin-bottom: 20px;
			}
			div.card-body p{
				font-size: 13px;
				margin-top: -10px;
			}
			div.res-info{
				margin-bottom: 8px;
			}
			#item_quantity{
				width: 30px;
				float: right;
			}
			.cart-form span{
				margin: 2px 3px;
			}
		</style>
	</head>

	<body style="background: #eacda3;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #d6ae7b, #eacda3);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #d6ae7b, #eacda3); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand active" href="welcome-user.php" style="font-size: 18px;">FoodShala Welcome: <?php echo $_SESSION['first_name'];?></a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="my-order.php" class="active">My Order</a><li>
						
						<form method="get" action="files/logout.php">
							<li><button name="logout" type="submit" class="btn btn-danger" style="margin-top: 8px;">Logout</button><li>
							</form>
						</ul>
					</div>
				</div>
			</nav><br><br><br>
			
			
	<!-- show all added item by resturant -->
			<?php
				require 'files/connection.php';
				$sql1 = "select menu_items.*, restaurants.res_name from menu_items, restaurants where menu_items.res_id=restaurants.id";
				$result1 = $conn->query($sql1);
			?>
			<div class="container-fluid" ><br>
		<center><h2>All Menu Available Here</h2><hr></center>	
				<?php
				while($row = $result1->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;margin-bottom: 30px;">
						<img class="card-img-top" src="<?php echo $row['item_imagepath']; ?>" alt="Card image" style="width:100%; height: 160px;">
						<div class="card-body">
							<h4 class="card-title"><?php echo ucwords($row['item_name']); ?></h4>
							<b class="card-text pull-right"><?php echo ucfirst($row['item_type']); ?></b>
							
							<div class="card-text res-info">Restaurant -<b> <?php echo ucwords($row['res_name']) ?></b></div>
		<form class="cart-form" action="welcome-user.php" method="post">
								<input type="hidden" name="item_id" value="<?php echo $row['item_id']; ?>">
								<input type="hidden" name="res_id" value="<?php echo $row['res_id']; ?>">
								<input type="hidden" name="item_name" value="<?php echo $row['item_name']; ?>">
								<input type="hidden" name="res_name" value="<?php echo $row['res_name']; ?>">
								<input type="hidden" name="item_price" value="<?php echo $row['item_price']; ?>">
							
								<button name="addCartBtn" id="addCartBtnid" class="btn btn-sm btn-info pull-right">Buy Now</button>

							</form>
							<div class="card-text" style="margin-top: 10px;"><?php echo '₹'.$row['item_price']; ?></div>
						</div>
					</div>
				</div>
				<?php } ?>
			</div><br><br><br><br><br><br><br>

				<!-- Footer Section -->
		<footer id="sticky-footer" style="background: black;height: 100px;">
			<div class="container text-center">
				<h3>Copyright &copy; FoodShala </h3>
			</div>
		</footer>
			
			
		</body>
	</html>
	<?php } ?>

	<!-- Php function For Order Food -->

	<?php
	require 'files/connection.php';
	
     if(isset($_POST['addCartBtn'])) {
		$item_id = $_POST['item_id'];
		$res_id = $_POST['res_id'];
		$user_id = $_SESSION['custid'];
		$item_name = $_POST['item_name'];
		$item_price = $_POST['item_price'];
		$date = date('Y/m/d H:i:s');
		$res_name = $_POST['res_name'];
		
		
		$sql="insert into orders (id, user_id, res_id, item_name,  item_price, date,rest_name) values ('$item_id', '$user_id', '$res_id', '$item_name', '$item_price', '$date','$res_name') ";
		
		$result=$conn->query($sql);
			if($result){
	echo "<script> alert('Food Ordred Succefully Go to my order page');</script>";
	}
	else
	echo "error occured";
	
	}
	
	
	?>