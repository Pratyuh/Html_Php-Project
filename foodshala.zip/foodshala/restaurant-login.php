<!-- Resturant Login Page-->
<?php include('header.php'); 
// Turn off error reporting
error_reporting(0);
?>
<!-- Resturant Signin form -->
<center><h1 ><u>Resturant Login Page</u></h1></center>
<div class="container col-md-6 col-md-offset-3">
	<!-- form start -->
	<form action="restaurant-login.php" method="post">
		<div class="form-group">
			<label for="email">Restaurant Email<b>*</b></label>
			<input type="email" class="form-control" id="res_email" name="res_email" required/>
		</div>
		<div class="form-group">
			<label for="password">Password<b>*</b></label>
			<input type="password" class="form-control" id="res_password" name="res_password" required/>
		</div>
		<button type="submit" name="resSigninBtn" class="btn btn-success">Sign in</button>
		<span>Don't have account? <a class="text-danger" href="restaurant-signup.php">Sign up</a></span>
	</form>
	<!-- form end -->
</div>
</body>
</html>

<!-- php code for resturant login function-->
<?php
	require 'files/connection.php';
session_start();
	
		if(isset($_POST['resSigninBtn'])) {
	$res_email = $_POST['res_email'];
	$res_password = $_POST['res_password'];
	$reshashpassword = md5($res_password);
	$sql="select * from restaurants where res_email='$res_email' and res_password='$reshashpassword'";
	$result=$conn->query($sql);
	$row = $result->fetch_assoc();
	
			$id = $row['id'];
			$res_name = $row['res_name'];

	$count = mysqli_num_rows($result);
	if($count == 1) {
		$_SESSION['restid'] = $id;
		$_SESSION['res_name'] = $res_name;
		header("location: viewmenu.php");
		}else {
		echo "<script> alert('Your Login Name or Password is invalid');</script>";
		}
	}
	
?>