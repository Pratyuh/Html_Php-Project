-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2020 at 04:14 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodshala`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `preference` varchar(100) NOT NULL,
  `contact_number` bigint(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `email`, `preference`, `contact_number`, `password`) VALUES
(17, 'Pratyusa', 'Dwibedy', 'onlinewebhost2019@gmail.com', 'non-veg', 7077079340, '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `item_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_imagepath` varchar(255) NOT NULL,
  `item_price` int(100) NOT NULL,
  `item_type` varchar(100) NOT NULL,
  `item_desc` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`item_id`, `res_id`, `item_name`, `item_imagepath`, `item_price`, `item_type`, `item_desc`) VALUES
(19, 8, 'Chicken Biriyani', 'uploads/2020_07_29_15_38_20_Hyderabadi-Chicken-Biryani-800x900.jpg', 400, 'non-veg', 'Chicken Biriyani'),
(20, 8, 'Roti Sabji', 'uploads/2020_07_29_15_38_35_sabji paratha.jfif', 120, 'veg', 'Sabji'),
(21, 8, 'Dal Fry', 'uploads/2020_07_29_15_38_57_Dhaba_Style_Dal_Fry_Recipe-1.jpg', 50, 'veg', 'dalfry'),
(22, 9, 'Chicken Drump Stick', 'uploads/2020_07_29_15_40_33_delish-190808-baked-drumsticks-0217-landscape-pf-1567089281.jpg', 500, 'non-veg', 'chicken'),
(23, 9, 'Noddles', 'uploads/2020_07_29_15_41_08_download.jfif', 30, 'veg', 'noddles'),
(24, 9, 'choco cake', 'uploads/2020_07_29_15_41_44_image.jfif', 600, 'veg', 'cake'),
(25, 8, 'Egg Roll', 'uploads/2020_07_29_15_53_10_59252082.jfif', 23, 'non-veg', 'eggroll');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `id` int(100) NOT NULL,
  `user_id` int(11) NOT NULL,
  `res_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `item_price` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `rest_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `id`, `user_id`, `res_id`, `item_name`, `item_price`, `date`, `rest_name`) VALUES
(36, 19, 17, 8, 'Chicken Biriyani', 400, '2020-07-29 15:45:30', 'Taj Hotel'),
(37, 24, 17, 9, 'choco cake', 600, '2020-07-29 15:46:14', 'Hotel Priya');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `id` int(11) NOT NULL,
  `res_name` varchar(100) NOT NULL,
  `res_email` varchar(100) NOT NULL,
  `res_number` bigint(100) NOT NULL,
  `res_city` varchar(100) NOT NULL,
  `res_password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`id`, `res_name`, `res_email`, `res_number`, `res_city`, `res_password`) VALUES
(8, 'Taj Hotel', 'pratyusacool@gmail.com', 7077079340, 'kalimela', '202cb962ac59075b964b07152d234b70'),
(9, 'Hotel Priya', 'pratyushcool04@gmail.com', 7896542587, 'Malkangiri', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `restaurants`
--
ALTER TABLE `restaurants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
