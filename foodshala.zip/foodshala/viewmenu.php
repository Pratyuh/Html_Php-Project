<!-- this page for resturant added menu show in
resturant tab-->

<?php
	require 'files/connection.php';
	session_start();
	if(strlen($_SESSION['restid'])==0)
	{
	header('location:restaurant-login.php');
	}
	else {
		
	
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<style type="text/css">
			.preview-area{
				width: 180px;
				height: 150px;
				display: none;
			}
			.preview-area img{
				width: 100%;
				height: 100%;
			}
		</style>
	</head>
	<body>
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand active" href="viewmenu.php" style="font-size: 18px;">FoodShala - Welcome <?php echo $_SESSION['res_name'];?></a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						
						
						<li><a href="add-menu.php" class="active">Add Menu item</a><li>
						<li><a href="view-orders.php">View Orders</a><li>
						<form method="get" action="files/logout.php">
							<li><button name="res_logout" type="submit" class="btn btn-danger" style="margin-top: 8px;">Logout</button><li>
							</form>
						</ul>
					</div>
				</div>
			</nav><br><br><br>
			<center><h1>View Menu Page</h1></center>
			
			
			<div class="content">
				<?php
				require 'files/connection.php';
				$user_id = $_SESSION['restid'];
				$query="SELECT * FROM menu_items where res_id = '$user_id'";
				$stmt=$conn->prepare($query);
				$stmt->execute();
				$result=$stmt->get_result();
				
				?>
				<a href="add-menu.php" class=" btn btn-primary">Add New Menu</a>
				<h4>Total Menu Item You Added
				<?php
				$rows_total = mysqli_num_rows($result);
				echo $rows_total;
				?>
				</h4><hr>
				<div class="card">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">Item Name</th>
								<th scope="col">Price</th>
								<th scope="col">Item Type</th>
								<th scope="col">Description</th>
								<th scope="col">Delete</th>
								
							</tr>
						</thead>
						<tbody>
							<?php while($row=$result->fetch_assoc()){ ?>
							<tr>
								<td><?= $row['item_name']; ?> </td>
								<td><?= $row['item_price']; ?></td>
								<td><?= $row['item_type']; ?></td>
								<td><?= $row['item_desc']; ?></td>
								<td><a href="files/delete_item.php?id=<?php echo $row['item_id']; ?>" class="btn btn-danger ">Remove</a> </td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
				</div>
				
			</div>

			<br><br><br><br><br><br><br><br>

			<?php include('footer.php') ?>
			
			
		</body>
	</html>
	<?php } ?>