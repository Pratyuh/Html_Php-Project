<!-- my order page-->
<?php
	require 'files/connection.php';
	session_start();
	error_reporting(E_ERROR | E_PARSE);
	if(strlen($_SESSION['custid'])==0)
	{
	header('location:user-login.php');
	}
	else {
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<style type="text/css">
			div.col-sm-4{
				margin-bottom: 20px;
			}
			div.card-body p{
				font-size: 13px;
				margin-top: -10px;
			}
			div.res-info{
				margin-bottom: 8px;
			}
			#item_quantity{
				width: 30px;
				float: right;
			}
			.cart-form span{
				margin: 2px 3px;
			}
		</style>
	</head>
	<body>
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand active" href="welcome-user.php" style="font-size: 18px;">FoodShala Welcome: <?php echo $_SESSION['first_name'];?></a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="welcome-user.php" class="active">Home</a><li>
						
						<form method="get" action="files/logout.php">
							<li><button name="logout" type="submit" class="btn btn-danger" style="margin-top: 8px;">Logout</button><li>
							</form>
						</ul>
					</div>
				</div>
			</nav><br><br><br>
			<!--Order Show section start -->
			
			<center><h1>My Order Page</h1></center>
   <div class="container-fluid" style="width: 60%">
			          <table class="table table-striped">

                        <!--show table only if there are items added in the cart-->
                        <?php
                        $sum = 0;
                  require 'files/connection.php';
				$user_id = $_SESSION['custid'];
                        $sql = "select * from orders where user_id = '$user_id'";

                        $result = mysqli_query($conn,  $sql)or die($mysqli_error($conn));
                        if (mysqli_num_rows($result) >= 1) {
                            ?>
                            <thead>
                                <tr>
                                   <th>Your Order Number</th>
                                    
                                    <th>Resturant Name</th>
                                    <th>Item Name</th>
                                    <th>Price</th>
                                     <th>Date Of Order</th>
                                   
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php
                                while ($row = mysqli_fetch_array($result)) {
                                    $sum+= $row["item_price"];
                                    $id="";
                                    $id .= $row["id"] . ",";
                                    echo "<tr>
                   <td>" . "# " . $row["order_id"] . "</td>
                   <td>" . "# " . $row["rest_name"] . "</td>
             <td>" . $row["item_name"] . "</td>
          <td>Rs " . $row["item_price"] . "</td>
            <td>" . $row["date"] . "</td>
      

   

                                          </tr>";
                                }
                              $id = rtrim($id, ",");
                         echo "<tr>
                         <td></td>
                                 <td></td>
                                  <td>Total</td>
                          <td>Rs " . $sum . "</td>
             
                                          </tr>";
                                ?>
                            </tbody>
                            <?php
                        } else {
                            echo "<center><h2>You are Not Buy Food Yet</h2></center>";
                        }
                        ?>
                        <?php
                        ?>
                    </table>
		</div>
			<?php } ?>

			<!--Order show section end --><br><br><br><br><br><br><br><br><br><br><br><br>
			

			<?php include('footer.php') ?>

		</body>
	</html>



