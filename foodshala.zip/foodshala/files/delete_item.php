<!-- delete menu item-->
<?php
    require 'connection.php';
    echo $id = $_GET['id'];


    $s_sql = "DELETE FROM menu_items WHERE item_id = '$id'";
    $result = mysqli_query($conn, $s_sql);

    if($result){
        header('Location: ../viewmenu.php');
    }else{
        echo mysqli_error($conn);
    }
?>