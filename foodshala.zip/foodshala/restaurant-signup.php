<!-- Resturant Signup page -->
<?php include('header.php'); ?>
<!-- Resturant signup form -->
<center><h1><u>Resturant SignUp Page</u></h1></center>
<div class="container col-md-6 col-md-offset-3">
	<!-- form start -->
	<form action="restaurant-signup.php" method="post">
		<div class="form-group">
			<label for="res_email">Restaurant Email<b>*</b></label>
			<input type="email" class="form-control" id="res_email" name="res_email" required/>
		</div>
		<div class="form-group">
			<label for="res_name">Restaurant Name<b>*</b></label>
			<input type="text" class="form-control" id="res_name" name="res_name" required />
		</div>
		<div class="form-group">
			<label for="res_number">Restaurant Number<b>*</b></label>
			<input type="text" class="form-control" id="res_number" name="res_number" required />
		</div>
		<div class="form-group">
			<label for="res_city">Restaurant City<b>*</b></label>
			<input type="text" class="form-control" id="res_city" name="res_city" required />
		</div>
		<div class="form-group">
			<label for="password">Password<b>*</b></label>
			<input type="password" class="form-control" id="res_password" name="res_password" required/>
		</div>
		<button type="submit" name="resSignupBtn" class="btn btn-primary">Sign up</button>
		<span>Already have an account? <a class="text-danger" href="restaurant-login.php">Sign in</a></span>
	</form>
	<!-- form end -->
</div>
</body>
</html>
<!-- php functionallity of resturant signup page -->
<?php
	require 'files/connection.php';
	
		if(isset($_POST['resSignupBtn'])) {
	$res_name = $_POST['res_name'];
	$res_email = $_POST['res_email'];
	$res_number = $_POST['res_number'];
	$res_city = $_POST['res_city'];
	$res_password = $_POST['res_password'];
	$hashrespassword = md5($res_password);
	$sql="insert into restaurants (res_name, res_email, res_number, res_city, res_password) values ('$res_name', '$res_email', '$res_number', '$res_city', '$hashrespassword')";
	$result=$conn->query($sql);
	if($result){
		header("location: restaurant-login.php");
	}
	else{
		echo "error occured";
	}
	}
	
?>