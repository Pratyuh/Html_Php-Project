<!-- Footer -->
<footer id="sticky-footer" style="background: black;height: 100px;">
			<div class="container text-center">
				<h3>Copyright &copy; FoodShala Pratyusa Dwibedy </h3>
				<p>Internshala Project</p>
			</div>
		</footer>