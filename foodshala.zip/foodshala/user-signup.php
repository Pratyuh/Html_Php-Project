<!-- customer sign up page -->
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<style type="text/css">
			b{
				color: red;
			}
		</style>
	</head>
	<body>
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="index.php" style="font-size: 18px;">FoodShala</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						
						
						
					</ul>
				</div>
			</div>
		</nav><br><br><br><br>
		<!-- Customer signup form -->
		<center><h1><u>User Signup Page</u></h1></center>
		<div class="container col-md-6 col-md-offset-3">
			<form action="user-signup.php" method="post">
				<div class="form-group">
					<label for="first_name">First Name<b>*</b></label>
					<input type="text" class="form-control" id="first_name" name="first_name" required />
				</div>
				<div class="form-group">
					<label for="last_name">Last Name<b>*</b></label>
					<input type="text" class="form-control" id="last_name" name="last_name" required />
				</div>
				<div class="form-group">
					<label for="email">Email<b>*</b></label>
					<input type="email" class="form-control" id="email" name="email" required/>
				</div>
				<div class="form-group">
					<label for="preference">Your Preference<b>*</b>&nbsp;</label>
					<input type="radio" name="preference" value="non-veg" required> Non-Veg &nbsp;
					<input type="radio" name="preference" value="veg" required> Veg
				</div>
				<div class="form-group">
					<label for="contact_number">Contact Number<b>*</b></label>
					<input type="text" class="form-control" id="contact_number" name="contact_number" required />
				</div>
				<div class="form-group">
					<label for="password">Password<b>*</b></label>
					<input type="password" class="form-control" id="password" name="password" required/>
				</div>
				<button type="submit" name="userSignupBtn" class="btn btn-success">Sign up</button>
				<span>Already have an account? <a class="text-danger" href="user-login.php">Login</a></span>
			</form>
		</div>
	</body>
</html>
<!-- php functionally for customer signup-->
<?php
	require 'files/connection.php';
	
		if(isset($_POST['userSignupBtn'])){
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$email = $_POST['email'];
	$preference = $_POST['preference'];
	$contact_number = $_POST['contact_number'];
	$password = $_POST['password'];
	$hashpassword = md5($password);

	$sql="insert into customers (first_name, last_name, email, preference, contact_number, password) values ('$first_name', '$last_name', '$email', '$preference', '$contact_number', '$hashpassword')";
	$result=$conn->query($sql);
	
	if($result){
		header("location: user-login.php");
	}
	else
		echo "error occured";
	}
	
?>