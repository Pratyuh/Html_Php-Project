<!-- Starting Page -->
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		
		
		<style type="text/css">

				div.col-sm-3{
				margin-bottom: 20px;
			}
			div.card-body p{
				font-size: 13px;
				margin-top: -10px;
			}
			div.res-info{
				margin-bottom: 8px;
			}
			.bg-image {
			/* The image used */
			background-image: url("uploads/1.jpg");
			
			/* Add the blur effect */
			filter: blur(2px);
			-webkit-filter: blur(2px);
			
			/* Full height */
			/* Center and scale the image nicely */
			background-position: center;
			background-repeat: no-repeat;
			background-size: cover;
			}
			.bg-text {
			background-color: rgb(0,0,0); /* Fallback color */
			background-color: rgba(0,0,0, 0.4); /* Black w/opacity/see-through */
			color: white;
			font-weight: bold;
			border: 3px solid #f1f1f1;
			position: absolute;
			top: 35%;
			left: 50%;
			transform: translate(-50%, -50%);
			z-index: 2;
			width: 80%;
			padding: 20px;
			text-align: center;
			}

		
		</style>
	</head>
	
	<body style="background: #114357;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #F29492, #114357);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #F29492, #114357); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand active" href="index.php" style="font-size: 18px;">FoodShala</a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="restaurant-login.php">Login As a Resturant</a></li>
						<li><a href="user-login.php">Login As a Customer</a></li>
						
					</ul>
				</div>
			</div>
		</nav><br><br><br>
		<!-- nav bar end-->
		<div class="container">
			
			<div class="bg-image"  style="height: 300px;"> </div>
			<div class="bg-text">
				<h1>FoodShala</h1>
				<p>This is the online food delivery system by which you can deliver any type of food</p>
			</div>
			
			<!-- Feature Product -->
			<h2>Top 4 Featured Product</h2><hr>
			<?php
				require 'files/connection.php';
				$sql = "select menu_items.*, restaurants.res_name from menu_items, restaurants where menu_items.res_id=restaurants.id ORDER BY item_name DESC limit 4";
				$result = $conn->query($sql);
			?>
			<div class="content"><br>
				<?php
					
				while($row = $result->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;">
						<img class="card-img-top" src="<?php echo $row['item_imagepath']; ?>" alt="Card image" style="width:100%; height: 160px;">
						<div class="card-body">
							<h4 class="card-title"><?php echo ucwords($row['item_name']); ?></h4>
							<p class="card-text pull-right"><?php echo ucfirst($row['item_type']); ?></p>
							<p class="card-text"><?php echo ucfirst($row['item_desc']); ?></p>
							<div class="card-text res-info">Restaurant Name - <?php echo ucwords($row['res_name']) ?></div>
							<a href="javascript:void(0);" class="btn btn-sm btn-info pull-right orderBtn">Order</a>
							<div class="card-text" style="margin-top: 8px;"><?php echo '₹'.$row['item_price']; ?></div>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			<!-- Feature Product End -->
			
			
		</div>

		<!-- Our Outlet -->
			
			<?php
			require 'files/connection.php';
			$sql2 = "select * from restaurants";
			$result2 = $conn->query($sql2);
			?>
			<div class="container-fluid" style="width: 90%"><br>
				<h2>Our Outlets</h2><hr>
				<?php
					
				while($row2 = $result2->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;">
						
						<div class="card-body" >
							<a href="user-login.php"> <img class="card-img-top" src="uploads/2.jpeg" alt="Card image" style="width:100%; height: 160px;"></a>
							<h4 class="card-title">Resturant Name: <?php echo ucwords($row2['res_name']); ?></h4>
							<p class="card-text">Contact Number : <?php echo ucfirst($row2['res_number']); ?></p>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
			<!-- Our Outlet  End-->

		<!-- Veg Item -->
		<div class="container-fluid" style="width: 90%">
			<h2 >All Veg Products</h2><hr>
			<?php
			require 'files/connection.php';
					$sql3 = "select * from menu_items where 	item_type = 'veg' limit 4 ";
			$result3 = $conn->query($sql3);
			?>
			<div class="container-fluid"><br>
				<?php
					
				while($row3 = $result3->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;">
						
						<div class="card-body" >
							<img class="card-img-top" src="<?php echo $row3['item_imagepath']; ?>" alt="Card image" style="width:100%; height: 160px;">
							<h4 class="card-title"><?php echo ucwords($row3['item_name']); ?></h4>
							<h5 class="card-text"><?php echo ucfirst($row3['item_type']); ?></h5>
							
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
		<!-- Veg Item End -->
		<!--Non  Veg Item -->
		<div class="container-fluid" style="width: 90%">
			<h2 >All Non-Veg Products</h2><hr>
			<?php
			require 'files/connection.php';
					$sql4 = "select * from menu_items where 	item_type = 'non-veg' limit 4 ";
			$result4 = $conn->query($sql4);
			?>
			<div class="container-fluid"><br>
				<?php
					
				while($row4 = $result4->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;">
						
						<div class="card-body" >
							<img class="card-img-top" src="<?php echo $row4['item_imagepath']; ?>" alt="Card image" style="width:100%; height: 160px;">
							<h4 class="card-title"><?php echo ucwords($row4['item_name']); ?></h4>
							<h5 class="card-text"><?php echo ucfirst($row4['item_type']); ?></h5>
							
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
		<!--Non  Veg Item End -->

		<!-- Script For orderbtn popup-->
		<script type="text/javascript">
			$('.orderBtn').on('click', function(){
				alert('To order something, first sign in');
			});
		</script>
		
		<!-- Footer Section -->
	<?php include('footer.php') ?>
	</body>
</html>