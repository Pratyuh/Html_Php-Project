<!-- This page After User Login -->
<?php
	require 'files/connection.php';
	session_start();
	if(strlen($_SESSION['restid'])==0)
	{
	header('location:restaurant-login.php');
	}
	else {
?>
<!DOCTYPE html>
<html>
	<head>
		<title>FoodShala</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<style type="text/css">
			div.col-sm-4{
				margin-bottom: 20px;
			}
			div.card-body p{
				font-size: 13px;
				margin-top: -10px;
			}
			div.res-info{
				margin-bottom: 8px;
			}
			#item_quantity{
				width: 30px;
				float: right;
			}
			.cart-form span{
				margin: 2px 3px;
			}
		</style>
	</head>

	<body style="background: #eacda3;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #d6ae7b, #eacda3);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #d6ae7b, #eacda3); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">
		<!-- navbar -->
		<nav class="navbar navbar-inverse navbar-fixed-top" style="font-size: 16px;">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand active" href="welcome-user.php" style="font-size: 18px;">FoodShala Welcome: <?php echo $_SESSION['res_name'];?></a>
				</div>
				<div class="collapse navbar-collapse" id="myNavbar">
					<ul class="nav navbar-nav navbar-right">
						
						
						<form method="get" action="files/logout.php">
							<li><button name="logout" type="submit" class="btn btn-danger" style="margin-top: 8px;">Logout</button><li>
							</form>
						</ul>
					</div>
				</div>
			</nav><br><br><br>
			
			
	<!-- show all added item by resturant -->
			<?php
				require 'files/connection.php';
				$sql1 = "select menu_items.*, restaurants.res_name from menu_items, restaurants where menu_items.res_id=restaurants.id";
				$result1 = $conn->query($sql1);
			?>
			<div class="container-fluid" ><br>
			<center>	<h3>You Cant Order Food As You are a Resturant </h3>
		<h2>All Menu Available Here</h2><hr></center>	
				<?php
				while($row = $result1->fetch_assoc()){ ?>
				<div class="col-sm-3">
					<div class="card" style="width:24rem;margin-bottom: 30px;">
						<img class="card-img-top" src="<?php echo $row['item_imagepath']; ?>" alt="Card image" style="width:100%; height: 160px;">
						<div class="card-body">
							<h4 class="card-title"><?php echo ucwords($row['item_name']); ?></h4>
							<b class="card-text pull-right"><?php echo ucfirst($row['item_type']); ?></b>
							
							<div class="card-text res-info">Restaurant -<b> <?php echo ucwords($row['res_name']) ?></b></div>
							
							
								<button name="addCartBtn" id="addCartBtnid" class="btn btn-sm btn-info pull-right" disabled>Buy Now</button>

							
							<div class="card-text" style="margin-top: 10px;"><?php echo '₹'.$row['item_price']; ?></div>
						</div>
					</div>
				</div>
				<?php } ?>
			</div><br><br><br><br><br><br><br>

				<!-- Footer Section -->
		<?php include('footer.php') ?>
			
			
		</body>
	</html>
	<?php } ?>

