<?php
        include 'includes/modal.php';
        ?>
<footer>
    <div class="container">
        <div class="row">
            <div class="columnf">
              <h3>Information</h3>
               
            </div>

            <div class="columnf">
              <h3>My Account</h3>
                <p><a href="#" data-toggle="modal" data-target="#loginmodal" ><span style="color:white">Log In</span></a></p>
                <p><a href="signup.php"><span style="color:white">Sign Up</span></a></p>
            </div>

            <div class="columnf">
              
               
            </div>
        </div>
        
    </div>
</footer>
