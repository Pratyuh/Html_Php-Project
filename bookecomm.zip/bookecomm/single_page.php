<?php error_reporting(0); ?>


<?php include'header.php' ?>


 <div class="super_container">
 	  <?php

 include('connection.php');

 $id=$_GET['single'];

 
   

$query=mysqli_query($conn,"select * from books where id='$id' ");

while($row=mysqli_fetch_array($query)){ 
  $name=$row['name'];
    $author=$row['author'];
   $thubnail=$row['image'];
    $price=$row['price'];
    $details=$row['details'];
     $file=$row['file'];
  

} ?> 
  
    <div class="single_product">
        <div class="container-fluid" style=" background-color: #fff; padding: 11px;">
            <div class="row">
                
                <div class="col-lg-6 order-lg-3 order-1">
           <div class="image_selected"><img src="img/<?php echo $thubnail; ?>" alt="" height="350px"></div>
                </div>
                <div class="col-lg-6 order-3">
                    <div class="product_description">
                       
                        <div class="product_name"><?php echo $name;?></div>

                        <div class="product-rating"><p>Author : <?php echo $author;?></p></div>

                        <div> <span class="product_price">₹  <?php echo $price;?></span> <strike class="product_discount"> <span style='color:black'>₹ 2,000<span> </strike> </div>
                        
                        <hr class="singleline">
                        <div> <p><?php echo $details;?></p> </div>
                        <div>
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="br-dashed">
                                        <div class="row">
                                            <div class="col-md-3 col-xs-3"> <img src="https://img.icons8.com/color/48/000000/price-tag.png"> </div>
                                            <div class="col-md-9 col-xs-9">
                                                <div class="pr-info"> <span class="break-all">Get 5% instant discount + 10X rewards @ RENTOPC</span> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-7"> </div>
                            </div>
                           
                        </div>
                        <hr class="singleline">
                        <div class="order_info d-flex flex-row">
                            <form action="#">
                        </div>
                        
                        <a  data-target=".bs-example-modal-sm" data-toggle="modal" class="btn btn-primary w-50">Download</a>
                           
                    </div>
                </div>
            </div>
           
         
        </div>
    </div>
</div>
   
<?php include'footer.php' ?>

</body>
</html>




<div tabindex="-1" class="modal bs-example-modal-sm" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header"><h4>Download <i class="fa fa-lock"></i></h4></div>
      <div class="modal-body"><i class="fa fa-question-circle"></i> Are you sure you want to Download <?php echo $name;?> ???</div>

      <div class="modal-footer"><a class="btn btn-primary btn-block" href="file/<?php echo $file;?>" download>Download</a></div>

    </div>
  </div>
</div>