<?php include'header.php' ?>



<main role="main">

  <section class="jumbotron text-center" style="background-image: url('img/back.jpg')">
    <div class="container">
      <h1>Welcome To Book World</h1>
      <p  style="color: white;font-size: 20px">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
      <p>
        <a href="#" class="btn btn-primary my-2">Main call to action</a>
        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
      </p>
    </div>
  </section>

  <div class="album py-5 bg-light">
    <div class="container">


        <?php
      require 'connection.php';
      $sql = "select * from books";
      $result = $conn->query($sql);
      ?>

      <div class="row">


      <?php
          
        while($row = $result->fetch_assoc()){ ?>

        <div class="col-md-3">
          <div class="card mb-4 shadow-sm">
             <img  class="img img-responsive" src="img/<?php echo $row['image']; ?>" height="350px" />

            <div class="card-body">
              <p class="card-text"><?php echo $row['name']; ?></p>
              <p class="card-text"><?php echo substr($row['details'], 0,50); ?>....</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                 <a href="single_page.php?single=<?php echo $row['id']?>" class="btn btn-primary">Buy Now</a>
                </div>
                <small class="text-muted">9 mins</small>
              </div>
            </div>
          </div>
        </div>

        <?php } ?>

     
      </div>
    </div>
  </div>

</main>

<?php include'footer.php' ?>